/*****< ss1vneti.c >***********************************************************/
/*      Copyright 2003 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  SS1VNETI - Stonestreet One Virtual Network Driver Implementation for      */
/*             Linux.                                                         */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/24/03  D. Lange       Initial creation.                               */
/******************************************************************************/
#include <sys/poll.h>           /* Included for poll().                       */
#include <sys/ioctl.h>          /* Included for ioctl().                      */
#include <sys/socket.h>         /* Included for skfd definition.              */
#include <net/if.h>             /* Included for if definitaion.               */
#include <fcntl.h>              /* Included for open(), read(), write().      */
#include <unistd.h>             /* Included for close().                      */
#include <pthread.h>            /* Included for thread functions.             */

#include "SS1VNET.h"            /* Main VNET Driver Prototypes/Constants.     */
#include "SS1VNETI.h"           /* VNET Driver Implementation Prototypes.     */
#include "SS1VNETM.h"           /* VNET Driver IOCTL's and Constants.         */

#include "BTPSKRNL.h"           /* BTPS Kernel Prototypes/Cosntants.          */

#define VNET_THREAD_STACK_SIZE   (65536)        /* Size of the Virtual Network*/
                                                /* Receive Thread's Stack (in */
                                                /* Bytes).                    */

#define ETHERNET_HEADER_SIZE           14       /* Size (in bytes) of the     */
                                                /* actual Ethernet Header that*/
                                                /* is used in the Ethernet    */
                                                /* Protocol.                  */

#define VNDIS_NETWORK_ADDRESS_LENGTH   (12)     /* Denotes the length of the  */
                                                /* Virtual NDIS Driver Network*/
                                                /* Address as a string,       */
                                                /* excluding the '/0' string  */
                                                /* terminator.                */

   /* The following constants represent the offsets (in bytes) of the   */
   /* fields present in th Ethernet Header.  These offsets are used when*/
   /* building an actual NDIS Packet and also when parsing a received   */
   /* NDIS Packet.                                                      */
#define ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET    0
#define ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET         6
#define ETHERNET_HEADER_TYPE_FIELD_OFFSET            12

   /* VNET Driver Information Block.  This structure contains ALL       */
   /* information associated with a specific Driver ID (member is       */
   /* present in this structure).                                       */
typedef struct _tagDriverInfo_t
{
   unsigned int             DriverID;
   unsigned int             VNETIndex;
   Mutex_t                  DriverMutex;
   int                      VNETHandle;
   Boolean_t                DeleteDriver;
   pthread_t                VNETThreadHandle;
   pthread_t                CallbackThreadHandle;
   VNET_Driver_Callback_t   DriverCallbackFunction;
   unsigned long            DriverCallbackParameter;
   struct _tagDriverInfo_t *NextDriverInfoPtr;
} DriverInfo_t;

   /* Internal Variables to this Module (Remember that all variables    */
   /* declared static are initialized to 0 automatically by the         */
   /* compiler as part of standard C/C++).                              */
static DriverInfo_t *DriverInfoList;            /* Variable which holds the   */
                                                /* First Entry (Head of List) */
                                                /* of All currently opened    */
                                                /* VNET Drivers.              */

static Mutex_t DriverInfoListMutex;             /* Mutex that guards access to*/
                                                /* the Virtual Network Driver */
                                                /* Information List.  This    */
                                                /* variable is also used to   */
                                                /* denote that this module    */
                                                /* has been successfully      */
                                                /* initialized.               */

static DriverInfo_t ThreadInfo;                 /* Global Access Structure    */
                                                /* that is used for passing   */
                                                /* information to a newly     */
                                                /* created VNET Thread.       */
                                                /* Access to this variable    */
                                                /* is protected via the       */
                                                /* VNET Driver Information    */
                                                /* List Mutex.                */

static int ThreadInitializedResult;             /* Global Access Variable     */
                                                /* that is used to pass the   */
                                                /* the initialization result  */
                                                /* from the newly created     */
                                                /* VNET Thread.  Access to    */
                                                /* this variable is           */
                                                /* protected via the VNET     */
                                                /* Information List Mutex.    */
                                                /* This variable holds the    */
                                                /* status of the newly        */
                                                /* created VNET Thread.       */

   /* Internal Function Prototypes.                                     */
static unsigned int GetNextDriverID(void);

static DriverInfo_t *AddDriverEntry(DriverInfo_t **ListHead, DriverInfo_t *EntryToAdd);
static DriverInfo_t *SearchDriverEntryByDriverID(DriverInfo_t **ListHead, unsigned int DriverID);
static DriverInfo_t *SearchDriverEntryByVNETIndex(DriverInfo_t **ListHead, unsigned int VNETIndex);
static DriverInfo_t *DeleteDriverEntry(DriverInfo_t **ListHead, unsigned int DriverID);
static void FreeDriverEntryMemory(DriverInfo_t *EntryToFree);
static void FreeDriverList(DriverInfo_t **ListHead);
static void FreeDriverStructureResources(DriverInfo_t *DriverInfo);

static void *ReceiveVNETThread(void *UserData);

static int InitializeVNETDriver(void);
static void CleanupVNETDriver(void);

   /* The following function is responsible for returning the Next      */
   /* Available VNET Driver ID.  This function will only return VNET    */
   /* Driver ID's that will be interpreted as Positive Integers (i.e.   */
   /* the Most Significant Bit will NEVER be set).                      */
static unsigned int GetNextDriverID(void)
{
   static unsigned int NextDriverID = 0;

   /* Increment the Counter to the next number.  Check the new number to*/
   /* see if it has gone negative (when ID is viewed as a signed        */
   /* integer).  If so, return to the first valid Number (one).         */
   NextDriverID++;

   if(((int)NextDriverID) < 0)
      NextDriverID = 1;

   /* Simply return the Driver ID Number to the caller.                 */
   return(NextDriverID);
}

   /* The following function adds the specified Entry to the specified  */
   /* List.  This function allocates and adds an entry to the list that */
   /* has the same attributes as the Entry passed into this function.   */
   /* This function will return NULL if NO Entry was added.  This can   */
   /* occur if the element passed in was deemed invalid or the actual   */
   /* List Head was invalid.                                            */
   /* * NOTE * This function does not insert duplicate entries into     */
   /*          the list.  An element is considered a duplicate if the   */
   /*          VNET Driver ID field is the same as an entry already     */
   /*          the list.  When this occurs, this function returns       */
   /*          in NULL.                                                 */
static DriverInfo_t *AddDriverEntry(DriverInfo_t **ListHead, DriverInfo_t *EntryToAdd)
{
   DriverInfo_t *AddedEntry = NULL;
   DriverInfo_t *tmpEntry;

   /* First let's verify that values passed in are semi-valid.          */
   if((ListHead) && (EntryToAdd))
   {
      /* Make sure that the element that we are adding seems semi-valid.*/
      if(EntryToAdd->DriverID)
      {
         /* OK, data seems semi-valid, let's allocate a new data        */
         /* structure to add to the list.                               */
         AddedEntry = (DriverInfo_t *)BTPS_AllocateMemory(sizeof(DriverInfo_t));

         if(AddedEntry)
         {
            /* Copy All Data over.                                      */
            *AddedEntry                   = *EntryToAdd;

            /* Now Add it to the end of the list.                       */
            AddedEntry->NextDriverInfoPtr = NULL;

            /* First, let's check to see if there are any elements      */
            /* already present in the List that was passed in.          */
            if((tmpEntry = *ListHead) != NULL)
            {
               /* Head Pointer was not NULL, so we will traverse the    */
               /* list until we reach the last element.                 */
               while(tmpEntry)
               {
                  if(tmpEntry->DriverID == AddedEntry->DriverID)
                  {
                     /* Entry was already added, so free the memory and */
                     /* flag an error to the caller.                    */
                     FreeDriverEntryMemory(AddedEntry);
                     AddedEntry = NULL;

                     /* Abort the Search.                               */
                     tmpEntry   = NULL;
                  }
                  else
                  {
                     /* OK, we need to see if we are at the last element*/
                     /* of the List.  If we are, we simply break out of */
                     /* the list traversal because we know there are NO */
                     /* duplicates AND we are at the end of the list.   */
                     if(tmpEntry->NextDriverInfoPtr)
                        tmpEntry = tmpEntry->NextDriverInfoPtr;
                     else
                        break;
                  }
               }

               if(AddedEntry)
               {
                  /* Last element found, simply Add the entry.          */
                  tmpEntry->NextDriverInfoPtr = AddedEntry;
               }
            }
            else
               *ListHead = AddedEntry;
         }
      }
   }

   return(AddedEntry);
}

   /* The following function searches the specified List for the        */
   /* specified Driver ID.  This function returns NULL if either the    */
   /* List Head is invalid, the Driver ID is invalid, or the specified  */
   /* Driver ID was NOT found.                                          */
static DriverInfo_t *SearchDriverEntryByDriverID(DriverInfo_t **ListHead, unsigned int DriverID)
{
   DriverInfo_t *FoundEntry = NULL;

   /* Let's make sure the list and Driver ID to search for appear to be */
   /* valid.                                                            */
   if((ListHead) && (DriverID))
   {
      /* Now, let's search the list until we find the correct entry.    */
      FoundEntry = *ListHead;

      while((FoundEntry) && (FoundEntry->DriverID != DriverID))
         FoundEntry = FoundEntry->NextDriverInfoPtr;
   }

   return(FoundEntry);
}

   /* The following function searches the specified List for the        */
   /* specified VNETIndex.  This function returns NULL if either the    */
   /* List Head is invalid, the VNETIndex is invalid, or the specified  */
   /* VNETIndex was NOT found.                                          */
static DriverInfo_t *SearchDriverEntryByVNETIndex(DriverInfo_t **ListHead, unsigned int VNETIndex)
{
   DriverInfo_t *FoundEntry = NULL;

   /* Let's make sure the list and VNET Index to searc for appear to be */
   /* valid.                                                            */
   if(ListHead)
   {
      /* Let's search the list until we find the same VNETIndex.        */
      FoundEntry = *ListHead;

      while((FoundEntry) && (FoundEntry->VNETIndex != VNETIndex))
         FoundEntry = FoundEntry->NextDriverInfoPtr;
   }

   return(FoundEntry);
}

   /* The following function searches the specified Driver List for the */
   /* specified Driver ID and removes it from the List.  This function  */
   /* returns NULL if either the Driver List Head is invalid, the Driver*/
   /* ID is invalid, or the specified Driver was NOT present in the     */
   /* list.  The entry returned will have the Next Entry field set to   */
   /* NULL, and the caller is responsible for deleting the memory       */
   /* associated with this entry by calling FreeDriverEntryMemory().    */
static DriverInfo_t *DeleteDriverEntry(DriverInfo_t **ListHead, unsigned int DriverID)
{
   DriverInfo_t *FoundEntry = NULL;
   DriverInfo_t *LastEntry  = NULL;

   /* Let's make sure the List and Driver ID to search for appear to be */
   /* semi-valid.                                                       */
   if((ListHead) && (DriverID))
   {
      /* Now, let's search the list until we find the correct entry.    */
      FoundEntry = *ListHead;

      while((FoundEntry) && (FoundEntry->DriverID != DriverID))
      {
         LastEntry  = FoundEntry;
         FoundEntry = FoundEntry->NextDriverInfoPtr;
      }

      /* Check to see if we found the specified entry.                  */
      if(FoundEntry)
      {
         /* OK, now let's remove the entry from the list.  We have to   */
         /* check to see if the entry was the first entry in the list.  */
         if(LastEntry)
         {
            /* Entry was NOT the first entry in the list.               */
            LastEntry->NextDriverInfoPtr = FoundEntry->NextDriverInfoPtr;
         }
         else
            *ListHead = FoundEntry->NextDriverInfoPtr;

         FoundEntry->NextDriverInfoPtr = NULL;
      }
   }

   return(FoundEntry);
}

   /* This function frees the specified Driver Information member.  No  */
   /* check is done on this entry other than making sure it is NOT NULL.*/
static void FreeDriverEntryMemory(DriverInfo_t *EntryToFree)
{
   if(EntryToFree)
      BTPS_FreeMemory(EntryToFree);
}

   /* The following function deletes (and free's all memory) every      */
   /* element of the specified Driver Information List.  Upon return of */
   /* this function, the Head Pointer is set to NULL.                   */
static void FreeDriverList(DriverInfo_t **ListHead)
{
   DriverInfo_t *EntryToFree;
   DriverInfo_t *tmpEntry;

   if(ListHead)
   {
      /* Simply traverse the list and free every element present.       */
      EntryToFree = *ListHead;

      while(EntryToFree)
      {
         tmpEntry    = EntryToFree;
         EntryToFree = EntryToFree->NextDriverInfoPtr;

         FreeDriverStructureResources(tmpEntry);

         FreeDriverEntryMemory(tmpEntry);
      }

      /* Make sure the List appears to be empty.                        */
      *ListHead = NULL;
   }
}

   /* This function represents the Receive VNET Data Thread.  This      */
   /* function will make sure that all Received VNET Data is dispatched */
   /* to the registered VNET Client.                                    */
   /* * NOTE * This function checks the global variable                 */
   /*          ThreadInfo to verify that there exists all necessary     */
   /*          VNET Thread Information.  This is done so that it        */
   /*          can actually be shutdown and communicate with the        */
   /*          main thread.                                             */
static void *ReceiveVNETThread(void *UserData)
{
   int                     VNETHandle;
   int                     DataLength;
   Mutex_t                 DriverMutex;
   Event_t                 ThreadInitializedEvent;
   Boolean_t               Done;
   Boolean_t               DeleteDriver;
   unsigned int            DriverID;
   DriverInfo_t           *DriverInfo;
   VNET_Event_Data_t       VNETEventData;
   unsigned char           EthernetPacketBuffer[VNET_MAXIMUM_ETHERNET_PAYLOAD_SIZE + VNET_ETHERNET_HEADER_SIZE];
   unsigned long           CallbackParameter;
   VNET_Driver_Callback_t  CallbackFunction;

   /* Initialize the Thread Initialized Event with the pointer passed   */
   /* in.                                                               */
   ThreadInitializedEvent = (Event_t)UserData;

   /* Now lets check to make sure that the required parameters appear to*/
   /* be at least semi-valid.                                           */
   if((ThreadInitializedEvent) && (ThreadInfo.VNETHandle) && (ThreadInfo.DriverID))
   {
      /* Store away Copy of the required parameters.                    */
      VNETHandle        = ThreadInfo.VNETHandle;
      DriverID          = ThreadInfo.DriverID;
      CallbackFunction  = ThreadInfo.DriverCallbackFunction;
      CallbackParameter = ThreadInfo.DriverCallbackParameter;

      /* Attempt to change the cancelation type for this thread to be   */
      /* asynchronous.                                                  */
      if(!(pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, (int *)NULL)))
      {
         /* Flag that the Initialization did Complete successfully.     */
         ThreadInitializedResult = 0;

         /* Signal the Initialization is Complete.                      */
         BTPS_SetEvent(ThreadInitializedEvent);

         Done = FALSE;
         while(!Done)
         {
            /* Change the cancelation state to enable asynchronous      */
            /* cancelation so that cancelation may occur while waiting  */
            /* for an event.                                            */
            if(!(pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, (int *)NULL)))
            {
               /* Flag that we have not received any data.              */
               DataLength = 0;

               /* Wait for a network packet to arrive.                  */
               if(!ioctl(VNETHandle, VNET_IOCTL_WAIT_RECEIVED_DATA, &DataLength))
               {
                  /* An event has occurred change the cancelation state */
                  /* to be disabled so that cancelation does not occur  */
                  /* while processing the event.                        */
                  if(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, (int *)NULL))
                  {
                     /* Error setting the cancelation type to be        */
                     /* deferred, force the thread to exit.             */
                     Done = TRUE;
                  }
               }
               else
               {
                  /* An error occurred while waiting for an event to    */
                  /* occur.                                             */
                  Done = TRUE;
               }
            }
            else
            {
               /* An error occurred changing the cancelation type to be */
               /* asynchronous, force the thread to exit.               */
               Done = TRUE;
            }

            /* Initialize the Delete Driver Flag.                       */
            DeleteDriver = FALSE;

            /* Check to make sure that an error did not occur before    */
            /* getting the Mutex.                                       */
            if(!Done)
            {
               /* Attempt to read the number of bytes that are available*/
               /* in the receive data packet.                           */
               DataLength = read(VNETHandle, EthernetPacketBuffer, sizeof(EthernetPacketBuffer));

               /* Now that we have receive a packet, let's dispatch the */
               /* Callback.                                             */
               if((DataLength >= VNET_ETHERNET_HEADER_SIZE) && (CallbackFunction))
               {
                  /* Format the VNET Data Indication Event.             */
                  VNETEventData.Event_Data_Type                                    = etVNET_Data_Indication;
                  VNETEventData.Event_Data.VNET_Data_Indication_Data.VNETDriverID  = DriverID;

                  VNETEventData.Event_Data.VNET_Data_Indication_Data.PayloadLength = DataLength - ETHERNET_HEADER_SIZE;
                  VNETEventData.Event_Data.VNET_Data_Indication_Data.PayloadBuffer = &(EthernetPacketBuffer[ETHERNET_HEADER_SIZE]);

                  VNET_ASSIGN_ETHERNET_ADDRESS(VNETEventData.Event_Data.VNET_Data_Indication_Data.EthernetHeader.DestinationAddress, EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 0], EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 1], EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 2], EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 3], EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 4], EthernetPacketBuffer[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 5]);
                  VNET_ASSIGN_ETHERNET_ADDRESS(VNETEventData.Event_Data.VNET_Data_Indication_Data.EthernetHeader.SourceAddress, EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 0], EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 1], EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 2], EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 3], EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 4], EthernetPacketBuffer[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 5]);

                  VNETEventData.Event_Data.VNET_Data_Indication_Data.EthernetHeader.EthernetTypeField = (unsigned short)((EthernetPacketBuffer[ETHERNET_HEADER_TYPE_FIELD_OFFSET + 0] << 8) | EthernetPacketBuffer[ETHERNET_HEADER_TYPE_FIELD_OFFSET + 1]);

                  /* A Data Packet has been received, now wait to get   */
                  /* the Mutex protecting the Driver Info List.         */
                  if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
                  {
                     /* Now Search for the Driver Info Structure for    */
                     /* this Driver ID in the Driver Info List.         */
                     if((DriverInfo = SearchDriverEntryByDriverID(&DriverInfoList, DriverID)) != NULL)
                     {
                        /* Note the Mutex used to protect this Driver   */
                        /* Info Structure.                              */
                        DriverMutex = DriverInfo->DriverMutex;

                        /* Release the Mutex that we acquired earlier.  */
                        BTPS_ReleaseMutex(DriverInfoListMutex);

                        /* Acquire the Mutex that protects this actual  */
                        /* VNET Driver.                                 */
                        if((DriverMutex) && (BTPS_WaitMutex(DriverMutex, BTPS_INFINITE_WAIT)))
                        {
                           DriverInfo->CallbackThreadHandle = pthread_self();

                           /* Submit the Callback.                      */
                           __BTPSTRY
                           {
                              (*CallbackFunction)(DriverID, &VNETEventData, CallbackParameter);
                           }
                           __BTPSEXCEPT(1)
                           {
                              /* Do Nothing.                            */
                           }

                           DriverInfo->CallbackThreadHandle = 0;

                           /* Check to see if a Request to close the    */
                           /* driver was made in the callback.          */
                           if(DriverInfo->DeleteDriver)
                              DeleteDriver = TRUE;

                           /* Release the Mutex that guards access to   */
                           /* this VNET Driver.                         */
                           BTPS_ReleaseMutex(DriverInfo->DriverMutex);
                        }
                        else
                           Done = TRUE;
                     }
                     else
                     {
                        /* An error occurred while searching for the    */
                        /* Driver Info Structure, signal the loop to    */
                        /* exit and release the previously acquired     */
                        /* Mutex.                                       */
                        BTPS_ReleaseMutex(DriverInfoListMutex);

                        Done = TRUE;
                     }

                     /* At this point we own NO Mutexes.                */
                     if(DeleteDriver)
                        CloseVNETDriver(DriverID);
                  }
               }
            }
         }
      }
      else
      {
         /* Flag that the Initialization did NOT Complete successfully. */
         ThreadInitializedResult = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

         /* Signal the Initialization is Complete.                      */
         BTPS_SetEvent(ThreadInitializedEvent);
      }
   }
   else
   {
      /* Flag that the Initialization did NOT Complete successfully.    */
      ThreadInitializedResult = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

      /* Signal the Initialization is Complete.                         */
      BTPS_SetEvent(ThreadInitializedEvent);
   }

   return(NULL);
}

   /* The following function Releases any Resources that are held by    */
   /* the specified Driver Information structure.  This function also   */
   /* flags all released resources as NOT being allocated.              */
static void FreeDriverStructureResources(DriverInfo_t *DriverInfo)
{
   /* Make sure a Driver Information structure is semi-valid.           */
   if(DriverInfo)
   {
      /* Cleanup all resources associated with this VSER Driver.        */
      if(DriverInfo->DriverMutex)
      {
         if(BTPS_WaitMutex(DriverInfo->DriverMutex, BTPS_INFINITE_WAIT))
         {
            /* Check to see if a valid VSER Status Thread Handle exists.*/
            if(DriverInfo->VNETThreadHandle)
            {
               /* A valid thread handle exists, cancel the thread to    */
               /* force it to exit.                                     */
               pthread_cancel(DriverInfo->VNETThreadHandle);

               /* Wait for the thread to exit.                          */
               pthread_join(DriverInfo->VNETThreadHandle, (void **)NULL);
            }

            /* Close the Open VNET Port (if indeed open).               */
            if(DriverInfo->VNETHandle)
               close(DriverInfo->VNETHandle);
         }

         /* Close the VSER Driver Mutex associated with this VSER Driver*/
         /* as it is no longer needed.                                  */
         BTPS_CloseMutex(DriverInfo->DriverMutex);
      }

      /* Initialize ALL Resources as NOT being allocated (valid).       */
      DriverInfo->VNETHandle           = -1;
      DriverInfo->VNETThreadHandle     = 0;
      DriverInfo->DriverMutex          = NULL;
      DriverInfo->CallbackThreadHandle = 0;
   }
}

   /* The following function is responsible for Initializing the Library*/
   /* and ALL Data structures required by the Library.  This function   */
   /* returns a non zero value if all resources were allocated and      */
   /* configured correctly, or zero otherwise.  This function MUST be   */
   /* called before any other function in this Module or the other      */
   /* functions will fail.                                              */
static int InitializeVNETDriver(void)
{
   /* Only Initialize the Module if it has NOT already been             */
   /* initialized.                                                      */
   if(!DriverInfoListMutex)
   {
      /* Initalize the Driver Information List Head Pointer to NULL     */
      /* (Empty).                                                       */
      DriverInfoList = NULL;

      /* Create the Mutex that will guard access to the VNET Driver     */
      /* Information List.  This Mutex is also used as a flag to        */
      /* determine if this module has been successfully initialized.    */
      DriverInfoListMutex = BTPS_CreateMutex(FALSE);
   }

   /* Return the Initialized Flag to the caller.                        */
   return((int)DriverInfoListMutex);
}

   /* The following function releases all resources that are held by    */
   /* this module (including memory and threads).  After this function  */
   /* is called, NO other function in this module will succede until a  */
   /* successful call to the InitializeVNETDriver() is completed.       */
static void CleanupVNETDriver(void)
{
   /* Check to make sure that this module has been initialized.         */
   if(DriverInfoListMutex)
   {
      /* Wait for Access to the Driver Information List.                */
      if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
      {
         /* Free the List and ALL Its Resources.                        */
         FreeDriverList(&DriverInfoList);
      }

      /* De-allocate the Mutex that guards list to the VNET Driver      */
      /* Information List.                                              */
      BTPS_CloseMutex(DriverInfoListMutex);
   }

   /* Clear All variables to NULL just to be safe.                      */
   DriverInfoList          = NULL;

   /* Flag Module as NOT being intialized.                              */
   DriverInfoListMutex     = NULL;
}

   /* The following function is responsible for changing the current    */
   /* Ethernet Address that is being used by the specified Virtual      */
   /* Network Driver.  The first parameter to this function specifies   */
   /* the Virtual Network Driver Index of the Actual virtual Network    */
   /* Driver in the system.  The second parameter specifies the actual  */
   /* Ethernet Address to use for the specified Driver (based on the    */
   /* first parameter).  This function returns a negative value on      */
   /* failure.                                                          */
int ConfigureVNETEthernetAddress(unsigned int VNETIndex, VNET_Ethernet_Address_t EthernetAddress)
{
   int                     ret_val;
   int                     Handle;
   int                     SocketFD;
   char                    DeviceName[32];
   DriverInfo_t           *DriverInfo;
   struct ifreq            InterfaceRequest;
  VNET_Ethernet_Address_t  CurrentEthernetAddress;

   /* Check to make sure that the VNET Driver module has been previously*/
   /* initialized.                                                      */
   if(!DriverInfoListMutex)
      InitializeVNETDriver();

   /* Initialize the return value to indicate that an error has         */
   /* occurred.                                                         */
   ret_val = VNET_DRIVER_ERROR_UNKNOWN;
   Handle  = 0;

   /* Wait for Access to the Driver Information List.                   */
   if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
   {
      /* Is there a VNDIS driver that uses this index currently open?   */
      /* ("open" = present in the device instance list) If so, fail out.*/
      DriverInfo = SearchDriverEntryByVNETIndex(&DriverInfoList, VNETIndex);

      /* Release the Mutex that we acquired earlier.                    */
      BTPS_ReleaseMutex(DriverInfoListMutex);

      /* This function should be called before the device is opened for */
      /* general use.  If a reference to the device is located, then we */
      /* will fail the request.                                         */
      ret_val = VNET_DRIVER_ERROR_WRITING_TO_DEVICE;

      /* Check to see if information about this device was located.     */
      if(!DriverInfo)
      {
         /* Try to Open the port for Non-Blocking Reading/Writing.      */
         sprintf(DeviceName, "/dev/%s%u", SS1VNET_DEVICE_NAME, VNETIndex);
         Handle = open(DeviceName, O_RDWR | O_NONBLOCK);
         if(Handle > 0)
         {
            /* Make a call to the driver to get the address.            */
            if(ioctl(Handle, VNET_IOCTL_QUERY_ETHERNET_ADDRESS, &CurrentEthernetAddress) >= 0)
            {
               /* Check to see if the addess is already set to the      */
               /* correct address.                                      */
               if(!VNET_COMPARE_ADDRESSES(CurrentEthernetAddress, EthernetAddress))
               {
                  /* Make a call to the driver to set the address.      */
                  if(ioctl(Handle, VNET_IOCTL_SET_ETHERNET_ADDRESS, &EthernetAddress) >= 0)
                  {
                     /* Attempt to reset the interface.  Create a       */
                     /* channel to the NET kernel.                      */
                     SocketFD = socket(AF_INET, SOCK_DGRAM, 0);
                     if(SocketFD >= 0)
                     {
                        /* Get the Flags for the interface.             */
                        sprintf(InterfaceRequest.ifr_name, "%s%u", SS1VNET_INTERFACE_NAME, VNETIndex);
                        if(ioctl(SocketFD, SIOCGIFFLAGS, &InterfaceRequest) >= 0)
                        {
                           /* Clear the UP Flag to bring the interface  */
                           /* down.                                     */
                           InterfaceRequest.ifr_flags &= ~(IFF_UP);
                           if(ioctl(SocketFD, SIOCSIFFLAGS, &InterfaceRequest) >= 0)
                           {
                              /* Clear the UP Flag to bring the         */
                              /* interface down.  Bring the interface   */
                              /* back up.                               */
                              InterfaceRequest.ifr_flags |= (IFF_UP | IFF_RUNNING);
                              if(ioctl(SocketFD, SIOCSIFFLAGS, &InterfaceRequest) >= 0)
                              {
                                 ret_val = 0;
                              }
                           }
            	         }
                     }
                  }

               }
               else
                  ret_val = 0;
            }
            /* We are finished with the device so close the connection. */
            close(Handle);
         }
      }
   }

   /* Return the result to the caller.                                  */
   return(ret_val);
}

   /* The following function is responsible for Opening a virtual       */
   /* Network Driver with the specified Index.  The first parameter to  */
   /* this function specifies the Virtual Network Driver Index of the   */
   /* Actual virtual Network Driver in the system.  The second and third*/
   /* parameters specify the VNET Driver Callback function that is to be*/
   /* called when a VNET Event Occurs.  All parameters to this function */
   /* *MUST* be specified.  If this function is successful, the caller  */
   /* will receive a non-zero, non-negative return value which serves as*/
   /* the VNETDriverID parameter for all other functions in the VNET    */
   /* Driver.  Since all VNET functions require a valid VNET Driver ID, */
   /* this function must be called successfully before any other        */
   /* function can be called.  If this function fails then the return   */
   /* value is a negative error code (see error codes above).           */
   /* * NOTE * If this function call is successful, no Ethernet Packets */
   /*          can be sent or received, until the Ethernet Connected    */
   /*          State is set to connected.                               */
   /*          The SetVNETEthernetConnectedState() function is used     */
   /*          for this purpose.  In other words, the default Ethernet  */
   /*          Connected State is disconnected (i.e. no Ethernet Packets*/
   /*          can be sent/received).                                   */
int OpenVNETDriver(unsigned int VNETIndex, VNET_Driver_Callback_t VNETCallback, unsigned long CallbackParameter)
{
   int            ret_val;
   char           DeviceName[64];
   Event_t        ThreadInitializedEvent;
   pthread_attr_t ThreadAttributes;

   /* Check to make sure that the VNET Driver module has been previously*/
   /* initialized.                                                      */
   if(!DriverInfoListMutex)
      InitializeVNETDriver();

   /* Make sure that the passed in parameters appear to be at least     */
   /* semi-valid.                                                       */
   if((DriverInfoListMutex) && (VNETCallback))
   {
      /* Wait for Access to the Driver Information List.                */
      if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
      {
         /* Initialize the Common Element among the VNET Drivers.       */
         /* * NOTE * This variable is a global variable (to this        */
         /*          module) that is used so we can pass information to */
         /*          the Receive VNET Thread.                           */
         BTPS_MemInitialize(&ThreadInfo, 0, sizeof(ThreadInfo));

         ThreadInfo.VNETHandle              = -1;
         ThreadInfo.DriverID                = GetNextDriverID();
         ThreadInfo.DeleteDriver            = FALSE;
         ThreadInfo.VNETThreadHandle        = 0;
         ThreadInfo.CallbackThreadHandle    = 0;
         ThreadInfo.DriverCallbackFunction  = VNETCallback;
         ThreadInfo.DriverCallbackParameter = CallbackParameter;
         ThreadInfo.NextDriverInfoPtr       = NULL;

         /* Make sure that a Mutex can be created to guard access to the*/
         /* Actual Driver Information itself.                           */
         if((ThreadInfo.DriverMutex = BTPS_CreateMutex(FALSE)) != NULL)
         {
            /* Try to Open the port for Non-Blocking Reading/Writing.   */
            sprintf(DeviceName, "/dev/%s%u", SS1VNET_DEVICE_NAME, VNETIndex);
            if((ThreadInfo.VNETHandle = open(DeviceName, O_RDWR | O_NONBLOCK)) > 0)
            {
               /* Initialize the Return Value.                          */
               ret_val = VNET_DRIVER_ERROR_UNKNOWN;

               /* Create the Event to signal Thread Initialization      */
               /* Complete.                                             */
               if((ThreadInitializedEvent = BTPS_CreateEvent(FALSE)) != NULL)
               {
                  /* Next, create a Thread to handle the VNET Events.   */
                  if(!pthread_attr_init(&ThreadAttributes))
                  {
                     /* The thread attribute structure was successfully */
                     /* initialized, now set the stack size to be the   */
                     /* passed stack size.                              */
                     if(!pthread_attr_setstacksize(&ThreadAttributes, VNET_THREAD_STACK_SIZE))
                     {
                        /* The stack size has been successfully set, now*/
                        /* create the thread.                           */
                        if(!pthread_create(&(ThreadInfo.VNETThreadHandle), &ThreadAttributes, ReceiveVNETThread, ThreadInitializedEvent))
                        {
                           /* Now wait for the Thread to signal         */
                           /* Initialization Completion.                */
                           if(BTPS_WaitEvent(ThreadInitializedEvent, BTPS_INFINITE_WAIT))
                           {
                              /* Check the result of the Thread         */
                              /* Initialization.                        */
                              if(!ThreadInitializedResult)
                              {
                                 /* OK, all finished with               */
                                 /* initialization, so let's Add the    */
                                 /* Driver Entry to the list.           */
                                 if(AddDriverEntry(&DriverInfoList, &ThreadInfo))
                                    ret_val = ThreadInfo.DriverID;
                              }
                           }
                        }
                     }

                     /* Clean up resources used to create the thread.   */
                     pthread_attr_destroy(&ThreadAttributes);
                  }

                  /* Release the Event now that we are through with it. */
                  BTPS_CloseEvent(ThreadInitializedEvent);
               }
            }
            else
               ret_val = VNET_DRIVER_ERROR_UNKNOWN;

            /* If there was an error, clean up the driver resources that*/
            /* were allocated up to this point.                         */
            if(ret_val < 0)
            {
               FreeDriverStructureResources(&ThreadInfo);
            }
         }
         else
            ret_val = VNET_DRIVER_ERROR_UNKNOWN;

         /* Release the Mutex that we acquired earlier.                 */
         BTPS_ReleaseMutex(DriverInfoListMutex);
      }
      else
         ret_val = VNET_DRIVER_ERROR_UNKNOWN;
   }
   else
      ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

   /* Return the result to the caller.                                  */
   return(ret_val);
}

   /* The following function is responsible for Closing the Virtual     */
   /* Network Driver that was opened via a successful call to the       */
   /* OpenVETSDriver() function.  The Input parameter to this function  */
   /* MUST have been acquired by a successful call to OpenVNETDriver(). */
   /* Once this function completes, the Virtual Network Driver that was */
   /* closed cannot be accessed again (sending/receiving data) by this  */
   /* module until the Driver is Re-Opened by calling the               */
   /* OpenVNETDriver() function.                                        */
void CloseVNETDriver(unsigned int VNETDriverID)
{
   DriverInfo_t *DriverInfo;

   /* Make sure that the passed in parameter seems semi-valid.          */
   if((DriverInfoListMutex) && (VNETDriverID))
   {
      /* Wait for Access to the Driver Information List.                */
      if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
      {
         if((DriverInfo = SearchDriverEntryByDriverID(&DriverInfoList, VNETDriverID)) != NULL)
         {
            /* We need to determine if we have been called in the       */
            /* context of a Callback Routine.  If we have, then we      */
            /* simply need to flag this driver for deletion and return. */
            if(pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
            {
               DriverInfo->DeleteDriver = TRUE;

               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);
            }
            else
            {
               /* Delete the specified Driver from the List.            */
               if((DriverInfo = DeleteDriverEntry(&DriverInfoList, VNETDriverID)) != NULL)
               {
                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);

                  /* Free All Resources associated with this VNET       */
                  /* Driver.                                            */
                  FreeDriverStructureResources(DriverInfo);

                  /* Finally Free the Memory that was associated with   */
                  /* this VNET Driver Information List Entry.           */
                  FreeDriverEntryMemory(DriverInfo);
               }
               else
               {
                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);
               }
            }
         }
         else
         {
            /* Release the Mutex that we acquired earlier.              */
            BTPS_ReleaseMutex(DriverInfoListMutex);
         }
      }
   }
}

   /* The following function is responsible for querying the current    */
   /* Ethernet Address that is being used by the specified Virtual      */
   /* Network Driver.  The VNETDriverID parameter that is passed to this*/
   /* function MUST have been established via a successful call to the  */
   /* OpenVNETDriver() function.  The final parameter to this function  */
   /* is a pointer to a buffer that will hold the current Ethernet      */
   /* Address of the Virtual Network Driver (if this function is        */
   /* successful).  This function returns zero if successful or a       */
   /* negative return error code if there was an error.  If this        */
   /* function is successful then the buffer pointed to by the          */
   /* EthernetAddress parameter will contain the currently opened       */
   /* Virtual Network Driver.  If this function is unsuccessful then the*/
   /* contents of the EthernetAddress parameter buffer will be          */
   /* undefined.                                                        */
int QueryVNETEthernetAddress(unsigned int VNETDriverID, VNET_Ethernet_Address_t *EthernetAddress)
{
   int           ret_val;
   Mutex_t       DriverMutex;
   Boolean_t     MutexAcquired;
   DriverInfo_t *DriverInfo;

   /* Make sure that the passed in parameter seems semi-valid.          */
   if((DriverInfoListMutex) && (VNETDriverID))
   {
      /* Let's make sure that the Data Buffer Parameter appears to be   */
      /* semi-valid.                                                    */
      if(EthernetAddress)
      {
         /* Wait for Access to the Driver Information List.             */
         if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
         {
            if((DriverInfo = SearchDriverEntryByDriverID(&DriverInfoList, VNETDriverID)) != NULL)
            {
               if(pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
               {
                  MutexAcquired = TRUE;

                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);
               }
               else
               {
                  /* Note the Driver Mutex that protects the Driver.    */
                  DriverMutex = DriverInfo->DriverMutex;

                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);

                  /* Acquire the Mutex that protects this actual VNET   */
                  /* Driver.                                            */
                  if((DriverMutex) && (BTPS_WaitMutex(DriverMutex, BTPS_INFINITE_WAIT)))
                     MutexAcquired = TRUE;
                  else
                     MutexAcquired = FALSE;
               }

               if(MutexAcquired)
               {
                  /* All that's left to do is simply send the Data to   */
                  /* the Driver.                                        */
                  if(!ioctl(DriverInfo->VNETHandle, VNET_IOCTL_QUERY_ETHERNET_ADDRESS, EthernetAddress))
                     ret_val = 0;
                  else
                     ret_val = VNET_DRIVER_ERROR_READING_FROM_DEVICE;

                  /* Release the Mutex that is related to this specific */
                  /* VNET Driver (if it was acquired).                  */
                  if(!pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
                     BTPS_ReleaseMutex(DriverInfo->DriverMutex);
               }
               else
               {
                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);

                  ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
               }
            }
            else
            {
               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);

               ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
            }
         }
         else
            ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
      }
      else
         ret_val = VNET_DRIVER_ERROR_INVALID_PARAMETER;
   }
   else
      ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

   /* Return the result to the caller.                                  */
   return(ret_val);
}

   /* The following function is responsible for specifying the current  */
   /* Ethernet Connected State that is to be used by the specified      */
   /* Virtual Network Driver.  The VNETDriverID parameter that is passed*/
   /* to this function MUST have been established via a successful call */
   /* to the OpenVNETDriver() function.  The final parameter to this    */
   /* function is a BOOLEAN parameter that specifies whether or not the */
   /* Ethernet Cable is connected (TRUE) or disconnected (FALSE).  This */
   /* function returns zero if successful or a negative return error    */
   /* code if there was an error.                                       */
   /* * NOTE * This function has to be called with the second parameter */
   /*          set to TRUE (connected) before ANY Ethernet Packets can  */
   /*          be sent or received.                                     */
   /* * NOTE * When the Ethernet Connected State is disconnected, no    */
   /*          Ethenet Packets can be sent or received.                 */
int SetVNETEthernetConnectedState(unsigned int VNETDriverID, Boolean_t Connected)
{
   int           ret_val;
   int           State;
   Mutex_t       DriverMutex;
   Boolean_t     MutexAcquired;
   DriverInfo_t *DriverInfo;

   /* Make sure that the passed in parameter seems semi-valid.          */
   if((DriverInfoListMutex) && (VNETDriverID))
   {
      /* Wait for Access to the Driver Information List.                */
      if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
      {
         if((DriverInfo = SearchDriverEntryByDriverID(&DriverInfoList, VNETDriverID)) != NULL)
         {
            if(pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
            {
               MutexAcquired = TRUE;

               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);
            }
            else
            {
               /* Note the Driver Mutex that protects the Driver.       */
               DriverMutex = DriverInfo->DriverMutex;

               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);

               /* Acquire the Mutex that protects this actual VNET      */
               /* Driver.                                               */
               if((DriverMutex) && (BTPS_WaitMutex(DriverMutex, BTPS_INFINITE_WAIT)))
                  MutexAcquired = TRUE;
               else
                  MutexAcquired = FALSE;
            }

            if(MutexAcquired)
            {
               /* Convret the Connected Boolean to an integer.          */
               State = (Connected)?1:0;

               /* All that's left to do is simply set the new connected */
               /* state with the Driver.                                */
               if(!ioctl(DriverInfo->VNETHandle, VNET_IOCTL_SET_ETHERNET_CONNECTED_STATUS, &State))
                  ret_val = 0;
               else
                  ret_val = VNET_DRIVER_ERROR_WRITING_TO_DEVICE;

               /* Release the Mutex that is related to this specific    */
               /* VNET Driver (if it was acquired).                     */
               if(!pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
                  BTPS_ReleaseMutex(DriverInfo->DriverMutex);
            }
            else
            {
               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);

               ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
            }
         }
         else
         {
            /* Release the Mutex that we acquired earlier.              */
            BTPS_ReleaseMutex(DriverInfoListMutex);

            ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
         }
      }
      else
         ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
   }
   else
      ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

   /* Return the result to the caller.                                  */
   return(ret_val);
}

   /* The following function is responsible for sending an Ethernet     */
   /* Packet to the specified Virtual Network Driver.  The VNETDriverID */
   /* parameter that is passed to this function MUST have been          */
   /* established via a successful call to the OpenVNETDriver()         */
   /* function.  The remaining parameters to this function are the      */
   /* Ethernet Packet Header to use for the packety, followed by the    */
   /* Length of the Data to send and a pointer to the Data Buffer to    */
   /* Send (Payload only).  This function returns zero if successful, or*/
   /* a negative return error code if unsuccessful.                     */
   /* * NOTE * If the Ethernet Connected State is disconnected, then no */
   /*          Ethernet packets will be passed through the Virtual      */
   /*          Network Driver.  The Ethernet connected state is set via */
   /*          a call to the SetVNETEthernetConnectedState() function.  */
   /* * NOTE * The default state of the Ethernet Connected State is     */
   /*          disconnected.                                            */
int WriteVNETEthernetPacket(unsigned int VNETDriverID, VNET_Ethernet_Header_t *EthernetHeader, unsigned int PayloadLength, unsigned char *PayloadBuffer)
{
   int            ret_val;
   Mutex_t        DriverMutex;
   Boolean_t      MutexAcquired;
   DriverInfo_t  *DriverInfo;
   unsigned char *PacketData;

   /* Make sure that the passed in parameter seems semi-valid.          */
   if((DriverInfoListMutex) && (VNETDriverID))
   {
      /* Let's make sure that the Data Buffer Parameters appear to be   */
      /* semi-valid.                                                    */
      if((EthernetHeader) && (PayloadLength) && (PayloadBuffer))
      {
         /* Wait for Access to the Driver Information List.             */
         if(BTPS_WaitMutex(DriverInfoListMutex, BTPS_INFINITE_WAIT))
         {
            if((DriverInfo = SearchDriverEntryByDriverID(&DriverInfoList, VNETDriverID)) != NULL)
            {
               if(pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
               {
                  MutexAcquired = TRUE;

                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);
               }
               else
               {
                  /* Note the Driver Mutex that protects the Driver.    */
                  DriverMutex = DriverInfo->DriverMutex;

                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);

                  /* Acquire the Mutex that protects this actual VNET   */
                  /* Driver.                                            */
                  if((DriverMutex) && (BTPS_WaitMutex(DriverMutex, BTPS_INFINITE_WAIT)))
                     MutexAcquired = TRUE;
                  else
                     MutexAcquired = FALSE;
               }

               if(MutexAcquired)
               {
                  /* Next, we need to format up the Ethernet Header     */
                  /* followed by the Payload Information so that we can */
                  /* send the Ethernet Packet to the virtual NDIS       */
                  /* Driver.                                            */
                  if((PacketData = (unsigned char *)BTPS_AllocateMemory(PayloadLength + ETHERNET_HEADER_SIZE)) != NULL)
                  {
                     /* Now that we have allocated all required memory, */
                     /* we need to format the Ethernet Header, followed */
                     /* by the Payload data.                            */
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 0] = EthernetHeader->DestinationAddress.Address0;
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 1] = EthernetHeader->DestinationAddress.Address1;
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 2] = EthernetHeader->DestinationAddress.Address2;
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 3] = EthernetHeader->DestinationAddress.Address3;
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 4] = EthernetHeader->DestinationAddress.Address4;
                     PacketData[ETHERNET_HEADER_DESTINATION_ADDRESS_OFFSET + 5] = EthernetHeader->DestinationAddress.Address5;

                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 0]      = EthernetHeader->SourceAddress.Address0;
                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 1]      = EthernetHeader->SourceAddress.Address1;
                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 2]      = EthernetHeader->SourceAddress.Address2;
                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 3]      = EthernetHeader->SourceAddress.Address3;
                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 4]      = EthernetHeader->SourceAddress.Address4;
                     PacketData[ETHERNET_HEADER_SOURCE_ADDRESS_OFFSET + 5]      = EthernetHeader->SourceAddress.Address5;

                     PacketData[ETHERNET_HEADER_TYPE_FIELD_OFFSET + 0]          = (unsigned char)(EthernetHeader->EthernetTypeField >> 8);
                     PacketData[ETHERNET_HEADER_TYPE_FIELD_OFFSET + 1]          = (unsigned char)(EthernetHeader->EthernetTypeField & 0xFF);

                     BTPS_MemCopy(&(PacketData[ETHERNET_HEADER_SIZE]), PayloadBuffer, PayloadLength);

                     /* All that's left to do is simply send the Data to*/
                     /* the Driver.                                     */
                     if((ret_val = write(DriverInfo->VNETHandle, PacketData, PayloadLength + ETHERNET_HEADER_SIZE)) > 0)
                        ret_val = 0;
                     else
                        ret_val = VNET_DRIVER_ERROR_WRITING_TO_DEVICE;

                     /* Free the Packet Data memory that was allocated  */
                     /* because we are finished with it.                */
                     BTPS_FreeMemory(PacketData);
                  }
                  else
                     ret_val = VNET_DRIVER_ERROR_WRITING_TO_DEVICE;

                  /* Release the Mutex that is related to this specific */
                  /* VNET Driver (if it was acquired).                  */
                  if(!pthread_equal(DriverInfo->VNETThreadHandle, pthread_self()))
                     BTPS_ReleaseMutex(DriverInfo->DriverMutex);
               }
               else
               {
                  /* Release the Mutex that we acquired earlier.        */
                  BTPS_ReleaseMutex(DriverInfoListMutex);

                  ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
               }
            }
            else
            {
               /* Release the Mutex that we acquired earlier.           */
               BTPS_ReleaseMutex(DriverInfoListMutex);

               ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
            }
         }
         else
            ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;
      }
      else
         ret_val = VNET_DRIVER_ERROR_INVALID_PARAMETER;
   }
   else
      ret_val = VNET_DRIVER_ERROR_INITIALIZING_DRIVER;

   /* Return the result to the caller.                                  */
   return(ret_val);
}

