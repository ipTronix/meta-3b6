#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6cc749b3, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xb6b46a7c, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0xa95d83b9, __VMLINUX_SYMBOL_STR(register_netdev) },
	{ 0x208725cd, __VMLINUX_SYMBOL_STR(alloc_netdev_mqs) },
	{ 0xe60f5930, __VMLINUX_SYMBOL_STR(cdev_add) },
	{ 0x8712e3b7, __VMLINUX_SYMBOL_STR(cdev_init) },
	{ 0x33ddbf36, __VMLINUX_SYMBOL_STR(device_create) },
	{ 0x275ef902, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x1ba3f252, __VMLINUX_SYMBOL_STR(__class_create) },
	{ 0x29537c9e, __VMLINUX_SYMBOL_STR(alloc_chrdev_region) },
	{ 0x12da5bb2, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0x396f2d17, __VMLINUX_SYMBOL_STR(netif_rx_ni) },
	{ 0x426ed22, __VMLINUX_SYMBOL_STR(eth_type_trans) },
	{ 0xce474a58, __VMLINUX_SYMBOL_STR(skb_put) },
	{ 0xd09bb0af, __VMLINUX_SYMBOL_STR(__netdev_alloc_skb) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x16305289, __VMLINUX_SYMBOL_STR(warn_slowpath_null) },
	{ 0x676bbc0f, __VMLINUX_SYMBOL_STR(_set_bit) },
	{ 0xec85999f, __VMLINUX_SYMBOL_STR(__netif_schedule) },
	{ 0x2a3aa678, __VMLINUX_SYMBOL_STR(_test_and_clear_bit) },
	{ 0x93abfe1a, __VMLINUX_SYMBOL_STR(try_module_get) },
	{ 0x2e61e88d, __VMLINUX_SYMBOL_STR(module_put) },
	{ 0xd85cd67e, __VMLINUX_SYMBOL_STR(__wake_up) },
	{ 0x1cfb04fa, __VMLINUX_SYMBOL_STR(finish_wait) },
	{ 0x344b7739, __VMLINUX_SYMBOL_STR(prepare_to_wait_event) },
	{ 0x1000e51, __VMLINUX_SYMBOL_STR(schedule) },
	{ 0xfbc74f64, __VMLINUX_SYMBOL_STR(__copy_from_user) },
	{ 0x67c2fa54, __VMLINUX_SYMBOL_STR(__copy_to_user) },
	{ 0x7ffc8ea5, __VMLINUX_SYMBOL_STR(netif_carrier_on) },
	{ 0x49ebacbd, __VMLINUX_SYMBOL_STR(_clear_bit) },
	{ 0x8a368488, __VMLINUX_SYMBOL_STR(netif_carrier_off) },
	{ 0xfa2a45e, __VMLINUX_SYMBOL_STR(__memzero) },
	{ 0x4be7fb63, __VMLINUX_SYMBOL_STR(up) },
	{ 0x1afae5e7, __VMLINUX_SYMBOL_STR(down_interruptible) },
	{ 0x3f40a731, __VMLINUX_SYMBOL_STR(ether_setup) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x7485e15e, __VMLINUX_SYMBOL_STR(unregister_chrdev_region) },
	{ 0x96debf71, __VMLINUX_SYMBOL_STR(class_destroy) },
	{ 0x688926d2, __VMLINUX_SYMBOL_STR(device_destroy) },
	{ 0x9764d02f, __VMLINUX_SYMBOL_STR(free_netdev) },
	{ 0xc96d4573, __VMLINUX_SYMBOL_STR(unregister_netdev) },
	{ 0x51d559d1, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_irqrestore) },
	{ 0x89410f05, __VMLINUX_SYMBOL_STR(__dev_kfree_skb_any) },
	{ 0x598542b2, __VMLINUX_SYMBOL_STR(_raw_spin_lock_irqsave) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "7E167C9D9791A0446EE0206");
