/*****< btpsfile.h >***********************************************************/
/*      Copyright 2008 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPSFILE - Stonestreet One Bluetooth Stack File Access Abstraction        */
/*             Implementation for Linux.                                      */
/*                                                                            */
/*  Author:  David Wooldridge                                                 */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   03/05/08  D. Wooldridge  Initial implementation.                         */
/*   06/17/09  D. Lange       Updated to support new API type schema.         */
/******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include "BTPSFILE.h"           /* BTPS File I/O Prototypes/Constants.        */
#include "BTPSKRNL.h"           /* BTPS Kernel Prototypes/Constants.          */

   /* The following function is provided to allow a mechanism for the   */
   /* caller to create a directory.  The parameter to this function     */
   /* specifies the (path qualified) directory name to create.  This    */
   /* function returns one of the following:                            */
   /*    - BTPS_FILE_MAKE_DIRECTORY_SUCCESS                             */
   /*    - BTPS_FILE_MAKE_DIRECTORY_ERROR_ALREADY_EXISTS                */
   /*    - BTPS_FILE_MAKE_DIRECTORY_ERROR_UNABLE_TO_CREATE              */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
int BTPSAPI BTPS_Make_Directory(BTPSCONST char *Path)
{
   int ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      ret_val = ((!mkdir(Path, (S_IRWXG | S_IRWXU | S_IRWXO)))?BTPS_FILE_MAKE_DIRECTORY_SUCCESS:BTPS_FILE_MAKE_DIRECTORY_ERROR_UNABLE_TO_CREATE);

      /* If the Creation of the Directory failed, we need to check if it*/
      /* failed because of the Directory already existing.  If the      */
      /* Directory did already exist, then we need flag the Creation as */
      /* successful.                                                    */
      /* * NOTE * We are doing this because OBEX claims that most       */
      /*          implementations behave in this manner.                */
      if((ret_val == BTPS_FILE_MAKE_DIRECTORY_ERROR_UNABLE_TO_CREATE) && (errno == EEXIST))
         ret_val = BTPS_FILE_MAKE_DIRECTORY_ERROR_ALREADY_EXISTS;
   }
   else
      ret_val = BTPS_FILE_MAKE_DIRECTORY_ERROR_UNABLE_TO_CREATE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechanism for the   */
   /* caller to delete a specified file .  The parameter to this        */
   /* function specifies the (path qualified) file name to delete.  This*/
   /* function returns a BOOLEAN TRUE if successful, or FALSE if an     */
   /* error occurred.                                                   */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
Boolean_t BTPSAPI BTPS_Delete_File(BTPSCONST char *Path)
{
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      if(!unlink(Path))
         ret_val = TRUE;
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechanism for the   */
   /* caller to delete a specified directory.  The parameter to this    */
   /* function specifies the (path qualified) directory name to delete. */
   /* This function returns a BOOLEAN TRUE if successful, or FALSE if an*/
   /* error occurred.                                                   */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
Boolean_t BTPSAPI BTPS_Delete_Directory(BTPSCONST char *Path)
{
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      if(!rmdir(Path))
         ret_val = TRUE;
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechanism for the   */
   /* caller to open a file (of the specified file name).  This first   */
   /* parameter to this function specifies the (path qualified) name of */
   /* the file to open.  The final parameter specifies the mode that    */
   /* the file is to be opened with.  The supported modes are:          */
   /*   - omReadOnly  - open for read only access                       */
   /*   - omWriteOnly - open for write only access                      */
   /*   - omReadWrite - open for read/write access                      */
   /*   - omCreate    - create new file (truncate if already exists)    */
   /*   - omAppend    - open for writing (create if doesn't exist)      */
   /* This function returns a NON-NULL File Descriptor if the specified */
   /* file was opened successfully, or NULL if there was an error.      */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
BTPS_File_Descriptor_t BTPSAPI BTPS_Open_File(BTPSCONST char *Path, BTPS_Open_Mode_t OpenMode)
{
   int                    FileDescriptor;
   int                    Flags;
   int                    Access;
   BTPS_File_Descriptor_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      /* Next, map the specified Open Mode to the correct Read/Write    */
      /* Flags.                                                         */
      switch(OpenMode)
      {
         case omReadOnly:
            Flags  = O_NONBLOCK | O_RDONLY;
            Access = 0;
            break;
         case omWriteOnly:
            Flags  = O_NONBLOCK | O_WRONLY;
            Access = S_IRWXG    | S_IRWXU | S_IRWXO;
            break;
         case omReadWrite:
            Flags  = O_NONBLOCK | O_RDWR;
            Access = S_IRWXG    | S_IRWXU | S_IRWXO;
            break;
         case omCreate:
            Flags  = O_NONBLOCK | O_TRUNC | O_CREAT  | O_WRONLY;
            Access = S_IRWXG    | S_IRWXU | S_IRWXO;
            break;
         case omAppend:
            Flags  = O_NONBLOCK | O_APPEND | O_CREAT | O_WRONLY;
            Access = S_IRWXG    | S_IRWXU  | S_IRWXO;
            break;
         default:
            Flags = 0;
            break;
      }

      /* If the mode specified was valid, go ahead and attempt to open  */
      /* the specified file for reading/writing.                        */
      if(Flags)
      {
         if((FileDescriptor = open(Path, Flags, Access)) >= 0)
         {
            /* Seek to the end of the File (for appending) if append was*/
            /* specified.                                               */
            if(OpenMode == omAppend)
               BTPS_Seek_File((BTPS_File_Descriptor_t)FileDescriptor, smEnd, 0);

            ret_val = (BTPS_File_Descriptor_t)FileDescriptor;
         }
         else
            ret_val = NULL;
      }
      else
         ret_val = NULL;
   }
   else
      ret_val = NULL;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to close a file that was previously successfully opened via*/
   /* the BTPS_Open_File() function.  This function accepts as the first*/
   /* parameter the NON-NULL File Descriptor (successful return value   */
   /* from the BTPS_Open_File() function).                              */
void BTPSAPI BTPS_Close_File(BTPS_File_Descriptor_t FileDescriptor)
{
   /* If a semi-valid File Descriptor was specified, go ahead and close */
   /* it.                                                               */
   if(FileDescriptor)
      close((int)FileDescriptor);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to seek to specific byte offset within the specified file. */
   /* The first parameter specifies the file descriptor of the          */
   /* previously opened file (via the BTPS_Open_File() function).  The  */
   /* second parameter specifies the location to apply the Seek Offset  */
   /* to (final parameter).  The values that this parameter can be is   */
   /* one of the following:                                             */
   /*   - smBeginning - Apply SeekOffset from beginning of file         */
   /*   - smCurrent   - Apply SeekOffset from current location in file  */
   /*   - smEnd       - Apply SeekOffset from end of file               */
   /* The final parameter, SeekOffset, specifies the offset (in bytes)  */
   /* to seek (taking into account the Seek Mode type - second          */
   /* parameter).  This function will return BOOLEAN TRUE if successful */
   /* or a FALSE if there was an error.                                 */
Boolean_t BTPSAPI BTPS_Seek_File(BTPS_File_Descriptor_t FileDescriptor, BTPS_Seek_Mode_t SeekMode, SDWord_t SeekOffset)
{
   DWord_t   MappedSeekMode;
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if(FileDescriptor)
   {
      /* Next map the specified Seek Mode to the native Seek Mode.      */
      switch(SeekMode)
      {
         case smBeginning:
            MappedSeekMode = SEEK_SET;
            break;
         case smCurrent:
            MappedSeekMode = SEEK_CUR;
            break;
         case smEnd:
            MappedSeekMode = SEEK_END;
            break;
         default:
            MappedSeekMode = (SEEK_SET + SEEK_CUR + SEEK_END);
            break;
      }

      /* If the Seek Mode specified was valid, go ahead and attempt to  */
      /* set the file position.                                         */
      if(MappedSeekMode != (SEEK_SET + SEEK_CUR + SEEK_END))
      {
         if(lseek((int)FileDescriptor, SeekOffset, MappedSeekMode) >= 0)
            ret_val = TRUE;
         else
            ret_val = FALSE;
      }
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to read data from a previously opened file.  The first     */
   /* parameter specifies the file descriptor of the previously opened  */
   /* file (via the BTPS_Open_File() function).  The second parameter   */
   /* specifies the number of bytes to read from the file.  The third   */
   /* parameter specifies the Buffer to read the data into (must be     */
   /* (at least) as many bytes as specified by the second parameter).   */
   /* The final parameter is optional, and if specified, points to a    */
   /* buffer that will contain (on success) the number of bytes that    */
   /* were actually read and placed into the buffer.  This function     */
   /* returns BOOLEAN TRUE if the data was successfully read or a       */
   /* BOOLEAN FALSE if an error occurred.                               */
Boolean_t BTPSAPI BTPS_Read_File(BTPS_File_Descriptor_t FileDescriptor, DWord_t BufferSize, Byte_t *Buffer, DWord_t *BytesRead)
{
   DWord_t   ActualBytesRead;
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((FileDescriptor) && (BufferSize) && (Buffer))
   {
      /* Input parameters appear to be valid, go ahead and attempt to   */
      /* read the specified data into the specified buffer.             */
      if(!((ActualBytesRead = read((int)FileDescriptor, Buffer, BufferSize)) & 0x80000000))
      {
         /* Data read successfully, go ahead and return the bytes       */
         /* actually read if the caller requested the count.            */
         if(BytesRead)
            *BytesRead = ActualBytesRead;

         /* Flag success to the caller.                                 */
         ret_val = TRUE;
      }
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to write data to a previously opened file.  The first      */
   /* parameter specifies the file descriptor of the previously opened  */
   /* file (via the BTPS_Open_File() function).  The second parameter   */
   /* specifies the number of bytes to write to the file.  The third    */
   /* parameter specifies the Buffer that contains the bytes to write to*/
   /* the file (must be (at least) as many bytes as specified by the    */
   /* second parameter).  The final parameter is optional, and if       */
   /* specified, points to a buffer that will contain (on success) the  */
   /* number of bytes that were actually written to the file.  This     */
   /* function returns BOOLEAN TRUE if the data was successfully read or*/
   /* a BOOLEAN FALSE if an error occurred.                             */
Boolean_t BTPSAPI BTPS_Write_File(BTPS_File_Descriptor_t FileDescriptor, DWord_t BufferSize, Byte_t *Buffer, DWord_t *BytesWritten)
{
   DWord_t   ActualBytesWritten;
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((FileDescriptor) && (BufferSize) && (Buffer))
   {
      /* Input parameters appear to be valid, go ahead and attempt to   */
      /* write the specified data into the specified buffer.            */
      if(!((ActualBytesWritten = write((int)FileDescriptor, Buffer, BufferSize)) & 0x80000000))
      {
         /* Data written successfully, go ahead and return the bytes    */
         /* actually written if the caller requested the count.         */
         if(BytesWritten)
            *BytesWritten = ActualBytesWritten;

         /* Flag success to the caller.                                 */
         ret_val = TRUE;
      }
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to begin the process of iterating through the directory    */
   /* specified by this function.  This is useful to iterate through all*/
   /* entries contained in the specified directory (see                 */
   /* BTPS_Get_Next_Directory_Entry() for more information).  The       */
   /* first parameter to this function specifies the (path qualified)   */
   /* directory name to open.  This function returns a NON-NULL         */
   /* directory descriptor if successful, or NULL if there as an error. */
   /* If this function returns success, then this return value can be   */
   /* passed to the BTPS_Get_Next_Directory_Entry() and the             */
   /* BTPS_Close_Directory() functions.                                 */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
BTPS_Directory_Descriptor_t BTPSAPI BTPS_Open_Directory(BTPSCONST char *Path)
{
   DIR                         *DirectoryHandle;
   BTPS_Directory_Descriptor_t  ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      if((DirectoryHandle = opendir(Path)) != NULL)
         ret_val = (BTPS_Directory_Descriptor_t)DirectoryHandle;
      else
         ret_val = NULL;
   }
   else
      ret_val = NULL;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to close a directory that was previously successfully      */
   /* opened via the BTPS_Open_Directory() function.  This function     */
   /* accepts as the first parameter the NON-NULL Directory Descriptor  */
   /* (successful return value from the BTPS_Open_Directory() function).*/
void BTPSAPI BTPS_Close_Directory(BTPS_Directory_Descriptor_t DirectoryDescriptor)
{
   /* If a semi-valid Directory Descriptor was specified, go ahead and  */
   /* close it.                                                         */
   if(DirectoryDescriptor)
      closedir((DIR *)DirectoryDescriptor);
}

   /* The following function is provided to allow a mechansim for the   */
   /* caller to interate through the directory entries contained in the */
   /* directory specified by the specified Directory Descriptor.  The   */
   /* first parameter specifies the Directory Descriptor (obtained from */
   /* a previously successful call to the BTP_Open_Directory() function)*/
   /* which specifies the directory to iterate through.  The final      */
   /* parameter specifies the last retrieved directory entry name that  */
   /* was returned from this function (to iterate to the next entry), or*/
   /* an empty string if this is the first time this function is being  */
   /* called for the specified directory.  If this function is          */
   /* successful, it will return a BOOLEAN TRUE value and the buffer    */
   /* pointed to by the final parmeter will contain the name of the next*/
   /* directory entry.  If this function returns FALSE then the contents*/
   /* of this buffer will be undefined (error occurred).                */
   /* * NOTE * The final parameter *MUST* point to a buffer that is     */
   /*          (at least) BTPS_MAXIMUM_FILE_NAME_LENGTH bytes long.     */
   /* * NOTE * The directory entry names returned from this function    */
   /*          are not path qualified (i.e. they do not contain the     */
   /*          path of the actual directory name in them).              */
   /* * NOTE * The final parameter should point to an empty string      */
   /*          (first character is a NULL character) to signify that the*/
   /*          first directory entry should be retrieved.  After this,  */
   /*          this parameter should specify the previously returned    */
   /*          directory entry name (to retrieve the next entry).       */
   /* * NOTE * The value that is returned in the final parameter will   */
   /*          be in the UTF-8 character set (NULL terminated).         */
Boolean_t BTPSAPI BTPS_Get_Next_Directory_Entry(BTPS_Directory_Descriptor_t DirectoryDescriptor, char *EntryName)
{
   Boolean_t      ret_val;
   struct dirent *DirectoryEntry;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((DirectoryDescriptor) && (EntryName))
   {
      if((DirectoryEntry = readdir((DIR *)DirectoryDescriptor)) != NULL)
      {
         if(strlen(DirectoryEntry->d_name) < BTPS_MAXIMUM_FILE_NAME_LENGTH)
         {
            strcpy(EntryName, DirectoryEntry->d_name);

            ret_val = TRUE;
         }
         else
            ret_val = FALSE;
      }
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechanism for the   */
   /* caller to determine if the specified Path, specifies the Root of  */
   /* a drive.  Examples of this function returning TRUE are:           */
   /*   - C:\ - TRUE on Windows based machines                          */
   /*   - /   - TRUE on Linux/UNIX based machines                       */
   /* This function returns a BOOLEAN TRUE if the specified Path        */
   /* specifies the root directory of a drive, or FALSE, otherwise.     */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
Boolean_t BTPSAPI BTPS_Query_Directory_Is_Root_Of_Drive(BTPSCONST char *Path)
{
   Boolean_t ret_val;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)))
   {
      /* Check to see if the Path specified equals the root.            */
      if((strlen(Path) == 1) && (Path[0] == '/'))
         ret_val = TRUE;
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

   /* The following function is provided to allow a mechanism for the   */
   /* caller to obtain File Information about a specific File or        */
   /* directory.  The first parameter to this function specifies the    */
   /* (path qualified) file or directory name to query the information  */
   /* about.  The second parameter specifies a buffer that will contain */
   /* the File/Directory information on return if this function is      */
   /* successful.  This function returns a BOOLEAN TRUE if successful,  */
   /* or FALSE if an error occurred.  Note that the final parameter is  */
   /* *CANNOT* be NULL and must point to a valid buffer to store the    */
   /* information into.  If this function returns success (TRUE) then   */
   /* this buffer will contain the file information for the specified   */
   /* input file/directory.  If this function returns an error (FALSE)  */
   /* then the contents of the buffer pointed to by the final parameter */
   /* will be undefined.                                                */
   /* * NOTE * The Path parameter should be specified in the UTF-8      */
   /*          character set.                                           */
Boolean_t BTPSAPI BTPS_Query_File_Information(BTPSCONST char *Path, BTPS_File_Information_t *FileInformation)
{
   Boolean_t    ret_val;
   struct tm   *Time;
   struct stat  FileStat;

   /* First check to make sure the input parameters appear to be        */
   /* semi-valid.                                                       */
   if((Path) && (strlen(Path)) && (FileInformation))
   {
      /* Input parameters appear to be semi-valid, go ahead and retrieve*/
      /* the information about the specified file/directory.            */
      if(!lstat(Path, &FileStat))
      {
         /* Determine if the entry is a File or Directory.              */
         FileInformation->FileType = (S_ISDIR(FileStat.st_mode))?ftDirectory:ftFile;

         /* Note the File Size.                                         */
         FileInformation->FileSize = FileStat.st_size;

         /* Convert the File Time to the System Time.                   */
         if((Time = localtime((time_t *)&(FileStat.st_mtime))) != NULL)
         {
            FileInformation->FileTime.Seconds    = Time->tm_sec;
            FileInformation->FileTime.Minute     = Time->tm_min;
            FileInformation->FileTime.Hour       = Time->tm_hour;
            FileInformation->FileTime.DayOfMonth = Time->tm_mday;
            FileInformation->FileTime.Month      = Time->tm_mon + 1;
            FileInformation->FileTime.Year       = Time->tm_year + 1900;
            FileInformation->FileTime.UTC_Time   = FALSE;

            /* Flag success to the caller.                              */
            ret_val                              = TRUE;
         }
         else
            ret_val = FALSE;
      }
      else
         ret_val = FALSE;
   }
   else
      ret_val = FALSE;

   /* Finally return the result to the caller.                          */
   return(ret_val);
}

