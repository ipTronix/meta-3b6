/*****< commprot.h >***********************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  COMMPROT - HCI Comm protocol prototypes and constants.                    */
/*                                                                            */
/*  Author:  Marcus Funk                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   3/5/13    M. Funk        Initial creation.                               */
/******************************************************************************/
#ifndef __COMMPROTH__
#define __COMMPROTH__

#include "BTTypes.h"
#include "HCITypes.h"

   /* These defines represent the possible error return codes that can  */
   /* be returned from a comm protocol function.                        */
#define COMM_PROTOCOL_ERROR_INVALID_PARAMETER    (-1)
#define COMM_PROTOCOL_ERROR_MEMORY_ALLOCATION    (-2)
#define COMM_PROTOCOL_ERROR_RESOURCE_ALLOCATION  (-3)

   /* The following enumerates the defined actions that can be required */
   /* from the HCIComm Driver for the Comm Protocols.  The              */
   /* cpeCreateTimers event can be used to create timers needed by the  */
   /* module.  These timers can then be started or restarted with the   */
   /* cpeStartTimer event, stopped with the cpeStopTimer event and      */
   /* deleted with the cpeDeleteTimers event.  The cpeTransmitData is   */
   /* used to send data out the com port and the cpeProcessPacket is    */
   /* used to further process incoming data.                            */
typedef enum
{
   cpeCreateTimers,
   cpeDeleteAllTimers,
   cpeStartTimer,
   cpeStopTimer,
   cpeTransmit,
   cpeProcessPacket,
   cpeSetTransportConfiguration
} Comm_Protocol_Event_Type_t;

   /* The following enumeration the packet types that can be is used    */
   /* with the process packet event.                                    */
typedef enum
{
   cppHCIUnknownPacket  = 0,
   cppHCICommandPacket  = 1,
   cppHCIACLDataPacket  = 2,
   cppHCISCODataPacket  = 3,
   cppHCIEventPacket    = 4,
   cppHCIAdditional     = 5,
   cppHCIVendorSpecific = 14,
   cppHCILinkControl    = 15
} Comm_Protocol_PacketType_t;

   /* The following prototype is for a function that is called when a   */
   /* timer expires.                                                    */
typedef void (BTPSAPI *Comm_Protocol_Timer_Callback_t)(unsigned long CallbackParameter);

   /* The following structure contains the information to describe a    */
   /* single timer.  It includes the Callback function, the callback    */
   /* parameter and the TimerID.                                        */
typedef struct _tagComm_Protocol_Timer_Data_t
{
   Comm_Protocol_Timer_Callback_t CallbackFunction;
   unsigned long                  CallbackParameter;
   unsigned int                   TimerID;
} Comm_Protocol_Timer_Data_t;

   /* The following structure is used with the cpeCreateTimers event    */
   /* type.  It contains the number of timers to be created and a       */
   /* pointer to a Protocol_Timer_Data_t structure that contains the    */
   /* callback function and parameter for each timer.  When the callback*/
   /* returns, the TimerID of the Protocol_Timer_Data_t structure will  */
   /* contain the Timer IDs to be used when starting or stopping the    */
   /* timers.                                                           */
typedef struct _tagProtocol_Timer_Information_t
{
   unsigned int                TimerCount;
   Comm_Protocol_Timer_Data_t *TimerData;
} Comm_Protocol_Create_Timers_Data_t;

   /* The following structure is used with the cpeStartTimer event type.*/
   /* This structure contains the ID of the timer to be started or      */
   /* restarted and the duration in milliseconds it should run.         */
typedef struct _tagComm_Protocol_Start_Timer_Data_t
{
   unsigned int                              TimerID;
   unsigned int                              Milliseconds;
} Comm_Protocol_Start_Timer_Data_t;

   /* The following structure is used with the cpeStopTimer event type. */
   /* This structure contains the ID of the timer to be stopped.        */
typedef struct _tagComm_Protocol_Stop_Timer_Data_t
{
   unsigned int                              TimerID;
} Comm_Protocol_Stop_Timer_Data_t;

   /* The following structure is used with the cpeTransmitData event    */
   /* type.  This structure contains the amount of data that needs to be*/
   /* transmitted and a pointer to the buffer containing the data.      */
typedef struct _tagComm_Protocol_Transmit_Data_t
{
   unsigned int                              DataLength;
   BTPSCONST unsigned char                  *DataBuffer;
} Comm_Protocol_Transmit_Data_t;

   /* The following structure is used with the cpeProcessPacket event   */
   /* type.  This structure contains the type of packet, the length of  */
   /* the packet, and the offset of data in the packet.                 */
   /* * NOTE * If the Packet data offset is non-zero, then the calling  */
   /*          function should NOT free or alter the data in the buffer */
   /*          provided as the buffer will be freed by the callback     */
   /*          function when it is finished.  If the offset is zero,    */
   /*          then the callback function will copy the data from the   */
   /*          buffer and the calling function is responsible for       */
   /*          freeing the memory if necessary.                         */
   /* * NOTE * The packet length does not include the offset of data in */
   /*          the buffer.                                              */
typedef struct _tagComm_Protocol_Process_Packet_Data_t
{
   Comm_Protocol_PacketType_t                PacketType;
   unsigned int                              PacketLength;
   unsigned char                            *PacketBuffer;
   unsigned int                              PacketDataOffset;
} Comm_Protocol_Process_Packet_Data_t;

   /* The following structure is used with the                          */
   /* cpeSetTransportConfiguration event type.  This structure contains */
   /* a flag to indicate if Xon/Xoff flow control should be enabled and */
   /* the values to be used for Xon and Xoff.                           */
   /* * NOTE * The Xon and Xoff values are only valid if the Xon/Xoff   */
   /*          enabled flag is TRUE, otherwise they should be ignored.  */
typedef struct _tagComm_Protocol_Set_Transport_Configuration_Data_t
{
   Boolean_t     Xon_Xoff_Enabled;
   unsigned char XonValue;
   unsigned char XoffValue;
} Comm_Protocol_Set_Transport_Configuration_Data_t;

   /* The following buffer defines offset for the data in the packet    */
   /* buffer of a cpeProcessPacket event.                               */
#define COMM_PROTOCOL_PROCESS_PACKET_DATA_OFFSET (BTPS_STRUCTURE_OFFSET(HCI_Packet_t, HCIPacketData))

   /* The following structure represents the Comm Event Container that  */
   /* is used by the Comm Event Callback.  This structure holds all     */
   /* pertinent information regarding the Event that requires action.   */
typedef struct _tagComm_Protocol_Event_Data_t
{
   Comm_Protocol_Event_Type_t  EventType;
   union
   {
      Comm_Protocol_Create_Timers_Data_t               CreateTimerData;
      Comm_Protocol_Start_Timer_Data_t                 StartTimerData;
      Comm_Protocol_Stop_Timer_Data_t                  StopTimerData;
      Comm_Protocol_Transmit_Data_t                    TransmitData;
      Comm_Protocol_Process_Packet_Data_t              ProcessPacketData;
      Comm_Protocol_Set_Transport_Configuration_Data_t SetTransportConfigurationData;
   } EventData;
} Comm_Protocol_Event_Data_t;

   /* The following defines the callback function used by the comm      */
   /* protocols to perform actions.  It accepts as its parameters the   */
   /* event data structure and the callback parameters specified when   */
   /* the protocol was initialized.                                     */
typedef int (BTPSAPI *Comm_Protocol_Event_Callback_t)(Comm_Protocol_Event_Data_t *Comm_Protocol_Event_Data, unsigned long CallbackParamter);

   /* The following prototype is for a callback function to handle      */
   /* changes in the sleep state of the protocol.  The function accepts */
   /* as parameters a boolean indication indicating if sleep is allowed */
   /* and a custom callback parameter.  If the function indicates that  */
   /* sleep is allowed, the application can safely power-down the       */
   /* associated COM port.                                              */
   /* * NOTE * This function prototype is also defined in HCICommT.h    */
typedef void (BTPSAPI *Comm_Protocol_Sleep_Callback_t)(Boolean_t SleepAllowed, unsigned long CallbackParameter);

   /* The following prototype is for a function to shutdown a Comm      */
   /* protocol.  The function accepts as its parameter a pointer to the */
   /* handle returned from its initialize function.  This function will */
   /* delete all timers and free all resources associated with the      */
   /* module.                                                           */
typedef void (BTPSAPI *Comm_Protocol_Shutdown_t)(void *Handle);

   /* The following prototype is for a function used to change the      */
   /* configuration of the comm protocol.  It accepts as its parameters */
   /* the handle returned from the protocol's initialization function   */
   /* and a pointer to the reconfiguration structure.                   */
   /* * NOTE * The reconfiguration structure will be specific to the    */
   /*          protocol being used.                                     */
typedef int (BTPSAPI *Comm_Protocol_Reconfigure_t)(void *Handle, void *Configuration);

   /* The following prototype is for a function that will force the     */
   /* state machines to re-synchronize with its peer.  It accepts as its*/
   /* parameter the handle returned from the modules initialization     */
   /* function.                                                         */
typedef void (BTPSAPI *Comm_Protocol_Resynchronize_t)(void *Handle);

   /* The following prototype is for a function that will handle        */
   /* transmitting bytes for the comm protocol.  It accepts as its      */
   /* parameters the handle returned from the module's initialization   */
   /* function, the type of packet, the length of the packet to be      */
   /* transmitted and a pointer to the buffer containing the data to be */
   /* transmitted.  This function will returned zero if successful or a */
   /* negative value if there is an error.  Upon successful return, the */
   /* function will either have transmitted or internally buffered all  */
   /* data in the provided buffer.                                      */
typedef int (BTPSAPI *Comm_Protocol_TransmitBytes_t)(void *Handle, Comm_Protocol_PacketType_t PacketType, unsigned int PacketLength, unsigned char *PacketData);

   /* The following prototype is for a function that will handle        */
   /* received bytes for the comm protocol.  It accepts as its          */
   /* parameters the handle returned from the module's initialization   */
   /* function, the length of the packet that was received and a pointer*/
   /* to the buffer containing the received data.  This function will   */
   /* return zero upon success or a negative value if there is an error.*/
   /* * NOTE * Depending on the module, this function may be used either*/
   /*          as a replacement for the HCIComm packetizer or as a      */
   /*          supplement called for data that isn't part of a valid HCI*/
   /*          packet.                                                  */
typedef int (BTPSAPI *Comm_Protocol_ReceiveBytes_t)(void *Handle, unsigned int BufferCount, unsigned char *Buffer);

#endif

