/*****< hcill.h >**************************************************************/
/*      Copyright 2012 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  HCILL - Enhanced HCI Low Level prototypes/constants.                      */
/*                                                                            */
/*  Author:  Marcus Funk                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   10/15/12  M. Funk        Initial creation.                               */
/******************************************************************************/
#ifndef __HCILLH__
#define __HCILLH__

#include "CommProt.h"          /* Comm Protocol Prototypes/Constants.         */

   /* The following structure defines the application configurable      */
   /* settings for an HCILL instance.                                   */
   /* * NOTE * This structure is also defined in HCICommT.h.            */
typedef struct _tagHCILL_Configuration_t
{
   Comm_Protocol_Sleep_Callback_t SleepCallbackFunction;
   unsigned long                  SleepCallbackParameter;
} HCILL_Configuration_t;

   /* The following function will initialize an instance of the HCILL   */
   /* interface.  The function accepts as its parameters a Comm Protocol*/
   /* Event Callback Function, and a Callback Parameter that will be    */
   /* passed to the Event Callback Function.  This function will return */
   /* a handle to the HCILL instance upon success or NULL if there was  */
   /* an error.                                                         */
void *BTPSAPI HCILL_Initialize(Comm_Protocol_Event_Callback_t CallbackFunction, unsigned long CallbackParameter);

   /* The following function will shutdown an instance of a HCILL       */
   /* interface.  The function will delete all timers and free all      */
   /* memory associated with the HCILL instance including memory        */
   /* allocated for the handle.  The function accepts as its parameter a*/
   /* pointer to the handle returned from the HCILL initialize function.*/
   /* * NOTE * Once the interface has been shutdown, the memory         */
   /*          associated with the protocol Handle will have been freed */
   /*          and MUST not be used.                                    */
void BTPSAPI HCILL_Shutdown(void *Handle);

   /* The following function is used to change the configuration of the */
   /* HCILL instance.  It accepts as its parameters the handle returned */
   /* from the HCILL initialization function and a pointer to the       */
   /* reconfiguration structure.  This function will return 1 if the    */
   /* connection is currently asleep, 0 if it is not asleep or a        */
   /* negative value if there is an error.                              */
   /* * NOTE * To disable the callback function, call this function with*/
   /*          SleepCallbackFunction set to NULL.                       */
int BTPSAPI HCILL_Reconfigure(void *Handle, void *Configuration);

   /* The following function will force the state machine to            */
   /* re-synchronize with the peer device.  It accepts as its parameter */
   /* a pointer to the handle returned from the HCILL initialization    */
   /* function.                                                         */
void BTPSAPI HCILL_Resynchronize(void *Handle);

   /* The following function will handle transmitting bytes for the     */
   /* HCILL instance.  It accepts as its parameters the handle returned */
   /* from the HCILL initialization function, the type of packet, the   */
   /* length of the packet to be transmitted and a pointer to the buffer*/
   /* containing the data to be transmitted.  This function will        */
   /* returned zero if successful or a negative value if there is an    */
   /* error.  Upon successful return, the function will either have     */
   /* transmitted or internally buffered all data in the provided       */
   /* buffer.                                                           */
int BTPSAPI HCILL_TransmitBytes(void *Handle, Comm_Protocol_PacketType_t PacketType, unsigned int PacketLength, unsigned char *PacketData);

   /* The following function will handle receiving bytes for the HCILL  */
   /* instance.  It accepts as its parameters the handle returned from  */
   /* the HCILL initialization function, the length of the packet that  */
   /* was received and a pointer to the buffer containing the received  */
   /* data.  This function will return zero upon success or a negative  */
   /* value if there is an error.                                       */
   /* * NOTE * It is assumed that the HCIComm packetizer has already    */
   /*          checked if the first byte is a HCI packet.               */
int BTPSAPI HCILL_ReceiveBytes(void *Handle, unsigned int BufferCount, unsigned char *Buffer);

#endif

