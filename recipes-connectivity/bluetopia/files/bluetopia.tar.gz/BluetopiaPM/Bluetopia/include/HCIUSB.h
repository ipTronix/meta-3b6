/*****< hciusb.h >*************************************************************/
/*      Copyright 2000 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  HCIUSB - USB HCI Driver Implementation for Generic Bluetooth Stack        */
/*           Prototypes and Constants.                                        */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/17/00  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __HCIUSBH__
#define __HCIUSBH__

#include "HCIUSBT.h"           /* HCI USB Driver Types/Constants.             */
#include "HCITypes.h"          /* HCI Types Prototypes/Constants.             */

   /* Error Return Codes.                                               */
#define HCI_USB_ERROR_INVALID_DRIVER_INFORMATION (-1)   /* Error that denotes */
                                                        /* that the specified */
                                                        /* Driver Information */
                                                        /* Structure is       */
                                                        /* invalid.           */

#define HCI_USB_ERROR_INVALID_CALLBACK_INFORMATION (-2) /* Error that denotes */
                                                        /* that the specified */
                                                        /* Callback function  */
                                                        /* pointer is invalid.*/

#define HCI_USB_ERROR_INITIALIZING_USB_DEVICE   (-3)    /* Error that denotes */
                                                        /* that an error      */
                                                        /* occurred during USB*/
                                                        /* Device             */
                                                        /* Configuration.     */

#define HCI_USB_ERROR_INVALID_USB_DRIVER_ID     (-4)    /* Error that denotes */
                                                        /* Driver ID supplied */
                                                        /* as function        */
                                                        /* argument is NOT    */
                                                        /* Registered with    */
                                                        /* this Module.       */

#define HCI_USB_ERROR_ERROR_WRITING_DEVICE      (-5)    /* Error that denotes */
                                                        /* that there was an  */
                                                        /* error writing the  */
                                                        /* specified Data to  */
                                                        /* the USB Device.    */

#define HCI_USB_ERROR_INVALID_DATA              (-6)    /* Error that denotes */
                                                        /* the specified Data */
                                                        /* to be sent was     */
                                                        /* invalid.           */

#define HCI_USB_ERROR_UNKNOWN                   (-7)    /* Error that is not  */
                                                        /* covered by any     */
                                                        /* other Error Code.  */

#define HCI_USB_ERROR_UNIMPLEMENTED             (-8)    /* Error that denotes */
                                                        /* the specified      */
                                                        /* function or        */
                                                        /* operation is not   */
                                                        /* implemented.       */

   /* Flag Values used with the HCI_SendUSBPacket() function.           */
#define HCI_USB_SEND_PACKET_ASYNCHRONOUS_FLAG  0x00000001 /* Bit Flag that    */
                                                        /* denotes that the   */
                                                        /* Data is to be      */
                                                        /* queued to be sent  */
                                                        /* (if this flag is   */
                                                        /* not specified, the */
                                                        /* function does NOT  */
                                                        /* return until ALL   */
                                                        /* Data bytes have    */
                                                        /* been sent (or an   */
                                                        /* error occurs).     */

   /* The following is the Type Declaration for the HCI SCO             */
   /* Configuration Parameter of the HCI_ChangeUSBSCOConfiguration()    */
   /* function.                                                         */
typedef enum
{
   hsuNoConfiguration,
   hsuOneChannel8BitVoice,
   hsuOneChannel16BitVoice,
   hsuTwoChannel8BitVoice,
   hsuTwoChannel16BitVoice,
   hsuThreeChannel8BitVoice,
   hsuThreeChannel16BitVoice
} HCI_USBSCOConfiguration_t;

   /* The following declared type represents the Prototype Function for */
   /* an HCI USB Driver Receive Data Callback.  This function will be   */
   /* called whenever a complete HCI Packet has been received.  This    */
   /* function passes to the caller the HCI USB Driver ID, the Packet   */
   /* that was received and the HCI USB Driver Callback Parameter that  */
   /* was specified when the HCI USB Driver was Opened.  The caller is  */
   /* free to use the contents of the HCI Packet ONLY in the context of */
   /* this callback.  If the caller requires the Data for a longer      */
   /* period of time, then the callback function MUST copy the data into*/
   /* another Data Buffer.  This function is guaranteed NOT to be       */
   /* invoked more than once simultaneously (i.e.  this function DOES   */
   /* NOT have be reentrant).  It should be noted that this function is */
   /* called in the Thread Context of a Thread that the User does NOT   */
   /* own.  Therefore, processing in this function should be as         */
   /* efficient as possible (this argument holds anyway because another */
   /* Packet will not be received while this function call is           */
   /* outstanding).                                                     */
typedef void (BTPSAPI *HCI_USBDriverCallback_t)(unsigned int USBDriverID, HCI_Packet_t *HCIPacket, unsigned long CallbackParameter);

   /* The following function is responsible for Initializing the Module */
   /* and ALL Data structures required by the Module.  This function    */
   /* returns a non zero value if all resources were allocated and      */
   /* configured correctly, or zero otherwise.  This function MUST be   */
   /* called before any other function in this Module or the other      */
   /* functions will fail.                                              */
int InitializeUSBList(void);

   /* The following function releases all resources that are held by    */
   /* this module (including memory and threads).  After this function  */
   /* is called, NO other function in this module will succeed until a  */
   /* successful call to the InitializeUSBList() is completed.          */
void CleanupUSBList(void);

   /* The following function is responsible for actually opening the    */
   /* specified USB Device (with attributes present in the required     */
   /* USBDriverInformation parameter).  This function also accepts the  */
   /* Callback function (and parameter) to call when Data is received   */
   /* from the USB Device.  This function returns a Positive, Non-zero  */
   /* Driver ID value that can be used as input to other functions if   */
   /* the USB Device is able to be opened successfully.  If there is an */
   /* error trying to open the USB Device (or invalid parameters) then  */
   /* this function returns a Negative return code.                     */
int OpenUSB(HCI_USBDriverInformation_t *USBDriverInformation, HCI_USBDriverCallback_t DriverCallback, unsigned long DriverCallbackParameter);

   /* The following function is responsible for reconfiguring the       */
   /* currently active HCI Driver.  The Input parameter to this function*/
   /* MUST have been acquired by a successful call to OpenUSB().  This  */
   /* function accepts the Driver ID of the driver to reconfigured,     */
   /* followed by a BOOLEAN which specifies whether or not any internal */
   /* HCI Driver state machines should be reset (for example BCSP and/or*/
   /* Packet building state machines).                                  */
int ReconfigureUSB(unsigned int USBDriverID, Boolean_t ResetStateMachines, HCI_Driver_Reconfigure_Data_t *DriverReconfigureData);

   /* The following function is responsible for Closing the specified   */
   /* USB Device and cleaning up all resources associated with the USB  */
   /* Device.  After this function is called, the specified USB Driver  */
   /* ID will no longer be valid, and cannot be used as input to any of */
   /* the other functions in this module.  Also, after this function is */
   /* called, there will be NO Receive Data Callbacks issued.           */
void CloseUSB(unsigned int USBDriverID);

   /* The following function is provided to allow a mechanism for       */
   /* modules to force the processing of incoming USB Data outside of   */
   /* the normal Scheduled Processing.  This mechanism allows apparent  */
   /* blocking functions to be written that wait on HCI Events before   */
   /* returning.                                                        */
   /* * NOTE * This function is only applicable in device stacks that   */
   /*          are non-threaded.  This function has no effect for device*/
   /*          stacks that are operating in threaded environments.      */
void ProcessUSB(unsigned int USBDriverID);

   /* The following function is used to actually Send an HCI Packet to  */
   /* the specified USB Device (specified by the USB Driver ID).  The   */
   /* HCIPacket Parameter is the HCI Packet to send and the Flags       */
   /* argument specifies any additional processing that is required for */
   /* this Transmission.  This function returns a non-zero, non-negative*/
   /* return value if the Transmission was successful, or a negative    */
   /* return value if the data was invalid or unable to be Transmitted. */
int SendUSBPacket(unsigned int USBDriverID, HCI_Packet_t *HCIPacket, unsigned int Flags);

   /* The following function changes the settings for the specified USB */
   /* Device regarding HCI SCO Bandwidth Configuration.  This function  */
   /* is applicable to USB Devices in particular because the            */
   /* specification supports dynamic Bandwidth Allocation on the USB    */
   /* Interface.  This function returns zero upon successful execution  */
   /* or a negative error code on failure.                              */
int ChangeUSBSCOConfiguration(unsigned int USBDriverID, HCI_SCOConfiguration_t SCOConfiguration);

   /* The following function updates the SCO connection handle list for */
   /* the specified USB Device.  This function returns zero upon        */
   /* successfully execution or a negative error code on failure.       */
int ChangeUSBSCOConfigurationHandles(unsigned int USBDriverID, unsigned int NumberHandles, Word_t *ConnectionHandleList);

#endif
