/*****< twuart.h >*************************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  TWUART - Three Wire UART (H5) Interface protypes/constants.               */
/*                                                                            */
/*  Author:  Marcus Funk                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   3/18/13   M. Funk        Initial creation.                               */
/******************************************************************************/
#ifndef __TWUARTH__
#define __TWUARTH__

#include "BTPSCFG.h"           /* Protocol Stack Configuration Constants.     */
#include "CommProt.h"          /* Comm Protocol Prototypes/Constants.         */

#define TWUART_MINIMUM_SLIDING_WINDOW_SIZE         1
#define TWUART_MAXIMUM_SLIDING_WINDOW_SIZE         7
#define TWUART_DEFAULT_SLIDING_WINDOW_SIZE         ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_SLIDING_WINDOW_SIZE) < TWUART_MAXIMUM_SLIDING_WINDOW_SIZE ? ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_SLIDING_WINDOW_SIZE) > TWUART_MINIMUM_SLIDING_WINDOW_SIZE ? BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_SLIDING_WINDOW_SIZE : TWUART_MINIMUM_SLIDING_WINDOW_SIZE) : TWUART_MAXIMUM_SLIDING_WINDOW_SIZE)

#define TWUART_DEFAULT_SUPPORT_CRC                ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_SUPPORT_CRC) ? 1 : 0)
#define TWUART_DEFAULT_SUPPORT_OOF_FLOW_CONTROL   ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_SUPPORT_OOF_FLOW_CONTROL) ? 1 : 0)

#define TWUART_MINIMUM_IDLE_TIME                   BTPS_CONFIGURATION_TIMER_MINIMUM_TIMER_RESOLUTION_MS
#define TWUART_MAXIMUM_IDLE_TIME                   30000
#define TWUART_DEFAULT_IDLE_TIME                   ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_IDLE_TIME_MS) < TWUART_MAXIMUM_IDLE_TIME ? ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_IDLE_TIME_MS) > TWUART_MINIMUM_IDLE_TIME ? BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_IDLE_TIME_MS : TWUART_MINIMUM_IDLE_TIME) : TWUART_MAXIMUM_IDLE_TIME)

#define TWUART_MINIMUM_RETRANSMIT_TIME             BTPS_CONFIGURATION_TIMER_MINIMUM_TIMER_RESOLUTION_MS
#define TWUART_MAXIMUM_RETRANSMIT_TIME             1000
#define TWUART_DEFAULT_RETRANSMIT_TIME             ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_RETRANSMIT_TIME_MS) < TWUART_MAXIMUM_RETRANSMIT_TIME ? ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_RETRANSMIT_TIME_MS) > TWUART_MINIMUM_RETRANSMIT_TIME ? BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_RETRANSMIT_TIME_MS : TWUART_MINIMUM_RETRANSMIT_TIME) : TWUART_MAXIMUM_RETRANSMIT_TIME)

#define TWUART_MINIMUM_ACKNOWLEDGE_DELAY           BTPS_CONFIGURATION_TIMER_MINIMUM_TIMER_RESOLUTION_MS
#define TWUART_MAXIMUM_ACKNOWLEDGE_DELAY           500
#define TWUART_DEFAULT_ACKNOWLEDGE_DELAY           ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_ACKNOWLEDGE_DELAY_MS) < TWUART_MAXIMUM_ACKNOWLEDGE_DELAY ? ((BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_RETRANSMIT_TIME_MS) > TWUART_MINIMUM_ACKNOWLEDGE_DELAY ? BTPS_CONFIGURATION_HCI_DRIVER_3WIRE_DEFAULT_RETRANSMIT_TIME_MS : TWUART_MINIMUM_ACKNOWLEDGE_DELAY) : TWUART_MAXIMUM_ACKNOWLEDGE_DELAY)

#define TWUART_MAXIMUM_RECEIVE_PACKET_BUFFER_SIZE  BTPS_CONFIGURATION_HCI_DRIVER_RECEIVE_PACKET_BUFFER_SIZE

   /* The following defines the version of the TWUART protocol.         */
   /* Currently set to v1.0.                                            */
#define TWUART_VERSION_NUMBER                      0

   /* The following struct contains the configuration for the link of   */
   /* the 3-Wire interface.  These parameters will only be applied      */
   /* during the link negotiation with the baseband that takes place    */
   /* when the first is sent or when the 3-wire state instance is       */
   /* resynchronized.                                                   */
   /* * NOTE * This structure is also defined in HCICommT.h.            */
typedef struct _tagTWUART_LinkConfiguration_t
{
   unsigned int SlidingWindowSize;
   Boolean_t    SupportCRC;
   Boolean_t    SupportOOFFlowControl;
} TWUART_LinkConfiguration_t;

   /* The following structure defines the application configurable      */
   /* settings for an Three Wire UART instance.                         */
   /* * NOTE * This structure is also defined in HCICommT.h.            */
typedef struct _tagTWUART_Configuration_t
{
   TWUART_LinkConfiguration_t     LinkConfiguration;
   unsigned int                   IdleTimeMS;
   unsigned int                   RetransmitTimeMS;
   unsigned int                   AcknowledgeDelayMS;

   Comm_Protocol_Sleep_Callback_t SleepCallbackFunction;
   unsigned long                  SleepCallbackParameter;

   unsigned int                   Flags;
} TWUART_Configuration_t;

   /* The following constants represent the bit mask of values for the  */
   /* Flags member of the HCI_3WireConfiguration_t.                     */
   /* * NOTE * These flags are also defined in HCICommT.h.              */
#define TWUART_CONFIGURATION_FLAGS_SCO_IS_RELIABLE    0x0001

   /* The following function will initialize an instance of the Three   */
   /* Wire UART interface.  This function accepts as its parameters a   */
   /* Comm Protocol Event Callback Function, and a Callback Parameter   */
   /* that will be passed to the Event Callback Function.  This function*/
   /* will return a handle to the TWUART instance upon success or NULL  */
   /* if there was an error.                                            */
void *BTPSAPI TWUART_Initialize(Comm_Protocol_Event_Callback_t CallbackFunction, unsigned long CallbackParameter);

   /* The following function will shutdown an instance of a Three Wire  */
   /* UART interface.  The function will delete all timers and free all */
   /* memory associated with the TWUART instance including memory       */
   /* allocated for the handle.  This function accepts as its parameter */
   /* a pointer to the handle returned from the TWUART initialize       */
   /* function.                                                         */
   /* * NOTE * Once the interface has been shutdown, the memory         */
   /*          associated with the protocol Handle will have been freed */
   /*          and MUST not be used.                                    */
void BTPSAPI TWUART_Shutdown(void *Handle);

   /* The following function is used to change the configuration of the */
   /* Three Wire UART instance.  This function accepts as its parameters*/
   /* a pointer to the handle returned from the TWUART initialize       */
   /* function and a pointer to the reconfiguration structure.  The     */
   /* function will return zero upon success or a negative value if     */
   /* there is an error.                                                */
   /* * NOTE * To disable the callback function, call this function with*/
   /*          SleepCallbackFunction set to NULL.                       */
int BTPSAPI TWUART_Reconfigure(void *Handle, void *Configuration);

   /* The following function will force the state machine to            */
   /* re-synchronize with the peer device.  This function accepts as its*/
   /* parameter a pointer to the handle returned from the TWUART        */
   /* initialize function.                                              */
void BTPSAPI TWUART_Resynchronize(void *Handle);

   /* The following function will handle transmitting bytes for the     */
   /* TWUART instance.  This function accepts as its parameters a       */
   /* pointer to the handle returned from the TWUART initialize function*/
   /* the type of packet, the length of the packet to be transmitted and*/
   /* a pointer to the buffer containing the data to be transmitted.  It*/
   /* will returned zero if successful or a negative value if there is  */
   /* an error.  Upon successful return, the function will either have  */
   /* transmitted or internally buffered all data in the provided       */
   /* buffer.                                                           */
int BTPSAPI TWUART_TransmitBytes(void *Handle, Comm_Protocol_PacketType_t PacketType, unsigned int PacketLength, unsigned char *PacketData);

   /* The following function will handle receiving bytes for the TWUART */
   /* instance.  This function accepts as its parameters a pointer to   */
   /* the handle returned from the TWUART initialize function the length*/
   /* of the packet that was received and a pointer to the buffer       */
   /* containing the received data.  It will return zero upon success or*/
   /* a negative value if there is an error.                            */
   /* * NOTE * This function is intended to be used in place of the     */
   /*          HCIComm Packetizer.                                      */
int BTPSAPI TWUART_ReceiveBytes(void *Handle, unsigned int BufferCount, unsigned char *Buffer);

#endif

