/*****< linuxaud.h >***********************************************************/
/*      Copyright 2011 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXAUD - Simple Linux application using Audio Sub-System Profile.       */
/*                                                                            */
/*  Author:  Matt Seabold                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/05/11  M. Seabold     Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXAUDH__
#define __LINUXAUDH__

#endif

