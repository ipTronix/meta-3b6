/*****< linuxftp.h >***********************************************************/
/*      Copyright 2002 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXFTP - Simple Linux application using OBEX File Transfer Profile.     */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/08/02  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXFTPH__
#define __LINUXFTPH__

#endif

