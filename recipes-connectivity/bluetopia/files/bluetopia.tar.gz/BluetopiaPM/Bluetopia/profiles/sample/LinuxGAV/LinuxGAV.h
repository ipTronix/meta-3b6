/*****< linuxgav.h >***********************************************************/
/*      Copyright 2003 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXGAV - Simple Linux application using Generic Audio/Video Distribution*/
/*             Profile.                                                       */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/14/03  D. Lange        Initial creation.                              */
/******************************************************************************/
#ifndef __LINUXGAVH__
#define __LINUXGAVH__

#endif
