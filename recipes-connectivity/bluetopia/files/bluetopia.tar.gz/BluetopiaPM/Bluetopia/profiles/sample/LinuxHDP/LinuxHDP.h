/*****< linuxhdp.h >***********************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXHDP - Simple Linux application using HDP Profile.                    */
/*                                                                            */
/*  Author:  Tim Thomas                                                       */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   11/01/10  T. Thomas      Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXHDPH__
#define __LINUXHDPH__

#endif
