/*****< linuxhid.h >***********************************************************/
/*      Copyright 2003 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXHFR - Simple Linux application using HID Profile.                    */
/*                                                                            */
/*  Author:  Rory Sledge                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   01/03/03  R. Sledge       Initial creation.                              */
/******************************************************************************/
#ifndef __LINUXHIDH__
#define __LINUXHIDH__

#endif
