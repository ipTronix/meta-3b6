/*****< linuxmap.h >***********************************************************/
/*      Copyright 2009 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXMAP - Simple Linux application using Message Access Profile (MAP).   */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/21/09  D. Lange        Initial creation.                              */
/******************************************************************************/
#ifndef __LINUXMAPH__
#define __LINUXMAPH__

#endif
