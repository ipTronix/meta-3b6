/*****< linuxopp.h >***********************************************************/
/*      Copyright 2009 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXOPP - Simple Linux application using OBEX Object Push Profile (OPP). */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/11/09  D. Lange        Initial creation.                              */
/******************************************************************************/
#ifndef __LINUXOPPH__
#define __LINUXOPPH__

#endif
