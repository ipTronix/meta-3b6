/*****< linuxpan.h >***********************************************************/
/*      Copyright 2009 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXPAN - Simple Linux application using the Personal Area Networking    */
/*             Profile.                                                       */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/20/09  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXPANH__
#define __LINUXPANH__

#endif
