/*****< linuxpba.h >***********************************************************/
/*      Copyright 2009 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXPBA - Simple Linux application using Phonebook Access Profile (PBAP).*/
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/22/09  D. Lange        Initial creation.                              */
/******************************************************************************/
#ifndef __LINUXPBAH__
#define __LINUXPBAH__

#endif
