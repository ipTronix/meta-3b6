/*****< linuxl2cap.h >*********************************************************/
/*      Copyright 2001 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXL2CAP - Simple Linux application using L2CAP Protocol.               */
/*                                                                            */
/*  Author:  Rory Sledge                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/27/01  R. Sledge      Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXL2CAPH__
#define __LINUXL2CAPH__

#endif

