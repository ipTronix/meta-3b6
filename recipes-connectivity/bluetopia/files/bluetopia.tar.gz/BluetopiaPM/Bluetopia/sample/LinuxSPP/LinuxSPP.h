/*****< linuxspp.h >***********************************************************/
/*      Copyright 2001 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXSPP - Simple Linux application using SPP Profile.                    */
/*                                                                            */
/*  Author:  Rory Sledge                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/27/01  R. Sledge      Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXSPPH__
#define __LINUXSPPH__

#endif

