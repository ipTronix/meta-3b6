/*****< tibts.c >**************************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  TIBTS - Vendor specific implementation of a set of vendor specific        */
/*         functions supported for a specific hardware platform.              */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/19/13  S. Hishmeh     Initial creation.                               */
/******************************************************************************/
#include "SS1BTPS.h"          /* Bluetopia API Prototypes/Constants.          */
#include "SS1TIBTS.h"         /* TI BTS API Prototypes/Constants.             */
#include "TIBTSIM.h"          /* TI BTS Implementation Prototypes/Constants.  */

   /* The following constants specify the different types of actions    */
   /* that can be found in a BTS script.  These values were found in    */
   /* reference [2] (see references at end of this file).               */
#define ACTION_SEND_COMMAND        (1)
#define ACTION_WAIT_EVENT          (2)
#define ACTION_SERIAL              (3)
#define ACTION_DELAY               (4)
#define ACTION_RUN_SCRIPT          (5)
#define ACTION_REMARKS             (6)

   /* The following definition specifies the maximum command data length*/
   /* of any HCI Command contained within the BTS Script.               */
#define MAXIMUM_COMMAND_LENGTH     (256)

   /********************** BTS Internal Structures **********************/

   /* The following structures specifies the data that is found in      */
   /* header of a BTS Script.                                           */
typedef __PACKED_STRUCT_BEGIN__ struct _tagBTSFileHeader_t
{
   DWord_t       MagicNumber;
   DWord_t       VersionNumber;
   unsigned char RFA[24];
} __PACKED_STRUCT_END__ BTSFileHeader_t;

   /* The following definitions specify the magic number that is stored */
   /* in the header of a BTS Script, first as a string and second as a  */
   /* hexadecimal value.  Refer to reference [1] below.                 */
#define HEADER_MAGIC_NUMBER_STRING   "BTSB"
#define HEADER_MAGIC_NUMBER_VALUE    (0x42535442)

   /* The following definition specifies the expected version number    */
   /* that is found in the header of every BTS Script.  Refer to        */
   /* reference [1] below.                                              */
#define HEADER_VERSION_NUMBER        (0x00000001)

   /* The following structure defines the format of an Action's Header. */
typedef __PACKED_STRUCT_BEGIN__ struct _tagBTSAction_t
{
   Word_t Type;
   Word_t Size;
} __PACKED_STRUCT_END__ BTSActionHeader_t;

   /************************* BTS File Actions **************************/

   /* The following structure specifies the format of a Send Command    */
   /* Action.                                                           */
typedef __PACKED_STRUCT_BEGIN__ struct _tagSendCommandAction_t
{
   Byte_t Prefix;
   Word_t CommandOpCode;
   Byte_t CommandDataLength;
   Byte_t CommandData[1];
} __PACKED_STRUCT_END__ SendCommandAction_t;

#define SEND_COMMAND_ACTION_SIZE (sizeof(SendCommandAction_t) - 1)

   /* The following structure specifies the format of a Wait Event      */
   /* Action.                                                           */
typedef __PACKED_STRUCT_BEGIN__ struct _tagWaitEventAction_t
{
   DWord_t Milliseconds;
   DWord_t DataLength;
   Byte_t  Data[1];
} __PACKED_STRUCT_END__ WaitEventAction_t;

#define WAIT_EVENT_ACTION_SIZE   (sizeof(WaitEventAction_t) - 1)

   /* The following structure specifies the format of a Set Host COM    */
   /* Parameters Action.                                                */
typedef __PACKED_STRUCT_BEGIN__ struct _tagHostSetCOMParamsAction_t
{
   DWord_t BaudRate;
   DWord_t FlowControl;
} __PACKED_STRUCT_END__ HostSetCOMParamsAction_t;

#define HOST_SET_COM_PARAMS_ACTION_SIZE (sizeof(HostSetCOMParamsAction_t))

   /* The following structure specifies the format of a Delay Action.   */
typedef __PACKED_STRUCT_BEGIN__ struct _tagDelayAction_t
{
   DWord_t MillisecondDelay;
} __PACKED_STRUCT_END__ DelayAction_t;

#define DELAY_ACTION_SIZE (sizeof(DelayAction_t))

   /* The following structure specifies the format of a Run Script      */
   /* Action.                                                           */
   /* * NOTE * This command is used to execute another script from      */
   /*          within a script.  At the moment nothing is known about   */
   /*          the format of this command, I wasn't able to find any    */
   /*          documentation and it's not used in the kernel source code*/
   /*          referenced at the end of this file.  The structure is    */
   /*          added here anyway is a placeholder for future additions. */
typedef __PACKED_STRUCT_BEGIN__ struct _tagRunScriptAction_t
{
   Byte_t Data[1];
} __PACKED_STRUCT_END__ RunScriptAction_t;

#define RUN_SCRIPT_ACTION_SIZE (sizeof(RunScriptAction_t))

   /* The following structure specifies the format of a Remarks Action. */
   /* Remarks are embedded in-line script comments and are always       */
   /* preceded with a '#' character.                                    */
   /* * NOTE * The structure below sets the minimum remark size to 1.   */
   /*          There is no documentation stating that a remark must have*/
   /*          a length of 1, but it wouldn't make sense to have a      */
   /*          0-length remark.  If this causes problems in the future  */
   /*          the implementation below may have to be changed.         */
typedef __PACKED_STRUCT_BEGIN__ struct _tagRemarksAction_t
{
   Byte_t Remarks[1];
} __PACKED_STRUCT_END__ RemarksAction_t;

#define REMARKS_ACTION_SIZE (sizeof(RemarksAction_t))

   /***************** Internally Used Type Definitions ******************/

   /* The following structure specifies the data is stored internal to  */
   /* this module, i.e. when the API-user passes in a                   */
   /* TIBTS_Imlementation_Handle_t variable they are actually passing in*/
   /* a pointer to a structure of this type.                            */
typedef struct _tagScriptParameters_t
{
   TIBTS_Imlementation_Handle_t ImplementationHandle;
   DWord_t                      ScriptFlags;
   Byte_t                       CommandBuffer[MAXIMUM_COMMAND_LENGTH];
} ScriptParameters_t;

   /* Internal Function Prototypes.                                     */
static int GetSendHCICommandAction(ScriptParameters_t *ScriptParameters, TIBTS_Send_HCI_Command_Action_Data_t *SendHCICommandActionData);

   /* The following function is used to read a Send Command Action from */
   /* a file.  It takes as input the script open script parameters and a*/
   /* pointer specifying where the HCI Command that was read from the   */
   /* script should be stored.  It returns 0 on success and a negative  */
   /* error code otherwise.                                             */
static int GetSendHCICommandAction(ScriptParameters_t *ScriptParameters, TIBTS_Send_HCI_Command_Action_Data_t *SendHCICommandActionData)
{
   int                 ret_val;
   int                 NumberBytesRead;
   Word_t              CommandOpCode;
   SendCommandAction_t SendCommandAction;

   /* Read the send command action's header from the script.            */
   if((NumberBytesRead = TIBTS_Read(ScriptParameters->ImplementationHandle, SEND_COMMAND_ACTION_SIZE, SEND_COMMAND_ACTION_SIZE, (Byte_t *)&SendCommandAction)) == SEND_COMMAND_ACTION_SIZE)
   {
      /* Check if this command has any additional data bytes.           */
      if(SendCommandAction.CommandDataLength)
      {
         /* The command does have additional data bytes, attempt to read*/
         /* them from the script file.                                  */
         if((NumberBytesRead = TIBTS_Read(ScriptParameters->ImplementationHandle, SendCommandAction.CommandDataLength, sizeof(ScriptParameters->CommandBuffer), ScriptParameters->CommandBuffer)) == SendCommandAction.CommandDataLength)
         {
            /* We were able to read the additional data bytes from the  */
            /* file, flag success to the caller.                        */
            ret_val = 0;
         }
         else
         {
            /* We were not able to read the additional data bytes from  */
            /* the file, flag the error to the caller.                  */
            ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
         }
      }
      else
      {
         /* There are no additional data bytes for this command to read,*/
         /* flag success to the caller.                                 */
         ret_val = 0;
      }

      /* Check if any errors occurred while retrieving the command from */
      /* the script.                                                    */
      if(!ret_val)
      {
         /* No errors occurred, assign the HCI Command.                 */
         CommandOpCode                               = READ_UNALIGNED_WORD_LITTLE_ENDIAN(&SendCommandAction.CommandOpCode);

         SendHCICommandActionData->OGF               = TIBTS_COMMAND_OPCODE_TO_OGF(CommandOpCode);
         SendHCICommandActionData->OCF               = TIBTS_COMMAND_OPCODE_TO_OCF(CommandOpCode);
         SendHCICommandActionData->CommandDataLength = SendCommandAction.CommandDataLength;

         if(SendHCICommandActionData->CommandDataLength)
            SendHCICommandActionData->CommandData = ScriptParameters->CommandBuffer;
         else
            SendHCICommandActionData->CommandData = NULL;
      }
   }
   else
   {
      /* Could not read the command action's header from the script,    */
      /* let's determine the reason for the error.                      */
      if(NumberBytesRead == 0)
      {
         /* The return error code is 0, which represents the end of the */
         /* file, next check if this is a BTS Script Stored as a Memory */
         /* Array inside of a file.                                     */
         if(ScriptParameters->ScriptFlags & TIBTS_SCRIPT_FLAGS_MEMORY_ARRAY_FORMAT)
         {
            /* This is a memory array, flag that we have reached the end*/
            /* of the script.                                           */
            ret_val = TIBTS_ERROR_END_OF_SCRIPT;
         }
         else
         {
            /* This is not a memory array and the script specified there*/
            /* was a send command action present, however we have       */
            /* reached the end of the file before reading the full      */
            /* command.  Specify that this is invalid file format.      */
            ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
         }
      }
      else
      {
         /* Check if the return code is greater than 0.                 */
         if(NumberBytesRead > 0)
         {
            /* The return code is greater than 0, flag an API-Specific  */
            /* error back to the caller.                                */
            ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
         }
         else
         {
            /* The return code is less than zero, pass the error code   */
            /* back to the caller.                                      */
            ret_val = NumberBytesRead;
         }
      }
   }

   return(ret_val);
}

   /* The following function returns the Bluetooth Script Version       */
   /* Information for the Bluetooth Controller currently in use.  This  */
   /* function retrieves the Controller's Firmware Version Information  */
   /* and uses it to choose an appropriate Bluetooth Script Version.    */
   /* This function takes as input a Bluetooth Stack Identifier and an  */
   /* address specifying where the resulting Bluetooth Script Version   */
   /* Information should be stored.  This function returns 0 on success */
   /* and a negative value if an error occurs.  On success the Bluetooth*/
   /* Script's Version Information is stored in the last parameter.     */
int BTPSAPI TIBTS_Get_Script_Version(unsigned int BluetoothStackID, TIBTS_Script_Version_Info_t *ScriptVersionInfo)
{
   int    ret_val;
   Byte_t StatusResult;
   Byte_t HCI_VersionResult;
   Word_t HCI_RevisionResult;
   Byte_t LMP_VersionResult;
   Word_t Manufacturer_NameResult;
   Word_t LMP_SubversionResult;

   /* Check if the input parameters are valid.                          */
   if((BluetoothStackID) && (ScriptVersionInfo))
   {
      /* The input parameters appear to be valid, next read the local   */
      /* version information.                                           */
      if((!(ret_val = HCI_Read_Local_Version_Information(BluetoothStackID, &StatusResult, &HCI_VersionResult, &HCI_RevisionResult, &LMP_VersionResult, &Manufacturer_NameResult, &LMP_SubversionResult))) && (StatusResult == HCI_ERROR_CODE_NO_ERROR))
      {
         /* Parse the Link Management Protocol's Subversion.            */
         ScriptVersionInfo->ProjectVersion = (Byte_t)((LMP_SubversionResult & 0x7C00) >> 10);
         ScriptVersionInfo->MajorVersion   = (Byte_t)((LMP_SubversionResult & 0x0380) >> 7);
         ScriptVersionInfo->MinorVersion   = (Byte_t)(LMP_SubversionResult & 0x007F);

         /* Do an additional check to see if the Major Version needs to */
         /* be fixed up.  This is required to get the correct version   */
         /* and this is what is done in the kernel source code, see     */
         /* reference [3] below.                                        */
         if(LMP_SubversionResult & 0x8000)
            ScriptVersionInfo->MajorVersion |= 0x0008;

         /* Flag success to the caller.                                 */
         ret_val = 0;
      }
   }
   else
   {
      /* One or more of the input parameters is invalid, pass the error */
      /* back to the caller.                                            */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}

   /* The following function Opens a BTS Script.  This function takes as*/
   /* input an address that specifies where the open parameters should  */
   /* be read from.  This function returns a handle that can be used to */
   /* retrieve commands from the BTS Script on success and NULL if an   */
   /* error occurred.                                                   */
TIBTS_Script_Handle_t BTPSAPI TIBTS_Open_Script(TIBTS_Script_Open_Parameters_t *ScriptOpenParameters)
{
   TIBTS_Script_Handle_t         ret_val;
   TIBTS_Imlementation_Handle_t  ImplementationHandle;
   ScriptParameters_t           *ScriptParameters;
   BTSFileHeader_t               BTSFileHeader;
   Boolean_t                     Error;

   /* Intentionally don't check on the open parameters here, leave it up*/
   /* to the TIBTS implementation (TIBTSIM.c) to handle checking the    */
   /* parameters.  This is done because on some devices the script open */
   /* parameters may actually not even be used and NULL is a valid use  */
   /* case.                                                             */
   if((ImplementationHandle = TIBTS_Open(ScriptOpenParameters)))
   {
      /* Allocate memory for the script parameters.                     */
      if((ScriptParameters = (ScriptParameters_t *)BTPS_AllocateMemory(sizeof(ScriptParameters_t))))
      {
         Error = FALSE;

         /* Check if this is a script stored in the format of a memory  */
         /* array.                                                      */
         if(!(ScriptOpenParameters->ScriptFlags & TIBTS_SCRIPT_FLAGS_MEMORY_ARRAY_FORMAT))
         {
            /* This is a not a memory array-formatted script, attempt to*/
            /* read the BTS header from the script.                     */
            if(TIBTS_Read(ImplementationHandle, sizeof(BTSFileHeader_t), sizeof(BTSFileHeader_t), (Byte_t *)&BTSFileHeader) != sizeof(BTSFileHeader_t))
            {
               /* We could not read the BTS header from the script, flag*/
               /* the error to the caller.                              */
               Error = TRUE;
            }
         }

         if(!Error)
         {
            /* No errors have occurred, set the output parameters for   */
            /* the caller.                                              */
            ScriptParameters->ImplementationHandle = ImplementationHandle;
            ScriptParameters->ScriptFlags          = ScriptOpenParameters->ScriptFlags;

            /* Flag success to the caller.                              */
            ret_val                                = (TIBTS_Script_Handle_t *)ScriptParameters;
         }
         else
         {
            /* An error occurred, close the script.                     */
            TIBTS_Close(ImplementationHandle);

            /* Pass the error back to the caller.                       */
            ret_val = NULL;
         }
      }
      else
      {
         /* We could not allocate memory for the local script           */
         /* parameters, close the script.                               */
         TIBTS_Close(ImplementationHandle);

         /* Pass the error back to the caller.                          */
         ret_val = NULL;
      }
   }
   else
   {
      /* We could not open the script, pass the error back to the       */
      /* caller.                                                        */
      ret_val = NULL;
   }

   return(ret_val);
}

   /* The following function closes the Bluetooth Script and releases   */
   /* any memory associated with the script.  It returns 0 on success   */
   /* and a negative error code otherwise.                              */
int BTPSAPI TIBTS_Close_Script(TIBTS_Script_Handle_t ScriptHandle)
{
   int                 ret_val;
   ScriptParameters_t *ScriptParameters;

   ScriptParameters = ScriptHandle;

   /* Check for semi-valid input.                                       */
   if(ScriptParameters)
   {
      /* The input parameters are not null, attempt to close the script.*/
      ret_val = TIBTS_Close(ScriptParameters->ImplementationHandle);

      /* Free the script parameters.                                    */
      BTPS_FreeMemory(ScriptParameters);
   }
   else
   {
      /* The input passed in is invalid, pass the error back to the     */
      /* caller.                                                        */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}

   /* The following function retrieves the next SCript Action from the  */
   /* BTS Script.  It takes as input a Script Handle and an address     */
   /* specifying where the Action's Parameters will be written.  This   */
   /* function returns 0 on success, TIBTS_ERROR_END_OF_SCRIPT if no    */
   /* more actions were found in the script, and a negative value if an */
   /* error occurred.                                                   */
int BTPSAPI TIBTS_Get_Next_Action(TIBTS_Script_Handle_t ScriptHandle, TIBTS_Script_Action_t *ScriptAction)
{
   int                 ret_val;
   int                 NumberBytesRead;
   Boolean_t           SupportedActionFound;
   ScriptParameters_t *ScriptParameters;
   BTSActionHeader_t   BTSActionHeader;
   DelayAction_t       DelayAction;

   ScriptParameters = ScriptHandle;

   /* Check for semi-valid input.                                       */
   if((ScriptParameters) && (ScriptAction))
   {
      /* The input appears to valid, next check if the format of the    */
      /* script is a memory array.                                      */
      if(ScriptParameters->ScriptFlags & TIBTS_SCRIPT_FLAGS_MEMORY_ARRAY_FORMAT)
      {
         /* The format of the script is a memory array, read the next   */
         /* Send Command Action from the script.                        */
         ret_val = GetSendHCICommandAction(ScriptParameters, &(ScriptAction->ActionData.SendHCICommandActionData));
      }
      else
      {
         ret_val              = 0;
         SupportedActionFound = FALSE;

         /* Continue to read in actions from the script.                */
         while((!ret_val) && (!SupportedActionFound) && ((NumberBytesRead = TIBTS_Read(ScriptParameters->ImplementationHandle, sizeof(BTSActionHeader_t), sizeof(BTSActionHeader_t), (Byte_t *)&BTSActionHeader)) == sizeof(BTSActionHeader_t)))
         {
            /* Assign the action type and size.                         */
            BTSActionHeader.Type = READ_UNALIGNED_WORD_LITTLE_ENDIAN(&BTSActionHeader.Type);
            BTSActionHeader.Size = READ_UNALIGNED_WORD_LITTLE_ENDIAN(&BTSActionHeader.Size);

            switch(BTSActionHeader.Type)
            {
               case ACTION_SEND_COMMAND:
                  /* This is a Send HCI Command Action, read the        */
                  /* action's information from the script.              */
                  ret_val = GetSendHCICommandAction(ScriptParameters, &(ScriptAction->ActionData.SendHCICommandActionData));

                  if(!ret_val)
                  {
                     ScriptAction->Type = atSendHCICommand;
                  }

                  SupportedActionFound = TRUE;
                  break;

               case ACTION_DELAY:
                  /* This is a delay action, read the action's          */
                  /* information from the script.                       */
                  if((ret_val = TIBTS_Read(ScriptParameters->ImplementationHandle, DELAY_ACTION_SIZE, DELAY_ACTION_SIZE, (Byte_t *)&DelayAction)) == DELAY_ACTION_SIZE)
                  {
                     ScriptAction->Type                             = atDelay;
                     ScriptAction->ActionData.DelayActionData.Delay = READ_UNALIGNED_DWORD_LITTLE_ENDIAN(&DelayAction.MillisecondDelay);
                     ret_val                                        = 0;
                  }

                  SupportedActionFound = TRUE;
                  break;

               default:
                  /* This is not a supported action, check if our buffer*/
                  /* is large enough to read in the data from this      */
                  /* action.                                            */
                  if(BTSActionHeader.Size <= sizeof(ScriptParameters->CommandBuffer))
                  {
                     /* Our buffer is large enough, attempt to read the */
                     /* action's data from the script.                  */
                     if((NumberBytesRead = TIBTS_Read(ScriptParameters->ImplementationHandle, BTSActionHeader.Size, sizeof(ScriptParameters->CommandBuffer), ScriptParameters->CommandBuffer)) != BTSActionHeader.Size)
                     {
                        /* The remainder of the action bytes could not  */
                        /* be read, flag the error the caller.          */
                        ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
                     }
                  }
                  else
                  {
                     /* Our buffer is not large enough to read in the   */
                     /* data for this action.  No BTS scripts have been */
                     /* encountered so far that have more than 256 bytes*/
                     /* of command data (except for send commands which */
                     /* may have a few more bytes than 256, the commands*/
                     /* are handled differently just above).  Flag this */
                     /* as an error to the caller.                      */
                     ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
                  }
                  break;
            }
         }

         /* Check if the return value is 0 and number of bytes that were*/
         /* read is 0.                                                  */
         if((!ret_val) && (NumberBytesRead == 0))
         {
            /* The return value is 0 and number of bytes that were read */
            /* is 0, we have reached the end of the script.  Flag this  */
            /* event to the caller.                                     */
            ret_val = TIBTS_ERROR_END_OF_SCRIPT;
         }
      }
   }
   else
   {
      /*  The parameters passed in are invalid, flag the error to the   */
      /*  caller.                                                       */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}

   /* The following function retrieves the next HCI Command from a BTS  */
   /* Script that is stored in a Memory Array.  It takes as input an    */
   /* address where the length of the data can be read from.  The second*/
   /* parameter specifies the location of the data.  And the third      */
   /* parameter specifies the address where the Command's Parameters    */
   /* will be written to.  This function returns 0 on success,          */
   /* TIBTS_ERROR_END_OF_SCRIPT if no more HCI Commands were found in   */
   /* the script, and a negative value if an error occurred.            */
   /* * NOTE * This command automatically updates the Data Length       */
   /*          parameter to the number of remaining bytes in the array, */
   /*          and also updates the the current location of the Data    */
   /*          pointer within the array.                                */
int BTPSAPI TIBTS_Get_Next_HCI_Command_Memory_Array(DWord_t *DataLength, Byte_t **Data, TIBTS_Send_HCI_Command_Action_Data_t *SendHCICommandActionData)
{
   int                  ret_val;
   SendCommandAction_t *SendCommandAction;
   Byte_t              *TempData;
   DWord_t              TempDataLength;
   Word_t               CommandOpCode;

   /* Check for semi-valid input.                                       */
   if((DataLength) && (Data) && (*Data) && (SendHCICommandActionData))
   {
      /* The input appears to valid, next check if there is any data    */
      /* remaining to be read from the array.                           */
      if((*DataLength) > 0)
      {
         /* Check if there is enough remaining data to read in the next */
         /* send command action.                                        */
         if((*DataLength) > SEND_COMMAND_ACTION_SIZE)
         {
            /* There is enough data, next note the original data length */
            /* and data pointer passed in to the function.              */
            TempDataLength     = *DataLength;
            TempData           = *Data;

            /* Assign the Send Command Action to the first byte in the  */
            /* data.                                                    */
            SendCommandAction  = (SendCommandAction_t *)TempData;

            /* Increment the data length and data pointer.              */
            TempDataLength    -= SEND_COMMAND_ACTION_SIZE;
            TempData          += SEND_COMMAND_ACTION_SIZE;

            /* Check if there is enough data remaining in the array to  */
            /* read in send command action's data.                      */
            if(TempDataLength >= SendCommandAction->CommandDataLength)
            {
               /* There is enough data remaining in the array to read in*/
               /* the next send command action, next read in the        */
               /* command's 2 byte op code, being careful not to        */
               /* read/write 2 bytes at an odd address.                 */
               CommandOpCode                       = READ_UNALIGNED_WORD_LITTLE_ENDIAN(&SendCommandAction->CommandOpCode);

               /* Set the output parameters for the caller.             */
               SendHCICommandActionData->OGF               = TIBTS_COMMAND_OPCODE_TO_OGF(CommandOpCode);
               SendHCICommandActionData->OCF               = TIBTS_COMMAND_OPCODE_TO_OCF(CommandOpCode);
               SendHCICommandActionData->CommandDataLength = SendCommandAction->CommandDataLength;

               if(SendHCICommandActionData->CommandDataLength)
                  SendHCICommandActionData->CommandData = SendCommandAction->CommandData;
               else
                  SendHCICommandActionData->CommandData = NULL;

               /* Increment our local data length and data pointer      */
               /* variables.                                            */
               TempDataLength -= SendCommandAction->CommandDataLength;
               TempData       += SendCommandAction->CommandDataLength;

               /* Update the data length and data pointer parameters    */
               /* passed in to this function.                           */
               *DataLength     = TempDataLength;
               *Data           = TempData;

               /* Flag success to the caller.                           */
               ret_val         = 0;
            }
            else
            {
               /* There is not enough data in this buffer to specify all*/
               /* of the send command's action's data, flag the error to*/
               /* the caller.                                           */
               ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
            }
         }
         else
         {
            /* There is enough remaining data to read in the next send  */
            /* command action, flag the error to the caller.            */
            ret_val = TIBTS_ERROR_INVALID_SCRIPT_FORMAT;
         }
      }
      else
      {
         /* There is no data remaining to be read, flag to the caller   */
         /* that we have reached the end of the script.                 */
         ret_val = TIBTS_ERROR_END_OF_SCRIPT;
      }
   }
   else
   {
      /* The input parameters are not valid, flag the error back to the */
      /* caller.                                                        */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}

// References:
// [1] BTS Script Format and Integration Texas Instruments Application Report PDF (SWAA042�March 2008).
// [2] http://docs.huihoo.com/doxygen/linux/kernel/3.7/ti__wilink__st_8h_source.html
// [3] http://git.kernel.org/cgit/linux/kernel/git/next/linux-next.git/tree/drivers/misc/ti-st/st_kim.c
