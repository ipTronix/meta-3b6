/*****< tibtsim.c >************************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  TIBTSIM - Stonestreet One Bluetooth Protocol Stack Texas Instrument's     */
/*            Bluetooth Script (BTS) Platform Specific Implementation.        */
/*                                                                            */
/*  Author:  Samuel Hishmeh                                                   */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/19/13  S. Hishmeh     Initial creation.                               */
/******************************************************************************/
#include "SS1BTPS.h"            /* Bluetopia API Prototypes/Constants.        */
#include "TIBTSIM.h"

   /* The following function opens a Texas Instrument's Bluetooth       */
   /* Script.  It takes as its only input the script-open parameters.   */
   /* It returns a non-null handle which can be used to read and close  */
   /* the script on success, and NULL if an error occurred.             */
TIBTS_Imlementation_Handle_t BTPSAPI TIBTS_Open(TIBTS_Script_Open_Parameters_t *Script_Open_Parameters)
{
   TIBTS_Imlementation_Handle_t ret_val;

   /* Check for semi-valid input.                                       */
   if((Script_Open_Parameters) && (Script_Open_Parameters->ScriptPath))
   {
      /* The input pointers are not null, attempt to open the BTS       */
      /* Script.                                                        */
      ret_val = (TIBTS_Imlementation_Handle_t *)fopen(Script_Open_Parameters->ScriptPath, "r");
   }
   else
   {
      /* Invalid input, flag the error to the caller.                   */
      ret_val = NULL;
   }

   return(ret_val);
}

   /* The following function closes a Texas Instrument's Bluetooth      */
   /* Script.  It takes as input the handle returned from TIBTS_Open(). */
   /* It returns 0 on success and a negative error code otherwise.      */
int BTPSAPI TIBTS_Close(TIBTS_Imlementation_Handle_t Imlementation_Handle)
{
   int   ret_val;
   FILE *ScriptFilePtr;

   ScriptFilePtr = (FILE *)Imlementation_Handle;

   /* Check for semi-valid input.                                       */
   if(ScriptFilePtr)
   {
      /* The input pointers are not null, close the file.               */
      ret_val = fclose(ScriptFilePtr);
   }
   else
   {
      /* Invalid input, flag the error to the caller.                   */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}

   /* The following function reads from a Texas Instrument's Bluetooth  */
   /* Script.  It takes as input the handle returned from TIBTS_Open(), */
   /* the number of bytes to read, the length of the destination buffer,*/
   /* and a pointer to a buffer where the data will be stored.  It      */
   /* returns the number of bytes actually read on success, 0 if the end*/
   /* of the script has been reached, and a negative error code if a    */
   /* failure occurred.                                                 */
int BTPSAPI TIBTS_Read(TIBTS_Imlementation_Handle_t Imlementation_Handle, Word_t NumberBytes, Word_t BufferLength, Byte_t *Buffer)
{
   int     ret_val;
   size_t  NumberReadBytes;
   FILE   *ScriptFilePtr;

   ScriptFilePtr = (FILE *)Imlementation_Handle;

   /* Check for semi-valid input.                                       */
   if((ScriptFilePtr) && (NumberBytes) && (Buffer) && (BufferLength) && (BufferLength >= NumberBytes))
   {
      /* The input appears to valid, read from the file.                */
      if((NumberReadBytes = fread(Buffer, 1, (size_t)NumberBytes, ScriptFilePtr)) <= 0)
      {
         /* An error occurred or we read 0 bytes, lets's figure out what*/
         /* caused the error.  First check if we've reach the end of the*/
         /* file.                                                       */
         if(feof(ScriptFilePtr))
         {
            /* We have reached the end of the file, return 0 to the     */
            /* caller.                                                  */
            ret_val = 0;
         }
         else
         {
            /* Check if the error code is less than zero.               */
            if(NumberReadBytes < 0)
            {
               /* The error code is less than zero, pass the error back */
               /* to the caller.                                        */
               ret_val = (int)NumberReadBytes;
            }
            else
            {
               /* The error code is 0, pass an API error back to the    */
               /* caller.                                               */
               ret_val = TIBTS_ERROR_COULD_NOT_READ_SCRIPT;
            }
         }
      }
      else
      {
         /* The call to read data was successful, set the return value  */
         /* to the number of bytes read.                                */
         ret_val = (int)NumberReadBytes;
      }
   }
   else
   {
      /* Invalid input, flag the error to the caller.                   */
      ret_val = BTPS_ERROR_INVALID_PARAMETER;
   }

   return(ret_val);
}
