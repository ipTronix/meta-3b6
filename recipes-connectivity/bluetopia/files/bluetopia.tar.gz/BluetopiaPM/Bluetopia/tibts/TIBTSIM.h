/*****< tibtsim.h >************************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  TIBTSIM - Stonestreet One Bluetooth Protocol Stack Texas Instrument's     */
/*            Bluetooth Script (BTS) Platform Specific Implementation.        */
/*                                                                            */
/*  Author:  Samuel Hishmeh                                                   */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   09/19/13  S. Hishmeh     Initial creation.                               */
/******************************************************************************/
#ifndef __TIBTSIMH__
#define __TIBTSIMH__

#include "TIBTSAPI.h"           /* Bluetooth API Type Definitions.      */
#include "BTTypes.h"            /* Bluetooth basic type definitions     */

   /* The following type definition is used as a handle to access data  */
   /* contained in the Bluetooth Script.                                */
typedef void *TIBTS_Imlementation_Handle_t;

   /* The following function opens a Texas Instrument's Bluetooth       */
   /* Script.  It takes as its only input the script-open parameters.   */
   /* It returns a non-null handle which can be used to read and close  */
   /* the script on success, and NULL if an error occurred.             */
TIBTS_Imlementation_Handle_t BTPSAPI TIBTS_Open(TIBTS_Script_Open_Parameters_t *Script_Open_Parameters);

   /* The following function closes a Texas Instrument's Bluetooth      */
   /* Script.  It takes as input the handle returned from TIBTS_Open(). */
   /* It returns 0 on success and a negative error code otherwise.      */
int BTPSAPI TIBTS_Close(TIBTS_Imlementation_Handle_t Imlementation_Handle);

   /* The following function reads from a Texas Instrument's Bluetooth  */
   /* Script.  It takes as input the handle returned from TIBTS_Open(), */
   /* the number of bytes to read, the length of the destination buffer,*/
   /* and a pointer to a buffer where the data will be stored.  It      */
   /* returns the number of bytes actually read on success, 0 if the end*/
   /* of the script has been reached, and a negative error code if a    */
   /* failure occurred.                                                 */
int BTPSAPI TIBTS_Read(TIBTS_Imlementation_Handle_t Imlementation_Handle, Word_t NumberBytes, Word_t BufferLength, Byte_t *Buffer);

#endif
