/*****< btpmipc.h >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMIPC - Interprocess Communication Abstraction layer for Stonestreet    */
/*            One Bluetooth Protocol Stack Platform Manager.                  */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   06/04/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPMIPCH__
#define __BTPMIPCH__

#include "BTAPITyp.h"            /* Bluetooth API Type Definitions.           */

   /* The following constants represent reserved Address ID's that are  */
   /* used internally by this module.                                   */
#define IPC_BROADCAST_ADDRESS_ID                         0x00000000
#define IPC_SERVER_ADDRESS_ID                            0xFFFFFFFF

   /* IPC Event Types.                                                  */
typedef enum
{
   etIPC_Client_Registration,
   etIPC_Client_Un_Registration,
   etIPC_Message_Received
} IPC_Event_Type_t;

   /* The following structure represents the data that is used with the */
   /* etIPC_Client_Registration and etIPC_Client_UnRegistration events. */
   /* The ClientAddress member contains the Client Address of the Client*/
   /* that was Registered/Un-Registered.                                */
typedef struct _tagIPC_Client_Registration_Data_t
{
   unsigned int ClientAddress;
} IPC_Client_Registration_Data_t;

#define IPC_CLIENT_REGISTRATION_DATA_SIZE                (sizeof(IPC_Client_Registration_Data_t))

   /* The following structure represents the data that is used with the */
   /* etIPC_Client_Registration and etIPC_Client_UnRegistration events. */
   /* The ClientAddress member contains the Client Address of the Client*/
   /* that Registered/Un-Registered.                                    */
typedef struct _tagIPC_Message_Received_Data_t
{
   unsigned int   ClientAddress;
   unsigned int   MessageLength;
   unsigned char *MessageData;
} IPC_Message_Received_Data_t;

#define IPC_MESSAGE_RECEIVED_DATA_SIZE                   (sizeof(IPC_Message_Received_Data_t))

   /* The following structure represents the container structure for    */
   /* Holding all IPC Event Data Data.                                  */
typedef struct _tagIPC_Event_Data_t
{
   IPC_Event_Type_t Event_Data_Type;
   unsigned int     Event_Data_Size;
   union
   {
      IPC_Client_Registration_Data_t IPC_Client_Registration_Data;
      IPC_Message_Received_Data_t    IPC_Message_Received_Data;
   } Event_Data;
} IPC_Event_Data_t;

#define IPC_EVENT_DATA_SIZE                             (sizeof(IPC_Event_Data_t))

   /* The following declared type represents the Prototype Function for */
   /* an IPC Event Callback.  This function will be called whenever an  */
   /* IPC event occurs.  This function passes to the caller the IPC     */
   /* Event Data that occurred, and the IPC Event Callback Parameter    */
   /* that was specified when this Callback was installed.  This        */
   /* function is guaranteed NOT to be invoked more than once           */
   /* simultaneously for the specified installed callback (i.e. this    */
   /* function DOES NOT have be reentrant).  Because of this, the       */
   /* processing in this function should be as efficient as possible.   */
   /* It should also be noted that this function is called in the Thread*/
   /* Context of a Thread that the User does NOT own.  Therefore,       */
   /* processing in this function should be as efficient as possible    */
   /* (this argument holds anyway because another IPC Event will not be */
   /* processed while this function call is outstanding).               */
   /* ** NOTE ** For messages that are actually received through the    */
   /*            IPC mechansim (etIPC_Message_Received), the callee is  */
   /*            responsible for freeing the specified message.  This   */
   /*            means that when the callee is finished with the actual */
   /*            received message data it should call the               */
   /*            IPC_FreeReceivedMessageData() function, passing the    */
   /*            MessageData member.  Failure to abide by this will     */
   /*            result in resource leaks.  Note this is ONLY applicable*/
   /*            to the etIPC_Message_Received message.                 */
   /* ** NOTE ** This function MUST NOT block and wait for events that  */
   /*            can only be satisfied by Receiving IPC Events.  A      */
   /*            deadlock WILL occur because NO IPC Event Callbacks will*/
   /*            be issued while this function is currently outstanding.*/
typedef void (BTPSAPI *IPC_Event_Callback_t)(IPC_Event_Data_t *IPC_Event_Data, void *CallbackParameter);

   /* The following function is responsible for initializing the IPC    */
   /* Handler for the current Platform Manager Entity (either client or */
   /* server).  The first parameter is a pointer to platform specific   */
   /* Callback Information.  The second and third parameter specify the */
   /* Event Callback function and parameter that is called when an IPC  */
   /* Event occurs (respectively).  This function will return zero if   */
   /* the IPC Handler was able to be intialized correctly, or a negative*/
   /* return error code if there was an error initializing the IPC      */
   /* Handler.                                                          */
int IPC_Initialize(void *InitializationInfo, IPC_Event_Callback_t EventCallbackFunction, void *CallbackParameter);

   /* The following function is responsible for instructing the IPC     */
   /* Handler Module to cleanup any resources that it is currently      */
   /* holding.                                                          */
void IPC_Cleanup(void);

   /* The following function is responsible for sending the specified   */
   /* Message through the Bluetopia Platform Manager services.  This    */
   /* function accepts as input the Destination Routing ID that the     */
   /* message is destined for, followed by the Length of the data (in   */
   /* bytes), followed by a pointer to the actual data itself.  The     */
   /* Destination Address ID will be assigned by this module (either    */
   /* from a Registration message and/or the Server Destination Routing */
   /* ID.  Note that the ID of 0x00000000 is considered a broadcast     */
   /* Destination.  Also note that the data sent by this module is      */
   /* opaque and this module has no concept of matching messages        */
   /* (requests vs. responses).  This function returns zero if          */
   /* successful, or a negative return error code if there was an error */
   /* sending the message.                                              */
int IPC_SendMessage(unsigned int AddressID, unsigned int MessageLength, unsigned char *MessageData);

   /* The following function is provided to allow a mechanism to free   */
   /* any previously allocated Received Message Data.  More             */
   /* specifically, this function allows the caller a means to free     */
   /* allocated message data (the MessageData member of the             */
   /* IPC_Message_Received_Data_t structure of an etIPC_Message_Received*/
   /* event).  This function IS ONLY to be called for the above         */
   /* mentioned message.                                                */
   /* * NOTE * This function *MUST* be called for the MessageData       */
   /*          member for EVERY etIPC_Message_Received event.           */
void IPC_FreeReceivedMessageData(unsigned char *MessageData);

#endif
