/*****< btpmipc.c >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMIPC - Interprocess Communication Abstraction layer for Stonestreet    */
/*            One Bluetooth Protocol Stack Platform Manager.                  */
/*                                                                            */
/*  Author:  Greg Hensley                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   06/04/10  G. Hensley     Initial creation.                               */
/******************************************************************************/
#include <stdio.h>

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "BTPSKRNL.h"            /* BTPS Kernel Prototypes/Constants.         */

#include "BTPMDBG.h"             /* BTPM Debug Module Prototypes/Constants.   */
#include "BTPMERR.h"             /* BTPM Error Prototypes/Constants.          */
#include "BTPMIPC.h"             /* BTPM IPC Module Prototypes/Constants.     */

   /* The following constant represents the largest supported Socket    */
   /* Packet supported by the platform.                                 */
#define IPC_SOCKET_PATH_MAX                  (sizeof(struct sockaddr_un) - ((unsigned int )&(((struct sockaddr_un *)0)->sun_path)))

   /* Note the Configured Default Socket Path (of default it to a       */
   /* default if not specified).                                        */
#ifdef BTPM_LINUX_IPC_DEVICE_PATH

   #define IPC_SOCKET_PATH_DEFAULT           BTPM_LINUX_IPC_DEVICE_PATH

#else

   #define IPC_SOCKET_PATH_DEFAULT           "/tmp/SS1BTPMS"

#endif

typedef enum
{
   ccShutdown,
   ccWrite
} IPC_Control_Code_t;

typedef struct _tagThreadInitData_t
{
   int                   CtrlSocketFd;
   int                   DataSocketFd;
   IPC_Event_Callback_t  EventCallbackFunction;
   void                 *CallbackParameter;
} ThreadInitData_t;

   /* Internal Variables to this Module (Remember that all variables    */
   /* declared static are initialized to 0 automatically by the         */
   /* compiler as part of standard C/C++).                              */

   /* Variable which serves as a global flag about whether this module  */
   /* is initialized or not.                                            */
static Boolean_t Initialized;

   /* Variables which hold the file descriptors for the control pipe    */
   /* used to send control messages to the traffic thread.              */
static int ThreadControlSocketW = -1;
static int ThreadControlSocketR = -1;

   /* Variable which holds the file descriptor for the connection to    */
   /* the server.                                                       */
static int ServerFd = -1;

   /* Variable which holds a reference to the traffic thread.           */
static pthread_t Thread = 0;

   /* Internal Function Prototypes.                                     */
static int ForcedSocketWrite(int Fd, struct msghdr *Msg, int Flags);
static void *IPCThread(void *Arg);

   /* The following function is used to transmit a prepared msghdr      */
   /* structure over an open socket in a reliable way. This routine     */
   /* will ensure that the message is sent regardless of signal         */
   /* interruption. This function returns zero if successful, or a      */
   /* negative return error code if there was an error sending the      */
   /* message.                                                          */
static int ForcedSocketWrite(int Fd, struct msghdr *Msg, int Flags)
{
   int           ret_val = 0;
   Boolean_t     Sent = FALSE;
   struct pollfd Fds;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* We will continue to try to send the message until either it is    */
   /* sent or we encounter an unrecoverable error.                      */
   while(!Sent)
   {
      errno = 0;

      /* First, just try to send the data.                              */
      if(sendmsg(Fd, Msg, Flags) > 0)
      {
         DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Message sent successfully\n"));
         Sent    = TRUE;
         ret_val = 0;
      }
      else
      {
         /* Writing failed. If the reason is fatal (not EAGAIN or       */
         /* EWOULDBLOCK), then fail out immeidately.                    */
         if((errno != EAGAIN) && (errno != EWOULDBLOCK))
         {
            /* This failure is unrecoverable.                           */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FAILURE), ("Failed to send IPC message for fd %d (errno %d, %s)\n", Fd, errno, strerror(errno)));

            ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_SEND_DATA;
            Sent    = TRUE;

            //XXX Explicitly handle each possible error code.
         }
         else
         {
            /* We are advised to attempt the write again.               */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Failed to send message... retrying.\n"));

            /* Prepare a pollfd structure for the poll() routine.       */
            Fds.fd      = Fd;
            Fds.events  = POLLOUT;
            Fds.revents = 0;

            /* We will continue to try to send the message until either */
            /* it is sent or we encounter an unrecoverable error.       */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Waiting for fd %d to become available (0x%04x / 0x%04x)\n", Fds.fd, Fds.events, Fds.revents));

            errno = 0;

            /* poll() for the writable status of the file descriptor.   */
            if((ret_val = poll(&Fds, 1, 1000)) >= 0)
            {
               if(ret_val == 0)
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Timed out waiting for socket to become available... attempting to send, anyway.\n"));
               else
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Socket reports status: events: 0x%04x  revents: 0x%04x\n", Fds.events, Fds.revents));
            }
            else
               DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to query socket status: errno: %d (%s)\n", errno, strerror(errno)));
         }
      }
   }

   return(ret_val);
}

   /* The following function is the entry-point for the IPC traffic     */
   /* thread.  This thread is responsible for receiving messages from   */
   /* the server.  Events (such as incoming messages) are dispatched to */
   /* the callback routine provided to IPC_Initialize().  Initialization*/
   /* is announced as an etIPC_Client_Registration event and shutdown as*/
   /* an etIPC_Client_Un_Registration event, indicating clear to send   */
   /* and not-clear to send, respectively.  The thread maintains a      */
   /* read-only pipe endpoint through which commands can be issued to   */
   /* the thread.  If this pipe or the server connection ever close, the*/
   /* thread will shut down.  The thread can also be shut down by       */
   /* sending an ccShutdown over the control pipe.  A shutdown event is */
   /* accompanied by an unregistration event for the server connection. */
   /* Restoring the connection requires calling IPC_Cleanup() followed  */
   /* by IPC_Initialize().                                              */
static void *IPCThread(void *Arg)
{
   int                   ret_val = 0;
   int                   ControlSocket;
   int                   DataSocket;
   void                 *CallbackParameter;
   int                   i;
   int                   Fd;
   void                 *RecvBuffer;
   int                   RecvLengthExp;
   int                   RecvLengthAct;
   struct iovec          Iov;
   struct msghdr         Msg;
   struct pollfd         Fds[2];
   IPC_Event_Data_t      EventData;
   IPC_Control_Code_t    ControlCode;
   const unsigned int    FdsLength = sizeof(Fds) / sizeof(Fds[0]);
   IPC_Event_Callback_t  EventCallbackFunction = NULL;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Make sure the thread argument blob appears valid.                 */
   if((Arg) && (((ThreadInitData_t *)Arg)->EventCallbackFunction))
   {
      /* Extract the data from the argument blob and free the           */
      /* associated memory.                                             */
      ControlSocket         = ((ThreadInitData_t *)Arg)->CtrlSocketFd;
      DataSocket            = ((ThreadInitData_t *)Arg)->DataSocketFd;
      EventCallbackFunction = ((ThreadInitData_t *)Arg)->EventCallbackFunction;
      CallbackParameter     = ((ThreadInitData_t *)Arg)->CallbackParameter;

      BTPS_FreeMemory(Arg);

      /* Set up the shared pollfd list for monitoring the control and   */
      /* listen descriptors.                                            */
      Fds[0].fd = ControlSocket;
      Fds[1].fd = DataSocket;

      for(i=0;i<FdsLength;i++)
      {
         Fds[i].events  = POLLIN;
         Fds[i].revents = 0;

         fcntl(Fds[i].fd, F_SETFL, fcntl(Fds[i].fd, F_GETFL) | O_NONBLOCK);
      }

      /* Prepare the msghdr structure for receiving messages.           */
      BTPS_MemInitialize(&Msg, 0, sizeof(Msg));

      Msg.msg_iov    = &Iov;
      Msg.msg_iovlen = 1;

      /* Notify the upper layer that data can be sent to the other end  */
      /* of the connection now, by dispatching a registration event for */
      /* the server via the IPC callback.                               */
      EventData.Event_Data_Type                                       = etIPC_Client_Registration;
      EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

      EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = IPC_SERVER_ADDRESS_ID;

      __BTPSTRY
      {
         (*EventCallbackFunction)(&EventData, CallbackParameter);
      }
      __BTPSEXCEPT(1)
      {
         /* Do Nothing.                                                 */
      }

      /* Continue operating until we encounter an error condition, or   */
      /* the thread is interrupted (causing poll() to return before any */
      /* interesting events occur on the listed sockets.                */
      while((ret_val == 0) && (poll(Fds, FdsLength, -1) > 0))
      {
         /* Find the first file descriptor which has a pending event.   */
         for(i=0;i<FdsLength;i++)
         {
            if(Fds[i].revents)
               break;
         }

         /* Check to be sure we found a descriptor. This should never   */
         /* fail since we should not reach this code unless poll()      */
         /* reported that at least one socket experienced an event.     */
         if(i < FdsLength)
         {
            Fd = Fds[i].fd;

            /* Check for the special case of the interesting socket     */
            /* being the control pipe.                                  */
            if(Fd == ControlSocket)
            {
               DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Handling event on the control socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

               /* It's possible for the POLLIN event to occur alongside */
               /* an error, so check for errors first.                  */
               if((Fds[i].revents & POLLHUP) || (Fds[i].revents & POLLERR))
               {
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket closed from remote side (%d, 0x%04x).\n", Fd, Fds[i].revents));

                  /* The control socket was closed from the other end.  */
                  /* This is a critical socket, so there's nothing to   */
                  /* do but shutdown.                                   */
                  ret_val = BTPM_ERROR_CODE_IPC_PIPE_ERROR;
               }
               else
               {
                  /* No errors, so double-check that we did get a       */
                  /* POLLIN event. This should never fail since we are  */
                  /* indicating to poll() that we are only interested   */
                  /* in POLLIN events.                                  */
                  if(Fds[i].revents & POLLIN)
                  {
                     /* Try to read a control code from the control     */
                     /* pipe.                                           */
                     if((RecvLengthAct = read(Fd, &ControlCode, sizeof(IPC_Control_Code_t))) > 0)
                     {
                        /* Make sure we received an entire code.        */
                        if(RecvLengthAct == sizeof(IPC_Control_Code_t))
                        {
                           /* Currently, the only implemented code is   */
                           /* IPC Control Shutdown, which stops the     */
                           /* thread.                                   */
                           if(ControlCode == ccShutdown)
                           {
                              DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Received 'shutdown' command from control socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

                              /* Shutdown IPC system. Break out of      */
                              /* polling loop where I/O will be         */
                              /* disconnected cleanly. Setting a        */
                              /* positive return code will break out of */
                              /* the polling loop while not indicating  */
                              /* any error.                             */
                              ret_val = 1;
                           }
                        }
                        else
                        {
                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket incomplete read. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                           /* There was a problem reading from the      */
                           /* control pipe. This is a fatal error.      */
                           ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_RECEIVE_DATA;
                        }
                     }
                  }
                  else
                  {
                     DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket is in an error state. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                     /* poll() reported an error on the socket. Since   */
                     /* this is our control socket, there's nothing to  */
                     /* do but shutdown.                                */
                     ret_val = BTPM_ERROR_CODE_IPC_PIPE_ERROR;
                  }
               }
            }
            else
            {
               /* The event occurred on the server socket.              */
               DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Handling event on the server comms socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

               /* It's possible for the POLLIN event to occur alongside */
               /* an error, so check for errors first.                  */
               if((Fds[i].revents & POLLHUP) || (Fds[i].revents & POLLERR))
               {
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Server-side disconnected or error on socket. Notifying upper layers and closing descriptor %d\n", Fd));

                  /* The server shut down their end of the socket       */
                  /* connection, so shutdown the thread.                */
                  ret_val = BTPM_ERROR_CODE_IPC_SERVER_CLOSED;
               }
               else
               {
                  /* No errors, so double-check that we did get a       */
                  /* POLLIN event. This should never fail since we are  */
                  /* indicating to poll() that we are only interested   */
                  /* in POLLIN events.                                  */
                  if(Fds[i].revents & POLLIN)
                  {
                     /* There is incoming data from a client. First,    */
                     /* determine how much data is pending. Using       */
                     /* SOCK_DGRAM sockets, the FIONREAD ioctl will     */
                     /* always return the size of the next pending      */
                     /* message, not the total data in the socket       */
                     /* buffer.                                         */
                     RecvLengthExp = 0;
                     if(ioctl(Fd, FIONREAD, &RecvLengthExp) == 0)
                     {
                        /* Allocate enough space off the heap to        */
                        /* contain the message.                         */
                        if((RecvBuffer = BTPS_AllocateMemory(RecvLengthExp)) != NULL)
                        {
                           /* Set up the msghdr structure with the new  */
                           /* buffer.                                   */
                           Iov.iov_base  = RecvBuffer;
                           Iov.iov_len   = RecvLengthExp;

                           /* Try to receive the message.               */
                           RecvLengthAct = recvmsg(Fd, &Msg, 0);

                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Received server-side message: %d bytes (%d, 0x%04x, 0x%08x).\n", RecvLengthAct, Fd, Fds[i].revents, Msg.msg_flags));

                           /* Double-check that the message was         */
                           /* truncated due to a too-small buffer. This */
                           /* should never happen unless the FIONREAD   */
                           /* ioctl is broken.                          */
                           if((Msg.msg_flags & MSG_TRUNC) == 0)
                           {
                              DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Sending server-side message to upper layer (%d, 0x%04x, 0x%08x).\n", Fd, Fds[i].revents, Msg.msg_flags));

                              /* The message is good, so dispatch       */
                              /* the event to the IPC callback. The     */
                              /* callback will own the buffer now, so   */
                              /* we don't need to worry releasing the   */
                              /* memory.                                */
                              EventData.Event_Data_Type                                    = etIPC_Message_Received;
                              EventData.Event_Data_Size                                    = IPC_EVENT_DATA_SIZE;

                              EventData.Event_Data.IPC_Message_Received_Data.ClientAddress = Fd;
                              EventData.Event_Data.IPC_Message_Received_Data.MessageLength = RecvLengthAct;
                              EventData.Event_Data.IPC_Message_Received_Data.MessageData   = RecvBuffer;

                              __BTPSTRY
                              {
                                 (*EventCallbackFunction)(&EventData, CallbackParameter);
                              }
                              __BTPSEXCEPT(1)
                              {
                                 /* Do Nothing.                         */
                              }
                           }
                           else
                           {
                              DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Incoming message was not read in full. Shutting down (%d, 0x%04x, 0x%08x).\n", Fd, Fds[i].revents, Msg.msg_flags));

                              /* The buffer was too small. This should  */
                              /* never happen and probably indicates a  */
                              /* broken socket driver. Free the buffer  */
                              /* space back to the head and shut down   */
                              /* the socket.                            */
                              BTPS_FreeMemory(RecvBuffer);

                              ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                           }
                        }
                        else
                        {
                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to allocate space for incoming data on server comms socket. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                           ret_val = BTPM_ERROR_CODE_UNABLE_TO_ALLOCATE_MEMORY;
                        }
                     }
                     else
                     {
                        DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to determine incoming data size on server comms socket. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                        ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_RECEIVE_DATA;
                     }
                  }
                  else
                  {
                     DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unknown error on server comms socket. Notifying upper layer and closing descriptor (%d, 0x%04x).\n", Fd, Fds[i].revents));

                     /* Some unknown error ocurred on the server socket.*/
                     /* Shut down the thread since we can't recover.    */
                     ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                  }
               }
            }
         }

         /* Clear revents flags on monitored sockets.                   */
         for(i=0;i<FdsLength;i++)
            Fds[i].revents = 0;
      }

      /* Disconnect from the server.                                    */
      close(DataSocket);
   }
   else
   {
      if(Arg)
         BTPS_FreeMemory(Arg);

      CallbackParameter = NULL;

      ret_val           = BTPM_ERROR_CODE_INVALID_PARAMETER;
   }

   /* Send an unregistration event for the closed client socket to the  */
   /* IPC callback.                                                     */
   EventData.Event_Data_Type                                       = etIPC_Client_Un_Registration;
   EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

   EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = IPC_SERVER_ADDRESS_ID;

   __BTPSTRY
   {
      if(EventCallbackFunction)
         (*EventCallbackFunction)(&EventData, CallbackParameter);
   }
   __BTPSEXCEPT(1)
   {
      /* Do Nothing.                                                    */
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return((void *)ret_val);
}

   /* The following function is responsible for initializing the IPC    */
   /* Handler for the current Platform Manager Entity (either client or */
   /* server).  The first parameter is a pointer to a null-terminated   */
   /* file path to the unix domain socket which the server will create  */
   /* and receive client connections on.  The second and third parameter*/
   /* specify the Event Callback function and parameter that is called  */
   /* when an IPC Event occurs (respectively).  This function will      */
   /* return zero if the IPC Handler was able to be intialized          */
   /* correctly, or a negative return error code if there was an error  */
   /* initializing the IPC Handler.                                     */
int IPC_Initialize(void *InitializationInfo, IPC_Event_Callback_t EventCallbackFunction, void *CallbackParameter)
{
   int                 ret_val;
   int                 ControlPipe[2];
   char               *SocketPath;
   unsigned int        SocketPathLength;
   pthread_attr_t      ThreadAttr;
   ThreadInitData_t   *TData;
   struct sockaddr_un  SocketAddress;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Check to see if we're initialized. If not, go ahead and initialize*/
   /* the IPC module.                                                   */
   if(!Initialized)
   {
      /* If a unix domain socket file path is not provided in           */
      /* InitializationInfo, use the compile-time default.              */
      SocketPath = (InitializationInfo ? (char *)InitializationInfo : IPC_SOCKET_PATH_DEFAULT);

      /* Check whether the InitializiationInfo paramter appears valid.  */
      if((strlen(SocketPath) < IPC_SOCKET_PATH_MAX))
      {
         /* Check whether the EventCallbackFunction appears valid.      */
         if(EventCallbackFunction)
         {
            /* Attempt to create a pipe for thread communication.       */
            if(!pipe(ControlPipe))
            {
               /* All communication is handled in a single thread, so   */
               /* all sockets/pipes must be non-blocking.               */
               /* * NOTE * ControlPipe[0] is the Read end of the Pipe   */
               /*          and ControlPipe[1] is the write end.         */
               fcntl(ControlPipe[0], F_SETFL, fcntl(ControlPipe[0], F_GETFL) | O_NONBLOCK);
               fcntl(ControlPipe[1], F_SETFL, fcntl(ControlPipe[1], F_GETFL) | O_NONBLOCK);

               /* Go ahead and store the Read/Write sockets for the     */
               /* Pipe.                                                 */
               ThreadControlSocketR = ControlPipe[0];
               ThreadControlSocketW = ControlPipe[1];

               /* Open the socket we'll use to talk to the server.      */
               ServerFd = socket(AF_UNIX, SOCK_SEQPACKET, 0);
               if(ServerFd >= 0)
               {
                  /* If the socket opened successfully, try to connect  */
                  /* to the server.                                     */
                  SocketAddress.sun_family = AF_UNIX;

                  if(SocketPath[0] == '\0')
                  {
                     /* Abstract socket.  The socket name is a NULL     */
                     /* character followed by an arbitrary string.      */
                     SocketAddress.sun_path[0] = '\0';
                     strncpy(&(SocketAddress.sun_path[1]), &(SocketPath[1]), (IPC_SOCKET_PATH_MAX - 1));

                     SocketPathLength = (1 + strlen(&(SocketPath[1])));
                  }
                  else
                  {
                     /* Normal file path.  Copy as a string.            */
                     strncpy(SocketAddress.sun_path, SocketPath, IPC_SOCKET_PATH_MAX);

                     SocketPathLength = strlen(SocketPath);
                  }

                  if(connect(ServerFd, (struct sockaddr *)&SocketAddress, (STRUCTURE_OFFSET(struct sockaddr_un, sun_path) + SocketPathLength)) == 0)
                  {
                     /* Create a thread initiailzation structure.       */
                     TData = (ThreadInitData_t *)BTPS_AllocateMemory(sizeof(ThreadInitData_t));
                     if(TData)
                     {

                        /* Populate the structure with the reading side */
                        /* of the control pipe, the data socket, and    */
                        /* the callback information provided by the     */
                        /* caller.                                      */
                        TData->CtrlSocketFd          = ThreadControlSocketR;
                        TData->DataSocketFd          = ServerFd;
                        TData->EventCallbackFunction = EventCallbackFunction;
                        TData->CallbackParameter     = CallbackParameter;

                        /* Start IPC traffic thread.                    */
                        if(!pthread_attr_init(&ThreadAttr))
                        {
                           if(pthread_create(&Thread, &ThreadAttr, IPCThread, TData) != 0)
                              ret_val = BTPM_ERROR_CODE_UNABLE_TO_CREATE_THREAD;
                           else
                              ret_val = 0;
                        }
                        else
                           ret_val = BTPM_ERROR_CODE_UNABLE_TO_CREATE_THREAD;

                        /* If there was an error, we need to free any   */
                        /* memory that was allocated.                   */
                        if(ret_val)
                           BTPS_FreeMemory(TData);
                     }
                     else
                        ret_val = BTPM_ERROR_CODE_UNABLE_TO_ALLOCATE_MEMORY;
                  }
                  else
                     ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
               }
               else
                  ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_OPEN_SOCKET;
            }
            else
               ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_OPEN_PIPE;
         }
         else
            ret_val = BTPM_ERROR_CODE_INVALID_CALLBACK_SPECIFIED;
      }
      else
         ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;

      /* Make sure the inititalization was successful.                  */
      if(!ret_val)
         Initialized = TRUE;
      else
      {
         /* If there was a problem, clean up any allocated resources.   */
         if(ThreadControlSocketR != (-1))
            close(ThreadControlSocketR);

         if(ThreadControlSocketW != (-1))
            close(ThreadControlSocketW);

         if(ServerFd != (-1))
            close(ServerFd);

         /* Flag that there are no open sockets.                        */
         ServerFd             = -1;
         ThreadControlSocketR = -1;
         ThreadControlSocketW = -1;
      }
   }
   else
      ret_val = BTPM_ERROR_CODE_ALREADY_INITIALIZED;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is responsible for instructing the IPC     */
   /* Handler Module to cleanup any resources that it is currently      */
   /* holding.                                                          */
void IPC_Cleanup(void)
{
   IPC_Control_Code_t ControlCode;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   if(Initialized)
   {
      /* Check if the thread control socket was opened.                 */
      if((ThreadControlSocketW != (-1)) && (Thread))
      {
         DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Shutting Down Thread\n"));

         /* If so, try to send a shutdown command to the thread.        */
         ControlCode = ccShutdown;
         if(write(ThreadControlSocketW, &ControlCode, sizeof(ControlCode)) == sizeof(ControlCode))
         {
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Waiting for Thread\n"));

            /* Wait for the thread to terminate.                        */
            pthread_join(Thread, NULL);

            /* Close the open Sockets.                                  */
            close(ThreadControlSocketR);
            close(ThreadControlSocketW);
         }
         else
         {
            /* If there was a problem sending the shutdown command, just*/
            /* close the control socket. If the thread is still running,*/
            /* this will appear as a HUP and trigger a shutdown, anyway.*/
            close(ThreadControlSocketW);

            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Unable to Shut Down Thread\n"));
         }
      }

      /* Mark the module as uninitialized.                              */
      Initialized          = FALSE;

      Thread               = 0;
      ThreadControlSocketR = -1;
      ThreadControlSocketW = -1;
      ServerFd             = -1;
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit\n"));
}

   /* The following function is responsible for sending the specified   */
   /* Message through the Bluetopia Platform Manager services.  This    */
   /* function accepts as input the Destination Routing ID that the     */
   /* message is destined for, followed by the Length of the data (in   */
   /* bytes), followed by a pointer to the actual data itself.  The     */
   /* Destination Address ID will be assigned by this module (either    */
   /* from a Registration message and/or the Server Destination Routing */
   /* ID.  Note that the ID of 0x00000000 is considered a broadcast     */
   /* Destination.  Also note that the data sent by this module is      */
   /* opaque and this module has no concept of matching messages        */
   /* (requests vs. responses).  This function returns zero if          */
   /* successful, or a negative return error code if there was an error */
   /* sending the message.                                              */
int IPC_SendMessage(unsigned int AddressID, unsigned int MessageLength, unsigned char *MessageData)
{
   int           ret_val = 0;
   struct iovec  Iov;
   struct msghdr Msg;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* We should only send data if this module has been initialized and  */
   /* the specified destination is the server.                          */
   if((Initialized) && (AddressID == IPC_SERVER_ADDRESS_ID))
   {
      /* Build a msghdr structure for transmission over a unix socket.  */
      BTPS_MemInitialize(&Msg, 0, sizeof(Msg));

      Msg.msg_iov    = &Iov;
      Msg.msg_iovlen = 1;

      Iov.iov_base   = MessageData;
      Iov.iov_len    = MessageLength;

      /* Check that the message appears valid.                          */
      if((MessageLength >= 0) && (MessageData != NULL))
      {
         /* The message looks acceptable, so send it to the server.     */
         ret_val = ForcedSocketWrite(ServerFd, &Msg, 0);
      }
      else
         ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;
   }
   else
      ret_val = BTPM_ERROR_CODE_IPC_MODULE_NOT_INITIALIZED;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is provided to allow a mechanism to free   */
   /* any previously allocated Received Message Data.  More             */
   /* specifically, this function allows the caller a means to free     */
   /* allocated message data (the MessageData member of the             */
   /* IPC_Message_Received_Data_t structure of an etIPC_Message_Received*/
   /* event).  This function IS ONLY to be called for the above         */
   /* mentioned message.                                                */
   /* * NOTE * This function *MUST* be called for the MessageData       */
   /*          member for EVERY etIPC_Message_Received event.           */
void IPC_FreeReceivedMessageData(unsigned char *MessageData)
{
   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Make sure the MessageData appears valid.                          */
   if(MessageData)
   {
      /* We didn't do anything special when allocating the data, so just*/
      /* free it blindly.                                               */
      BTPS_FreeMemory(MessageData);
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit\n"));
}
