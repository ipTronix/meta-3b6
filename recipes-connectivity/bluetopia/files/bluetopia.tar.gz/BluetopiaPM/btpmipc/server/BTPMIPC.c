/*****< btpmipc.c >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMIPC - Interprocess Communication Abstraction layer for Stonestreet    */
/*            One Bluetooth Protocol Stack Platform Manager.                  */
/*                                                                            */
/*  Author:  Greg Hensley                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   06/04/10  G. Hensley     Initial creation.                               */
/******************************************************************************/
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include "BTPSKRNL.h"            /* BTPS Kernel Prototypes/Constants.         */

#include "BTPMDBG.h"             /* BTPM Debug Module Prototypes/Constants.   */
#include "BTPMERR.h"             /* BTPM Error Prototypes/Constants.          */
#include "BTPMIPC.h"             /* BTPM IPC Module Prototypes/Constants.     */

#define IPC_SOCKET_PATH_MAX                  (sizeof(struct sockaddr_un) - ((unsigned int )&(((struct sockaddr_un *)0)->sun_path)))

   /* Note the Configured Default Socket Path (of default it to a       */
   /* default if not specified).                                        */
#ifdef BTPM_LINUX_IPC_DEVICE_PATH

   #define IPC_SOCKET_PATH_DEFAULT           BTPM_LINUX_IPC_DEVICE_PATH

#else

   #define IPC_SOCKET_PATH_DEFAULT           "/tmp/SS1BTPMS"

#endif

   /* The following parameters govern the Socket listening/accept       */
   /* mechanism.                                                        */
#define IPC_SOCKET_LISTEN_BACKLOG            2

#define MAXIMUM_NUMBER_CLIENTS_PER_THREAD    20

typedef enum
{
   ccShutdown,
   ccWrite
} IPC_Control_Code_t;

typedef struct _tagThreadInitData_t
{
   int                   CtrlSocketFd;
   int                   DataSocketFd;
   IPC_Event_Callback_t  EventCallbackFunction;
   void                 *CallbackParameter;
} ThreadInitData_t;

   /* Internal Variables to this Module (Remember that all variables    */
   /* declared static are initialized to 0 automatically by the compiler*/
   /* as part of standard C/C++).                                       */

   /* Variable which serves as a global flag about whether this module  */
   /* is initialized or not.                                            */
static Boolean_t Initialized;

   /* Variable which holds the Mutex that guards access to the various  */
   /* state variables in this module.                                   */
static Mutex_t IPCMutex;

   /* Array which holds polling structures for poll()'ing sockets. The  */
   /* first two elements are used for a thread control pipe and         */
   /* listening socket, respectively.                                   */
static struct pollfd Fds[2 + MAXIMUM_NUMBER_CLIENTS_PER_THREAD];
static unsigned int FdsLength = 0;

   /* Variables which hold the file descriptors for the control pipe    */
   /* used to send control messages to the traffic thread.              */
static int ThreadControlSocketW = -1;
static int ThreadControlSocketR = -1;

   /* Variable which holds the file descriptor for the listening socket */
   /* from which new client connections are accepted.                   */
static int ListenSocket = -1;

   /* Variable which holds a reference to the traffic thread.           */
static pthread_t Thread = 0;

   /* Internal Function Prototypes.                                     */
static void ShutdownListenSocket(int Fd);
static Boolean_t SocketClearToBind(char *SocketPath);
static int ForcedSocketWrite(int Fd, struct msghdr *Msg, int Flags);
static int AddFd(int Fd, short Events);
static int DelFd(int Index);
static void *IPCThreadMain(void *Arg);

   /* The following function is used to cleanly close a listening unix  */
   /* domain socket. The routine checks whether the socket has been     */
   /* bound to a file path and, if so, removes the file binding before  */
   /* closing the socket.                                               */
static void ShutdownListenSocket(int Fd)
{
   socklen_t          SocketAddressLength;
   struct sockaddr_un SocketAddress;

   SocketAddressLength = sizeof(SocketAddress);

   if(getsockname(Fd, (struct sockaddr *)(&SocketAddress), &SocketAddressLength) == 0)
   {
      /* getsockname() was successful, so fd is definately a valid      */
      /* socket, but only operate on socket types we expect (AF_UNIX).  */
      if(SocketAddress.sun_family == AF_UNIX)
      {
         /* If a name was returned, which doesn't begin with a NULL     */
         /* character, then the socket had been bound to a file name    */
         /* which needs to be cleaned up.                               */
         if((SocketAddressLength > STRUCTURE_OFFSET(struct sockaddr_un, sun_path)) && (SocketAddress.sun_path[0] != '\0'))
            unlink(SocketAddress.sun_path);

         /* Now that no one can connect to the socket (the visible      */
         /* binding is gone), we can safely close the socket.           */
         close(Fd);
      }
   }
}

   /* The following function is used to determine whether the given     */
   /* unix-domain socket file is available for binding. If the socket   */
   /* file is in use (there is a service listening on the socket), this */
   /* function returns FALSE. If the socket file exists but is not in   */
   /* use, the file is deleted and this function returns TRUE. If the   */
   /* socket file does not exist, this function returns TRUE.           */
static Boolean_t SocketClearToBind(char *SocketPath)
{
   int                Sock;
   Boolean_t          ret_val;
   struct stat        FileStat;
   unsigned int       SocketPathLength;
   struct sockaddr_un SocketAddress;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   ret_val = FALSE;

   /* Check that the socket path is semi-valid.                         */
   if(SocketPath)
   {
      /* Check if the file exists.                                      */
      if(stat(SocketPath, &FileStat) == 0)
      {
         /* Make sure the file is really a socket.                      */
         if(S_ISSOCK(FileStat.st_mode))
         {
            Sock = socket(AF_UNIX, SOCK_SEQPACKET, 0);
            if(Sock >= 0)
            {
               /* Try to connect to the socket file.                    */
               SocketAddress.sun_family = AF_UNIX;

               if(SocketPath[0] == '\0')
               {
                  /* Abstract socket.  The socket name is a NULL        */
                  /* character followed by an arbitrary string.         */
                  SocketAddress.sun_path[0] = '\0';
                  strncpy(&(SocketAddress.sun_path[1]), &(SocketPath[1]), (IPC_SOCKET_PATH_MAX - 1));

                  SocketPathLength = (1 + strlen(&(SocketPath[1])));
               }
               else
               {
                  /* Normal file path.  Copy as a string.               */
                  strncpy(SocketAddress.sun_path, SocketPath, IPC_SOCKET_PATH_MAX);

                  SocketPathLength = strlen(SocketPath);
               }

               if(connect(Sock, (struct sockaddr *)&SocketAddress, (STRUCTURE_OFFSET(struct sockaddr_un, sun_path) + SocketPathLength)) == 0)
               {
                  /* The connection succeeded, meaning the socket is    */
                  /* currently bound to another server. We cannot use   */
                  /* it.                                                */
               }
               else
               {
                  if(errno == ECONNREFUSED)
                  {
                     /* The connection attempt failed because no one is */
                     /* listening.  Delete the file, if the socket is   */
                     /* not in the abstract namespace.                  */
                     if((SocketPath[0] == '\0') || (unlink(SocketPath) == 0))
                        ret_val = TRUE;
                  }
               }

               close(Sock);
            }
         }
      }
      else
      {
         if(errno == ENOENT)
         {
            /* The file does not exist, so we should be able to use it. */
            ret_val = TRUE;
         }
      }
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is used to transmit a prepared msghdr      */
   /* structure over an open socket in a reliable way. This routine will*/
   /* ensure that the message is sent regardless of signal interruption.*/
   /* This function returns zero if successful, or a negative return    */
   /* error code if there was an error sending the message.             */
static int ForcedSocketWrite(int Fd, struct msghdr *Msg, int Flags)
{
   int           ret_val = 0;
   Boolean_t     Sent = FALSE;
   struct pollfd Fds;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* We will continue to try to send the message until either it is    */
   /* sent or we encounter an unrecoverable error.                      */
   while(!Sent)
   {
      /* First, just try to send the data.                              */
      if(sendmsg(Fd, Msg, Flags) > 0)
      {
         DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Message sent successfully\n"));
         Sent    = TRUE;
         ret_val = 0;
      }
      else
      {
         /* Writing failed. If the reason is fatal (not EAGAIN or       */
         /* EWOULDBLOCK), then fail out immediately.                    */
         if((errno != EAGAIN) && (errno != EWOULDBLOCK))
         {
            /* This failure is unrecoverable.                           */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FAILURE), ("Failed to send IPC message for fd %d (errno %d, %s)\n", Fd, errno, strerror(errno)));

            ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_SEND_DATA;
            Sent    = TRUE;

            //XXX Explicitly handle each possible error code.
         }
         else
         {
            /* We are advised to attempt the write again.               */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Failed to send message... retrying.\n"));

            /* Prepare a pollfd structure for the poll() routine.       */
            Fds.fd      = Fd;
            Fds.events  = POLLOUT;
            Fds.revents = 0;

            /* We will continue to try to send the message until either */
            /* it is sent or we encounter an unrecoverable error.       */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Waiting for fd %d to become available (0x%04x / 0x%04x)\n", Fds.fd, Fds.events, Fds.revents));

            errno = 0;

            /* poll() for the writable status of the file descriptor.   */
            if((ret_val = poll(&Fds, 1, 1000)) >= 0)
            {
               if(ret_val == 0)
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Timed out waiting for socket to become available... attempting to send, anyway.\n"));
               else
                  DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Socket reports status: events: 0x%04x  revents: 0x%04x\n", Fds.events, Fds.revents));
            }
            else
               DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to query socket status: errno: %d (%s)\n", errno, strerror(errno)));
         }
      }
   }

   return(ret_val);
}

   /* The following function is used to add a file descriptor to the    */
   /* list of active FDs. It locks the IPC mutex to ensure no           */
   /* interference with I/O operations on the sockets.                  */
static int AddFd(int Fd, short Events)
{
   int ret_val = 0;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   if(BTPS_WaitMutex(IPCMutex, BTPS_INFINITE_WAIT))
   {
      /* Add the fd to the list only if space is available.             */
      if(FdsLength < (MAXIMUM_NUMBER_CLIENTS_PER_THREAD + 2))
      {
         Fds[FdsLength].fd       = Fd;
         Fds[FdsLength].events   = Events;
         Fds[FdsLength].revents  = 0;

         FdsLength              += 1;
      }
      else
         ret_val = BTPM_ERROR_CODE_UNABLE_TO_ADD_ENTRY;

      BTPS_ReleaseMutex(IPCMutex);
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is used to remove a file descriptor to the */
   /* list of active FDs. It locks the IPC mutex to ensure no           */
   /* interference with I/O operations on the sockets.                  */
static int DelFd(int Index)
{
   int ret_val = 0;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   if(BTPS_WaitMutex(IPCMutex, BTPS_INFINITE_WAIT))
   {
      /* Check that the index is valid and that we have at least one fd */
      /* to remove.                                                     */
      if((Index < FdsLength) && (FdsLength > 1))
      {
         /* Order is not important in a pollfd list, so remove the      */
         /* element by copying the last element in the list over the    */
         /* removed one and decrementing the list length.               */
         Fds[Index] = Fds[FdsLength - 1];
         FdsLength -= 1;
      }

      BTPS_ReleaseMutex(IPCMutex);
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is the entry-point for the IPC traffic     */
   /* thread. This thread is responsible for accepting client connection*/
   /* requests and receiving client messages. Events such as new        */
   /* connections, dropped connections, and incoming messages are       */
   /* dispatched to the callback routine provided to IPC_Initialize().  */
   /* The thread maintains a read-only pipe endpoint through which      */
   /* commands can be issued to the thread. If this pipe or the         */
   /* listening socket ever close, the thread will shut down. The thread*/
   /* can also be shut down by sending an IPC_Control_Shutdown_Code over*/
   /* the control pipe. A shutdown event is accompanied by              */
   /* unregistration events for all connected clients. Restoring the    */
   /* after a shutdown requires calling IPC_Cleanup() followed by       */
   /* IPC_Initialize().                                                 */
static void *IPCThreadMain(void *Arg)
{
   int                   ret_val = 0;
   int                   ControlSocket;
   int                   ServerSocket;
   int                   i;
   int                   j;
   int                   Fd;
   int                   NewFd;
   int                   RecvLengthExp;
   int                   RecvLengthAct;
   void                 *CallbackParameter;
   void                 *RecvBuffer;
   struct iovec          Iov;
   struct msghdr         Msg;
   IPC_Event_Data_t      EventData;
   IPC_Control_Code_t    ControlCode;
   IPC_Event_Callback_t  EventCallbackFunction;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Make sure the thread argument blob appears valid.                 */
   if((Arg) && (((ThreadInitData_t *)Arg)->EventCallbackFunction))
   {
      /* Extract the data from the argument blob and free the associated*/
      /* memory.                                                        */
      ControlSocket         = ((ThreadInitData_t *)Arg)->CtrlSocketFd;
      ServerSocket          = ((ThreadInitData_t *)Arg)->DataSocketFd;
      EventCallbackFunction = ((ThreadInitData_t *)Arg)->EventCallbackFunction;
      CallbackParameter     = ((ThreadInitData_t *)Arg)->CallbackParameter;

      BTPS_FreeMemory(Arg);

      /* Set up the shared pollfd list for monitoring the control and   */
      /* listen descriptors. Protect this with the module mutex in case */
      /* anyone tries to send messages during this operation.           */
      if(BTPS_WaitMutex(IPCMutex, BTPS_INFINITE_WAIT))
      {
         Fds[0].fd = ControlSocket;
         Fds[1].fd = ServerSocket;
         FdsLength = 2;

         for(i=0;i < FdsLength;i++)
         {
            Fds[i].events = POLLIN;
            Fds[i].revents = 0;

            fcntl(Fds[i].fd, F_SETFL, fcntl(Fds[i].fd, F_GETFL) | O_NONBLOCK);
         }

         BTPS_ReleaseMutex(IPCMutex);

         /* Prepare the msghdr structure for receiving messages.        */
         BTPS_MemInitialize(&Msg, 0, sizeof(Msg));

         Msg.msg_iov    = &Iov;
         Msg.msg_iovlen = 1;

         /* We only service one file descriptor per call to poll().  To */
         /* ensure we don't play favorites to any greedy clients near   */
         /* the beginning of the list, we always start searching for    */
         /* ready sockets from the position after the one we last       */
         /* serviced.  Start from position zero.                        */
         i = 0;

         /* Continue operating until we encounter an error condition, or*/
         /* the thread is interrupted (causing poll() to return before  */
         /* any interesting events occur on the listed sockets.         */
         while((ret_val == 0) && (poll(Fds, FdsLength, -1) > 0))
         {
            /* Find the first file descriptor which has a pending event.*/
            for(j=0;j < FdsLength;j++)
            {
               i = (i + 1) % FdsLength;

               if(Fds[i].revents)
                  break;
            }

            /* Check to be sure we found a descriptor.  This should     */
            /* never fail since we should not reach this code unless    */
            /* poll() reported that at least one socket experienced an  */
            /* event.                                                   */
            if(j < FdsLength)
            {
               /* Grab the module mutex since we may be modifying the   */
               /* list of file descriptors if we're accepting or        */
               /* dropping connections.                                 */
               if(BTPS_WaitMutex(IPCMutex, BTPS_INFINITE_WAIT))
               {
                  Fd = Fds[i].fd;

                  /* Check for the special case of the interesting      */
                  /* socket being the control pipe.                     */
                  if(Fd == ControlSocket)
                  {
                     DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Handling event on the control socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

                     /* It's possible for the POLLIN event to occur     */
                     /* alongside an error, so check for errors first.  */
                     if((Fds[i].revents & POLLHUP) || (Fds[i].revents & POLLERR))
                     {
                        DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket closed from remote side (%d, 0x%04x).\n", Fd, Fds[i].revents));

                        /* The control socket was closed from the other */
                        /* end.  This is a critical socket, so there's  */
                        /* nothing to do but shutdown.                  */
                        ret_val = BTPM_ERROR_CODE_IPC_PIPE_ERROR;
                     }
                     else
                     {
                        /* No errors, so double-check that we did get a */
                        /* POLLIN event.  This should never fail since  */
                        /* we are indicating to poll() that we are only */
                        /* interested in POLLIN events.                 */
                        if(Fds[i].revents & POLLIN)
                        {
                           /* Try to read a control code from the       */
                           /* control pipe.                             */
                           if((RecvLengthAct = read(Fd, &ControlCode, sizeof(IPC_Control_Code_t))) > 0)
                           {
                              /* Make sure we received an entire code.  */
                              if(RecvLengthAct == sizeof(IPC_Control_Code_t))
                              {
                                 /* Currently, the only implemented code*/
                                 /* is IPC Control Shutdown, which stops*/
                                 /* the thread.                         */
                                 if(ControlCode == ccShutdown)
                                 {
                                    DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Received 'shutdown' command from control socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

                                    /* Shutdown IPC system.  Break out  */
                                    /* of polling loop where I/O will be*/
                                    /* disconnected cleanly.  Setting a */
                                    /* positive return code will break  */
                                    /* out of the polling loop while not*/
                                    /* indicating any error.            */
                                    ret_val = 1;
                                 }
                              }
                              else
                              {
                                 DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket incomplete read. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                                 /* There was a problem reading from the*/
                                 /* control pipe.  This is a fatal      */
                                 /* error.                              */
                                 ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_RECEIVE_DATA;
                              }
                           }
                        }
                        else
                        {
                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Control socket is in an error state. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                           /* poll() reported an error on the socket.   */
                           /* Since this is our control socket, there's */
                           /* nothing to do but shutdown.               */
                           ret_val = BTPM_ERROR_CODE_IPC_PIPE_ERROR;
                        }
                     }
                  }
                  else
                  {
                     /* Check if the event is on the listening socket.  */
                     if(Fd == ServerSocket)
                     {
                        DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Handling event on the listening server socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

                        /* It's possible for the POLLIN event to occur  */
                        /* alongside an error, so check for errors      */
                        /* first.                                       */
                        if((Fds[i].revents & POLLHUP) || (Fds[i].revents & POLLERR))
                        {
                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Server socket closed unexpectedly (%d, 0x%04x).\n", Fd, Fds[i].revents));

                           /* The listen socket was closed from the     */
                           /* other end.  This is a critical socket, so */
                           /* there's nothing to do but shutdown.       */
                           ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                        }
                        else
                        {
                           /* No errors, so double-check that we did get*/
                           /* a POLLIN event.  This should never fail   */
                           /* since we are indicating to poll() that we */
                           /* are only interested in POLLIN events.     */
                           if(Fds[i].revents & POLLIN)
                           {
                              /* A POLLIN event on a listening socket   */
                              /* indicates a connection attempt, so try */
                              /* to accept the connection.              */
                              if((NewFd = accept(Fd, NULL, NULL)) >= 0)
                              {
                                 DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("New client connection accepted: %d\n", NewFd));

                                 /* The accept succeeded, so configure  */
                                 /* the socket for non-blocking         */
                                 /* operation and add the socket to the */
                                 /* list of monitored descriptors.      */
                                 fcntl(NewFd, F_SETFL, fcntl(NewFd, F_GETFL) | O_NONBLOCK);
                                 DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("New client connection configured: %d, 0x%08x. Notifying upper layers.\n", NewFd, fcntl(NewFd, F_GETFL)));

                                 if(AddFd(NewFd, POLLIN) == 0)
                                 {
                                    /* Everything worked, so report the */
                                    /* connection to the IPC callback as*/
                                    /* an etIPC_Client_Registration     */
                                    /* event.                           */
                                    EventData.Event_Data_Type                                       = etIPC_Client_Registration;
                                    EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

                                    EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = NewFd;

                                    __BTPSTRY
                                    {
                                       (*EventCallbackFunction)(&EventData, CallbackParameter);
                                    }
                                    __BTPSEXCEPT(1)
                                    {
                                       /* Do Nothing.                   */
                                    }
                                 }
                                 else
                                 {
                                    /* We weren't able to add the       */
                                    /* descriptor to the monitoring     */
                                    /* list.  Possibly, the list is     */
                                    /* full.  Nothing we can do about   */
                                    /* this, so close the connection.   */
                                    DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("No remaining slots for client sockets. Closing descriptor %d\n", NewFd));
                                    close(NewFd);
                                 }
                              }
                              else
                              {
                                 /* Getting either EAGAIN or EWOULDBLOCK*/
                                 /* indicates that the pending          */
                                 /* connection request disappeared      */
                                 /* between poll() and accept().  This  */
                                 /* can happen under normal             */
                                 /* circumstances.  Any other error     */
                                 /* indicates a problem with the        */
                                 /* listening socket, so shutdown the   */
                                 /* thread.                             */
                                 if((errno != EAGAIN) && (errno != EWOULDBLOCK))
                                 {
                                    DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unexpected error while opening incoming client connection. Shutting down (%d, 0x%04x, %d (%s)).\n", Fd, Fds[i].revents, errno, strerror(errno)));
                                    ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                                 }
                                 else
                                    DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Incoming connection closed by remote client before being accepted (%d, 0x%04x).\n", Fd, Fds[i].revents));
                              }
                           }
                           else
                           {
                              DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unexpected event on server socket. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                              /* poll() reported an error on the socket.*/
                              /* Since this is our listening server     */
                              /* socket, there's nothing to do but to   */
                              /* shutdown.                              */
                              ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                           }
                        }
                     }
                     else
                     {
                        /* The event has occurred on a client socket.   */
                        DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Handling event on a client socket (%d, 0x%04x).\n", Fd, Fds[i].revents));

                        /* Check specifically for POLLNVAL, which       */
                        /* indicates an invalid socket (closed socket or*/
                        /* otherwise).                                  */
                        if(Fds[i].revents & POLLNVAL)
                        {
                           DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Client socket is invalid. Removing from polling list (%d, 0x%04x).\n", Fd, Fds[i].revents));

                           /* The client's socket wasn't properly       */
                           /* opened.  Remove the old fd from the       */
                           /* polling list.                             */
                           DelFd(i);
                        }
                        else
                        {
                           /* It's possible for the POLLIN event to     */
                           /* occur alongside an error, so check for    */
                           /* errors first.                             */
                           if((Fds[i].revents & POLLHUP) || (Fds[i].revents & POLLERR))
                           {
                              DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Client disconnected or error on socket. Notifying upper layers and closing descriptor %d\n", Fd));

                              /* The client shutdown the remote end of  */
                              /* the socket connection.  Report this as */
                              /* an unregistration and close the socket.*/
                              EventData.Event_Data_Type                                       = etIPC_Client_Un_Registration;
                              EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

                              EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = Fd;

                              __BTPSTRY
                              {
                                 (*EventCallbackFunction)(&EventData, CallbackParameter);
                              }
                              __BTPSEXCEPT(1)
                              {
                                 /* Do Nothing.                         */
                              }

                              close(Fd);

                              /* Remove the old fd from the polling     */
                              /* list.                                  */
                              DelFd(i);
                           }
                           else
                           {
                              /* No errors, so double-check that we did */
                              /* get a POLLIN event.  This should never */
                              /* fail since we are indicating to poll() */
                              /* that we are only interested in POLLIN  */
                              /* events.                                */
                              if(Fds[i].revents & POLLIN)
                              {
                                 /* There is incoming data from a       */
                                 /* client.  First, determine how much  */
                                 /* data is pending.  Using SOCK_DGRAM  */
                                 /* sockets, the FIONREAD ioctl will    */
                                 /* always return the size of the next  */
                                 /* pending message, not the total data */
                                 /* in the socket buffer.               */
                                 RecvLengthExp = 0;
                                 if(ioctl(Fd, FIONREAD, &RecvLengthExp) == 0)
                                 {
                                    /* Allocate enough space off the    */
                                    /* heap to contain the message.     */
                                    if((RecvBuffer = BTPS_AllocateMemory(RecvLengthExp)) != NULL)
                                    {
                                       /* Set up the msghdr structure   */
                                       /* with the new buffer.          */
                                       Iov.iov_base = RecvBuffer;
                                       Iov.iov_len  = RecvLengthExp;

                                       /* Try to receive the message.   */
                                       RecvLengthAct = recvmsg(Fd, &Msg, 0);

                                       DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Received client message: %d bytes (%d, 0x%04x, 0x%08x).\n", RecvLengthAct, Fd, Fds[i].revents, Msg.msg_flags));

                                       /* Double-check that the message */
                                       /* was truncated due to a        */
                                       /* too-small buffer.  This should*/
                                       /* never happen unless the       */
                                       /* FIONREAD ioctl is broken.     */
                                       if((Msg.msg_flags & MSG_TRUNC) == 0)
                                       {
                                          DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Sending client message to upper layer (%d, 0x%04x, 0x%08x).\n", Fd, Fds[i].revents, Msg.msg_flags));

                                          /* The message is good, so    */
                                          /* dispatch the event to the  */
                                          /* IPC callback.  The callback*/
                                          /* will own the buffer now, so*/
                                          /* we don't need to worry     */
                                          /* releasing the memory.      */
                                          EventData.Event_Data_Type                                    = etIPC_Message_Received;
                                          EventData.Event_Data_Size                                    = IPC_EVENT_DATA_SIZE;

                                          EventData.Event_Data.IPC_Message_Received_Data.ClientAddress = Fd;
                                          EventData.Event_Data.IPC_Message_Received_Data.MessageLength = RecvLengthAct;
                                          EventData.Event_Data.IPC_Message_Received_Data.MessageData   = RecvBuffer;

                                          __BTPSTRY
                                          {
                                             (*EventCallbackFunction)(&EventData, CallbackParameter);
                                          }
                                          __BTPSEXCEPT(1)
                                          {
                                             /* Do Nothing.             */
                                          }
                                       }
                                       else
                                       {
                                          DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Incoming message was not read in full. Shutting down (%d, 0x%04x, 0x%08x).\n", Fd, Fds[i].revents, Msg.msg_flags));

                                          /* The buffer was too small.  */
                                          /* This should never happen   */
                                          /* and probably indicates a   */
                                          /* broken socket driver.  Free*/
                                          /* the buffer space back to   */
                                          /* the head and shut down the */
                                          /* socket.                    */
                                          BTPS_FreeMemory(RecvBuffer);

                                          ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_RECEIVE_DATA;
                                       }
                                    }
                                    else
                                    {
                                       DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to allocate space for incoming data on client socket. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                                       ret_val = BTPM_ERROR_CODE_UNABLE_TO_ALLOCATE_MEMORY;
                                    }
                                 }
                                 else
                                 {
                                    DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unable to determine incoming data size on client socket. Shutting down (%d, 0x%04x).\n", Fd, Fds[i].revents));

                                    ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_RECEIVE_DATA;
                                 }
                              }
                              else
                              {
                                 DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_CRITICAL), ("Unknown error on client socket. Notifying upper layer and closing descriptor (%d, 0x%04x).\n", Fd, Fds[i].revents));

                                 /* An unkown problem occurred on the   */
                                 /* client socket connection.  Report   */
                                 /* this as an unregistration and close */
                                 /* the socket.                         */
                                 EventData.Event_Data_Type                                       = etIPC_Client_Un_Registration;
                                 EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

                                 EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = Fd;

                                 __BTPSTRY
                                 {
                                    (*EventCallbackFunction)(&EventData, CallbackParameter);
                                 }
                                 __BTPSEXCEPT(1)
                                 {
                                    /* Do Nothing.                      */
                                 }

                                 close(Fd);

                                 /* Remove the old fd from the polling  */
                                 /* list.                               */
                                 DelFd(i);
                              }
                           }
                        }
                     }
                  }

                  /* We are past any operation that could modify the    */
                  /* descriptor list, so release the mutex.             */
                  BTPS_ReleaseMutex(IPCMutex);
               }
            }

            /* Clear revents flags on monitored sockets.                */
            for(j=0;j < FdsLength;j++)
            {
               DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Clearing pending events for socket %d (0x%04x)\n", Fds[j].fd, Fds[j].revents));
               Fds[j].revents = 0;
            }
         }

         /* Stopping thread, so close utility sockets and disconnect all*/
         /* remaining clients.                                          */
         ShutdownListenSocket(ServerSocket);

         for(i=2;i < FdsLength;i++)
         {
            /* Send an unregistration event for the closed client socket*/
            /* to the IPC callback.                                     */
            EventData.Event_Data_Type                                       = etIPC_Client_Un_Registration;
            EventData.Event_Data_Size                                       = IPC_EVENT_DATA_SIZE;

            EventData.Event_Data.IPC_Client_Registration_Data.ClientAddress = Fds[i].fd;

            __BTPSTRY
            {
               (*EventCallbackFunction)(&EventData, CallbackParameter);
            }
            __BTPSEXCEPT(1)
            {
               /* Do Nothing.                                           */
            }

            /* And close the client socket.                             */
            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Closing client socket due to thread shutdown. Closing descriptor %d\n", Fds[i].fd));
            close(Fds[i].fd);
         }
      }
   }
   else
   {
      if(Arg)
         BTPS_FreeMemory(Arg);

      ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return((void *)ret_val);
}

   /* The following function is responsible for initializing the IPC    */
   /* Handler for the current Platform Manager Entity (either client or */
   /* server).  The first parameter is a pointer to a null-terminated   */
   /* file path to the unix domain socket which the server will create  */
   /* and receive client connections on.  The second and third parameter*/
   /* specify the Event Callback function and parameter that is called  */
   /* when an IPC Event occurs (respectively).  This function will      */
   /* return zero if the IPC Handler was able to be intialized          */
   /* correctly, or a negative return error code if there was an error  */
   /* initializing the IPC Handler.                                     */
int IPC_Initialize(void *InitializationInfo, IPC_Event_Callback_t EventCallbackFunction, void *CallbackParameter)
{
   int                 ret_val         = 0;
   int                 ControlPipe[2];
   int                 OriginalUMask;
   char               *SocketPath;
   unsigned int        SocketPathLength;
   pthread_attr_t      ThreadAttr;
   ThreadInitData_t   *TData;
   struct sockaddr_un  SocketAddress;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Check to see if we're initialized. If not, go ahead and initialize*/
   /* the IPC module.                                                   */
   if(!Initialized)
   {
      /* Create the module-wide mutex.                                  */
      if((IPCMutex = BTPS_CreateMutex(FALSE)) != NULL)
      {
         /* If a unix domain socket file path is not provided in        */
         /* InitializationInfo, use the compile-time default.           */
         SocketPath = (InitializationInfo ? (char *)InitializationInfo : IPC_SOCKET_PATH_DEFAULT);

         /* Check whether the Socket Path valid.                        */
         if((strlen(SocketPath) < IPC_SOCKET_PATH_MAX))
         {
            /* Check whether the EventCallbackFunction appears valid.   */
            if(EventCallbackFunction)
            {
               if(SocketClearToBind(SocketPath))
               {
                  /* Attempt to create a pipe for thread communication. */
                  /* * NOTE * ControlPipe[0] is the Read end of the Pipe*/
                  /*          and ControlPipe[1] is the write end.      */
                  if(!pipe(ControlPipe))
                  {
                     /* All communication is handled in a single thread,*/
                     /* so all sockets/pipes must be non-blocking.      */
                     fcntl(ControlPipe[0], F_SETFL, fcntl(ControlPipe[0], F_GETFL) | O_NONBLOCK);
                     fcntl(ControlPipe[1], F_SETFL, fcntl(ControlPipe[1], F_GETFL) | O_NONBLOCK);

                     /* Go ahead and store the Read/Write sockets for   */
                     /* the Pipe.                                       */
                     ThreadControlSocketR = ControlPipe[0];
                     ThreadControlSocketW = ControlPipe[1];

                     /* Set our umask before creating the socket to     */
                     /* only disable execute permissions. This will     */
                     /* ensure that we don't block clients from         */
                     /* connecting due to restrictive system defaults.  */
                     OriginalUMask = umask(S_IXUSR | S_IXGRP | S_IXOTH);

                     /* Open the socket we'll listen to for incoming    */
                     /* client connections.                             */
                     ListenSocket = socket(AF_UNIX, SOCK_SEQPACKET, 0);
                     if(ListenSocket >= 0)
                     {
                        /* If the socket opened successfully, bind it to*/
                        /* a file path.                                 */
                        SocketAddress.sun_family = AF_UNIX;

                        if(SocketPath[0] == '\0')
                        {
                           /* Abstract socket.  The socket name is a    */
                           /* NULL character followed by an arbitrary   */
                           /* string.                                   */
                           SocketAddress.sun_path[0] = '\0';
                           strncpy(&(SocketAddress.sun_path[1]), &(SocketPath[1]), (IPC_SOCKET_PATH_MAX - 1));

                           SocketPathLength = (1 + strlen(&(SocketPath[1])));
                        }
                        else
                        {
                           /* Normal file path.  Copy as a string.      */
                           strncpy(SocketAddress.sun_path, SocketPath, IPC_SOCKET_PATH_MAX);

                           SocketPathLength = strlen(SocketPath);
                        }

                        if(bind(ListenSocket, (struct sockaddr *)&SocketAddress, (STRUCTURE_OFFSET(struct sockaddr_un, sun_path) + SocketPathLength)) == 0)
                        {
                           /* Put the socket in listening mode.         */
                           if(listen(ListenSocket, IPC_SOCKET_LISTEN_BACKLOG) == 0)
                           {
                              /* All the socket communication is set up,*/
                              /* so allocate space for a thread         */
                              /* initialization structure.              */
                              TData = (ThreadInitData_t *)BTPS_AllocateMemory(sizeof(ThreadInitData_t));
                              if(TData)
                              {
                                 /* Populate the structure with the     */
                                 /* reading side of the control pipe,   */
                                 /* the data socket, and the callback   */
                                 /* information provided by the caller. */
                                 TData->CtrlSocketFd          = ThreadControlSocketR;
                                 TData->DataSocketFd          = ListenSocket;
                                 TData->EventCallbackFunction = EventCallbackFunction;
                                 TData->CallbackParameter     = CallbackParameter;

                                 /* Start IPC traffic thread.           */
                                 if(!pthread_attr_init(&ThreadAttr))
                                 {
                                    if(pthread_create(&Thread, &ThreadAttr, IPCThreadMain, TData) != 0)
                                       ret_val = BTPM_ERROR_CODE_UNABLE_TO_CREATE_THREAD;
                                    else
                                       ret_val = 0;
                                 }
                                 else
                                    ret_val = BTPM_ERROR_CODE_UNABLE_TO_CREATE_THREAD;

                                 /* If there was an error, we need to   */
                                 /* free any memory that was allocated. */
                                 if(ret_val)
                                    BTPS_FreeMemory(TData);
                              }
                              else
                                 ret_val = BTPM_ERROR_CODE_UNABLE_TO_ALLOCATE_MEMORY;
                            }
                            else
                               ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;
                        }
                        else
                           ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_OPEN_SOCKET;
                     }
                     else
                        ret_val = BTPM_ERROR_CODE_IPC_SOCKET_ERROR;

                     /* Restore the umask to the original value.        */
                     umask(OriginalUMask);
                  }
                  else
                     ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_OPEN_PIPE;
               }
               else
                  ret_val = BTPM_ERROR_CODE_IPC_SERVER_ALREADY_RUNNING;
            }
            else
               ret_val = BTPM_ERROR_CODE_INVALID_CALLBACK_SPECIFIED;
         }
         else
            ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;
      }
      else
         ret_val = BTPM_ERROR_CODE_UNABLE_TO_CREATE_MUTEX;

      /* Make sure the initialization was successful.                   */
      if(ret_val == 0)
         Initialized = TRUE;
      else
      {
         /* If there was a problem, clean up any allocated resources.   */
         if(IPCMutex)
            BTPS_CloseMutex(IPCMutex);

         if(ThreadControlSocketR != (-1))
            close(ThreadControlSocketR);

         if(ThreadControlSocketW != (-1))
            close(ThreadControlSocketW);

         ShutdownListenSocket(ListenSocket);

         ListenSocket = -1;

         IPCMutex     = NULL;
      }
   }
   else
      ret_val = BTPM_ERROR_CODE_ALREADY_INITIALIZED;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is responsible for instructing the IPC     */
   /* Handler Module to cleanup any resources that it is currently      */
   /* holding.                                                          */
void IPC_Cleanup(void)
{
   IPC_Control_Code_t ControlCode;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   if(Initialized)
   {
      /* Check if the thread control socket was opened.                 */
      if((ThreadControlSocketW != (-1)) && (Thread))
      {
         /* If so, try to send a shutdown command to the thread.        */
         ControlCode = ccShutdown;
         if(write(ThreadControlSocketW, &ControlCode, sizeof(ControlCode)) == sizeof(ControlCode))
         {
            /* Wait for the thread to terminate.                        */
            pthread_join(Thread, NULL);

            /* Close the open Sockets.                                  */
            close(ThreadControlSocketR);
            close(ThreadControlSocketW);
         }
         else
         {
            /* If there was a problem sending the shutdown command, just*/
            /* close the control socket. If the thread is still running,*/
            /* this will appear as a HUP and trigger a shutdown, anyway.*/
            close(ThreadControlSocketW);

            DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_VERBOSE), ("Unable to Shut Down Thread\n"));
         }
      }

      /* Free any additional resources allocated during initialization. */
      BTPS_CloseMutex(IPCMutex);

      /* Mark the module as uninitialized.                              */
      Initialized          = FALSE;

      Thread               = 0;
      ThreadControlSocketR = -1;
      ThreadControlSocketW = -1;
      ListenSocket         = -1;
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit\n"));
}

   /* The following function is responsible for sending the specified   */
   /* Message through the Bluetopia Platform Manager services.  This    */
   /* function accepts as input the Destination Routing ID that the     */
   /* message is destined for, followed by the Length of the data (in   */
   /* bytes), followed by a pointer to the actual data itself.  The     */
   /* Destination Address ID will be assigned by this module (either    */
   /* from a Registration message and/or the Server Destination Routing */
   /* ID.  Note that the ID of 0x00000000 is considered a broadcast     */
   /* Destination.  Also note that the data sent by this module is      */
   /* opaque and this module has no concept of matching messages        */
   /* (requests vs. responses).  This function returns zero if          */
   /* successful, or a negative return error code if there was an error */
   /* sending the message.                                              */
int IPC_SendMessage(unsigned int AddressID, unsigned int MessageLength, unsigned char *MessageData)
{
   int           ret_val = 0;
   int           WriteResult = 0;
   int           i;
   struct msghdr Msg;
   struct iovec  Iov;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter: 0x%08X, 0x%08X\n", AddressID, MessageLength));

   /* We should only send data if this module has been initialized.     */
   if(Initialized)
   {
      /* Build a msghdr structure for transmission over a unix socket.  */
      BTPS_MemInitialize(&Msg, 0, sizeof(Msg));

      Msg.msg_iov    = &Iov;
      Msg.msg_iovlen = 1;

      Iov.iov_base   = MessageData;
      Iov.iov_len    = MessageLength;

      /* Check that the message appears valid.                          */
      if((MessageLength >= 0) && (MessageData != NULL))
      {
         /* Grab the IPC mutex to ensure the file descriptor list can't */
         /* change while we iterate over it.                            */
         BTPS_WaitMutex(IPCMutex, BTPS_INFINITE_WAIT);

         /* Check for the special case of a broadcast packet.           */
         if(AddressID == IPC_BROADCAST_ADDRESS_ID)
         {
            /* If the message is address to the broadcast destination,  */
            /* it should be sent to all connected clients.              */
            /*   NOTE: We start at the third file descriptor because    */
            /*         the first two are reserved for control use.      */
            for(i=2;i < FdsLength;i++)
            {
               WriteResult = ForcedSocketWrite(Fds[i].fd, &Msg, 0);

               /* If we haven't had any problems yet, keep the result of*/
               /* the write operation. If there is a problem writing to */
               /* any client, this will manifest as an overall error.   */
               if(ret_val == 0)
                  ret_val = WriteResult;
            }

            if(ret_val != 0)
               ret_val = BTPM_ERROR_CODE_IPC_UNABLE_TO_SEND_DATA;
         }
         else
         {
            /* The destination is not the broadcast address. Make sure  */
            /* destination is a real, known client.                     */
            for(i=0;i < FdsLength;i++)
            {
               if(Fds[i].fd == AddressID)
                  break;
            }

            if(i < FdsLength)
            {
               /* The destination is a known client, so send the        */
               /* message.                                              */
               ret_val = ForcedSocketWrite(Fds[i].fd, &Msg, 0);
            }
            else
               ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;
         }

         BTPS_ReleaseMutex(IPCMutex);
      }
      else
         ret_val = BTPM_ERROR_CODE_INVALID_PARAMETER;
   }
   else
      ret_val = BTPM_ERROR_CODE_IPC_MODULE_NOT_INITIALIZED;

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit: %d\n", ret_val));

   return(ret_val);
}

   /* The following function is provided to allow a mechanism to free   */
   /* any previously allocated Received Message Data.  More             */
   /* specifically, this function allows the caller a means to free     */
   /* allocated message data (the MessageData member of the             */
   /* IPC_Message_Received_Data_t structure of an etIPC_Message_Received*/
   /* event).  This function IS ONLY to be called for the above         */
   /* mentioned message.                                                */
   /* * NOTE * This function *MUST* be called for the MessageData       */
   /*          member for EVERY etIPC_Message_Received event.           */
void IPC_FreeReceivedMessageData(unsigned char *MessageData)
{
   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Enter\n"));

   /* Make sure the MessageData appears valid.                          */
   if(MessageData)
   {
      /* We didn't do anything special when allocating the data, so just*/
      /* free it blindly.                                               */
      BTPS_FreeMemory(MessageData);
   }

   DebugPrint((BTPM_DEBUG_ZONE_IPC | BTPM_DEBUG_LEVEL_FUNCTION), ("Exit\n"));
}
