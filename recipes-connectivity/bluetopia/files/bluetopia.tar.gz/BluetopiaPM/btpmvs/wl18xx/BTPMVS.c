/*****< btvspm.c >*************************************************************/
/*      Copyright 2011 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTVSPM - Vendor specific PM implementation of a set of vendor specific    */
/*           functions supported for WL18xx Device.                           */
/*                                                                            */
/*  Author:  Kobi L                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/08/15  Kobi L         Initial creation.                               */
/*   12/16/15  D. Keren       Adding Vendor DDIP command.                     */
/******************************************************************************/
#include "SS1BTPS.h"          /* Bluetopia API Prototypes/Constants.          */
#include "BTPSKRNL.h"         /* BTPS Kernel Prototypes/Constants.            */
#include "BTPMVSAPI.h"          /* Vendor Specific Prototypes/Constants.      */
#include "DEVMAPI.h"

   /* The following MACRO is a utility MACRO that exists to aid in      */
   /* converting an unsigned long in milliseconds to 2 Baseband slots.  */
#define CONVERT_TO_TWO_BASEBAND_SLOTS(_x)                         ((unsigned long)((((4000L * (_x)) / 500L) + 5L)/10L))

   /* Vendor Specific Command Opcodes.                                  */
#define VS_DRPB_SET_POWER_VECTOR_COMMAND_OPCODE                  ((Word_t)(0xFD82))
#define VS_HCILL_PARAMETERS_COMMAND_OPCODE                       ((Word_t)(0xFD2B))
#define VS_SLEEP_MODE_CONFIGURATIONS_COMMAND_OPCODE              ((Word_t)(0xFD0C))
#define VS_WRITE_BD_ADDR_COMMAND_OPCODE                          ((Word_t)(0xFC06))
#define VS_WRITE_CODEC_CONFIG_COMMAND_OPCODE                     ((Word_t)(0xFD06))
#define VS_A3DP_OPEN_STREAM_COMMAND_OPCODE                       ((Word_t)(0xFD8C))
#define VS_A3DP_CLOSE_STREAM_COMMAND_OPCODE                      ((Word_t)(0xFD8D))
#define VS_A3DP_CODEC_CONFIGURATION_COMMAND_OPCODE               ((Word_t)(0xFD8E))
#define VS_A3DP_START_STREAM_COMMAND_OPCODE                      ((Word_t)(0xFD8F))
#define VS_A3DP_STOP_STREAM_COMMAND_OPCODE                       ((Word_t)(0xFD90))
#define VS_AVPR_ENABLE_COMMAND_OPCODE                            ((Word_t)(0xFD92))
#define VS_DRPB_ENABLE_RF_CALIBRATION_ENHANCED_COMMAND_OPCODE    ((Word_t)(0xFDFB))
#define VS_DRPB_TESTER_CON_TX_COMMAND_OPCODE                     ((Word_t)(0xFDCA))
#define VS_PACKET_TX_RX_COMMAND_OPCODE                           ((Word_t)(0xFDCC))
#define VS_DRPB_TESTER_CON_RX_COMMAND_OPCODE                     ((Word_t)(0xFDCB))
#define VS_DRPB_RESET_COMMAND_OPCODE                             ((Word_t)(0xFD88))
#define VS_DRPB_BER_METER_START_COMMAND_OPCODE                   ((Word_t)(0xFD8B))
#define VS_DRP_READ_BER_METER_RESULT_COMMAND_OPCODE              ((Word_t)(0xFD13))
#define VS_READ_PATCH_VERSION_COMMAND_OPCODE                     ((Word_t)(0xFF22))
#define VS_A3DP_SINK_OPEN_STREAM_COMMAND_OPCODE                  ((Word_t)(0xFD9A))
#define VS_A3DP_SINK_CLOSE_STREAM_COMMAND_OPCODE                 ((Word_t)(0xFD9B))
#define VS_A3DP_SINK_CODEC_CONFIGURATION_COMMAND_OPCODE          ((Word_t)(0xFD9C))
#define VS_A3DP_SINK_START_STREAM_COMMAND_OPCODE                 ((Word_t)(0xFD9D))
#define VS_A3DP_SINK_STOP_STREAM_COMMAND_OPCODE                  ((Word_t)(0xFD9E))
#define VS_CONFIGURE_DDIP_COMMAND_OPCODE                  		 ((Word_t)(0xFD55))

#define VS_COMMAND_OGF(_CommandOpcode)                           ((Byte_t)((_CommandOpcode) >> 10))
#define VS_COMMAND_OCF(_CommandOpcode)                           ((Word_t)((_CommandOpcode) & (0x3FF)))

   /* DDIP vendor specific command length */
#define VS_DDIP_COMMAND_LENGTH  		(9)

   /* DDIP vendor specific command default parameters: */

   /* Poll Period, 1 byte, 0x02 */
#define POLL_PERIODE			 		(0x02)
   /* The number of frames for ACK reception after the slave transmitted packet. */
   /* Slave Wait After TX Boundary, 1 byte, outgoing = 0x07 */
#define SLAVE_WAIT_AFTER_ACK_TX_BOUNDARY (0x07)
   /* The max number of frames that the Slave search for the Master during DDIP */
   /* Master Search Boundary, 1 byte, outgoing = 0x02 */
#define MASTER_SEARCH_BOUNDARY 			(0x02)
   /* Master Burst After RX enable */
#define MASTER_BURST_AFTER_RX_ENABLE    (0x01)
   /* Master Burst After RX limit */
#define MASTER_BURST_AFTER_RX_LIMIT     (0x01)


   /* Internal Function Prototypes.                                     */
static int MapSendRawResults(int Result, Byte_t Status, Byte_t LengthResult, Byte_t *ReturnData);
static void SwapEndianessBD_ADDR(BD_ADDR_t *Input, BD_ADDR_t *Output);

   /* The following function is a utility function that is used to map  */
   /* the return results that we returned from Send Raw (ONLY for       */
   /* commands that return command complete event) to a negative error  */
   /* code.                                                             */
   /* * NOTE * As an internal function no check is done on the return   */
   /*          parameters.                                              */
static int MapSendRawResults(int Result, Byte_t Status, Byte_t LengthResult, Byte_t *ReturnData)
{
   int ret_val;

   /* Check to see if the API returned an error.                        */
   if((!Result) && (!Status) && (LengthResult >= 1))
   {
      /* Check to see if the chip returned an error.                    */
      if(ReturnData[0] == HCI_ERROR_CODE_NO_ERROR)
         ret_val = 0;
      else
         ret_val = BTPS_ERROR_CODE_HCI_STATUS_BASE - ReturnData[0];
   }
   else
      ret_val = BTPS_ERROR_DEVICE_HCI_ERROR;

   return(ret_val);
}

   /* The following function swaps the endianness of a BD_ADDR.  The    */
   /* first parameter specifies the BD_ADDR that will be swapped, the   */
   /* second parameter specifies where the resulting BD_ADDR will be    */
   /* stored.                                                           */
   /* * NOTE * This is an internal function and assumes that the caller */
   /*          has already checked the input parameters.                */
   /* * NOTE * This function can properly handle the case that the input*/
   /*          and output pointers specify the same address.            */
static void SwapEndianessBD_ADDR(BD_ADDR_t *Input, BD_ADDR_t *Output)
{
   BD_ADDR_t TempBD_ADDR;

   if(Input != Output)
   {
      Output->BD_ADDR0 = Input->BD_ADDR5;
      Output->BD_ADDR1 = Input->BD_ADDR4;
      Output->BD_ADDR2 = Input->BD_ADDR3;
      Output->BD_ADDR3 = Input->BD_ADDR2;
      Output->BD_ADDR4 = Input->BD_ADDR1;
      Output->BD_ADDR5 = Input->BD_ADDR0;
   }
   else
   {
      TempBD_ADDR.BD_ADDR0 = Input->BD_ADDR5;
      TempBD_ADDR.BD_ADDR1 = Input->BD_ADDR4;
      TempBD_ADDR.BD_ADDR2 = Input->BD_ADDR3;
      TempBD_ADDR.BD_ADDR3 = Input->BD_ADDR2;
      TempBD_ADDR.BD_ADDR4 = Input->BD_ADDR1;
      TempBD_ADDR.BD_ADDR5 = Input->BD_ADDR0;

      BTPS_MemCopy(Output, &TempBD_ADDR, BD_ADDR_SIZE);
   }
}


   /* The following function prototype represents the vendor specific   */
   /* function which is used to change the HCILL parameters that are    */
   /* used for the HCILL Low Power protocol for the Local Bluetooth     */
   /* Device specified by the Bluetooth Protocol Stack that is specified*/
   /* by the Bluetooth Protocol Stack ID.  The second is the            */
   /* InactivityTimeout on the Uart in ms.  If no traffic on Uart lines */
   /* after this time the Controller sends a Sleep Indication.  The     */
   /* third is the RetransmitTimeout (ms) for the Sleep Indication if no*/
   /* Sleep Acknowledgement (from the Host) is received.  The fourth is */
   /* the Controller RTS pulse width during Controller wakeup (specified*/
   /* in us).  This function returns zero if successful or a negative   */
   /* return error code if there was an error.                          */
int BTPSAPI PM_VS_HCILL_Parameters(Word_t InactivityTimeout, Word_t RetransmitTimeout, Byte_t RTSPulseWidth)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[8];
	Byte_t CommandBuffer[5];
	Byte_t OGF;
	Word_t OCF;

	/* Before continuing, make sure the input parameters appear to be    */
	/* semi-valid.                                                       */
	/* Format the command to send.                                    */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&(CommandBuffer[0]), CONVERT_TO_TWO_BASEBAND_SLOTS(InactivityTimeout));
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&(CommandBuffer[NON_ALIGNED_WORD_SIZE]), CONVERT_TO_TWO_BASEBAND_SLOTS(RetransmitTimeout));
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[NON_ALIGNED_WORD_SIZE*2]), RTSPulseWidth);

	/* Send the command to update the HCILL Parameters.               */
	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_HCILL_PARAMETERS_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_HCILL_PARAMETERS_COMMAND_OPCODE);

	ret_val = DEVM_SendRawHCICommand(OGF, OCF, (Byte_t)sizeof(CommandBuffer), (Byte_t *)(CommandBuffer), &Status, &Length, ReturnBuffer, TRUE);

	/* Map the return results into an error code.                     */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* Sleep_Mode_Configurations command.  Refer to the Bluetooth (WL18xx*/
   /* and WL18xxQ) Vendor-Specific HCI Commands User's Guide for a      */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_Sleep_Mode_Configurations(Byte_t DeepSleepEnable)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[8];
	Byte_t CommandBuffer[9];
	Byte_t OGF;
	Word_t OCF;

	/* Format the command to send.                                    */
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[0]), 0x00);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[1]), DeepSleepEnable);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[2]), 0x00);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[3]), 0xFF);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[4]), 0xFF);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[5]), 0xFF);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[6]), 0xFF);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&(CommandBuffer[7]), 0x0000);

	/* Send the command to set the sleep mode configuration.          */
	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_SLEEP_MODE_CONFIGURATIONS_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_SLEEP_MODE_CONFIGURATIONS_COMMAND_OPCODE);

	ret_val = DEVM_SendRawHCICommand(OGF, OCF, sizeof(CommandBuffer), (Byte_t *)(CommandBuffer), &Status, &Length, ReturnBuffer, TRUE);

	/* Map the return results into an error code.                     */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function prototype represents the vendor specific   */
   /* function which is used to change the public Bluetooth Address     */
   /* (also known as a MAC address) for the local Bluetooth Device      */
   /* specified by the Bluetooth Protocol Stack ID.  The second         */
   /* parameter contains the Bluetooth Address to set.  This function   */
   /* returns zero if successful or a negative return error code if     */
   /* there was an error.                                               */
int BTPSAPI PM_VS_Write_BD_ADDR(BD_ADDR_t BD_ADDR)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];
	Byte_t OGF;
	Word_t OCF;

	/* Send the command to set the sleep mode configuration.          */
	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_WRITE_BD_ADDR_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_WRITE_BD_ADDR_COMMAND_OPCODE);

	ret_val = DEVM_SendRawHCICommand(OGF, OCF, BD_ADDR_SIZE, (Byte_t *)(&BD_ADDR), &Status, &Length, ReturnBuffer, TRUE);

	/* Map the return results into an error code.                     */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_Set_Power_Vector command.  Refer to the Bluetooth (WL18xx */
   /* and WL18xxQ) Vendor-Specific HCI Commands User's Guide for a      */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_DRPb_Set_Power_Vector(Byte_t ModulationType, Byte_t *PowerLevels, Byte_t PowerLevelIndex)
{
	const int    NumberPowerLevels = 8;
	int          ret_val;
	unsigned int Index;
	Byte_t       Length;
	Byte_t       Status;
	Byte_t       ReturnBuffer[8];
	Byte_t       CommandBuffer[BYTE_SIZE + (sizeof(PowerLevels[0]) * NumberPowerLevels) + BYTE_SIZE + WORD_SIZE];
	Byte_t       OGF;
	Word_t       OCF;

	Index = 0;

	/* Format the command to send.                                    */
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[Index++]), ModulationType);
	BTPS_MemCopy(&(CommandBuffer[Index]), PowerLevels, (sizeof(PowerLevels[0]) * NumberPowerLevels));
	Index += (sizeof(PowerLevels[0]) * NumberPowerLevels);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&(CommandBuffer[Index++]), PowerLevelIndex);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&(CommandBuffer[Index]), 0x0000);

	/* Send the command to set the sleep mode configuration.          */
	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_SET_POWER_VECTOR_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_SET_POWER_VECTOR_COMMAND_OPCODE);

	ret_val = DEVM_SendRawHCICommand(OGF, OCF, sizeof(CommandBuffer), (Byte_t *)(CommandBuffer), &Status, &Length, ReturnBuffer, TRUE);

	/* Map the return results into an error code.                     */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

/* The following function is used to write the codec interface       */
/* parameters and the PCM and Frame Sync frequencies.  This function */
/* returns zero if successful or a negative return error code if     */
/* there was an error.                                               */
/* * NOTE * PCMFreq is in kHz, whereas FSyncFreq is in Hz.           */
/*          IsMaster - should be non zero if CC256x is clock Master  */
int BTPSAPI PM_VS_PCM_Codec_Config(PCMCodecConfig_t *CodecConfig)
{
	int    ret_val;
	Byte_t CommandBuffer[34];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	/* PCM clock rate and direction                                   */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[0], CodecConfig->PCMFreq);
	CommandBuffer[2] = CodecConfig->ClockDirection;

	/* Frame-sync frequency, duty cycle, edge, and polarity           */
	ASSIGN_HOST_DWORD_TO_LITTLE_ENDIAN_UNALIGNED_DWORD(&CommandBuffer[3], CodecConfig->FSyncFreq);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[7], 0x0001);

	/* 0 = rising edge, 1 = falling edge                              */
	CommandBuffer[9]  = CodecConfig->FsyncEdge;

	/* 0 = active high, 1 = active low                                */
	CommandBuffer[10] = CodecConfig->FSyncPolarity;

	/* channel 1 data out size, offset, and edge                      */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[12], CodecConfig->CH1Out.Size);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[14], CodecConfig->CH1Out.Offset);
	CommandBuffer[16] = CodecConfig->CH1Out.Edge;        /* 0 = rising edge, 1 = falling edge  */

	/* channel 1 data in size, offset, and edge                       */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[17], CodecConfig->CH1In.Size);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[19], CodecConfig->CH1In.Offset);
	CommandBuffer[21] = CodecConfig->CH1In.Edge;        /* 0 = rising edge, 1 = falling edge  */

	/* channel 1 data out size, offset, and edge                      */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[23], CodecConfig->CH2Out.Size);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[25], CodecConfig->CH2Out.Offset);
	CommandBuffer[27] = CodecConfig->CH2Out.Edge;        /* 0 = rising edge, 1 = falling edge  */

	/* channel 1 data in size, offset, and edge                       */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[28], CodecConfig->CH2In.Size);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[30], CodecConfig->CH2In.Offset);
	CommandBuffer[32] = CodecConfig->CH2In.Edge;        /* 0 = rising edge, 1 = falling edge  */


	Length        = sizeof(ReturnBuffer);
	CommandLength = (Byte_t)sizeof(CommandBuffer);
	OGF           = VS_COMMAND_OGF(VS_WRITE_CODEC_CONFIG_COMMAND_OPCODE);
	OCF           = VS_COMMAND_OCF(VS_WRITE_CODEC_CONFIG_COMMAND_OPCODE);

	ret_val       = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}


   /* The following function is used to enable or disable the AVPR      */
   /* features.  This function returns zero if successful or a negative */
   /* return error code if there was an error.                          */
int BTPSAPI PM_VS_AVPR_Enable(Boolean_t AVPREnable, Boolean_t LoadCode, Byte_t A3DPRole)
{
	int    ret_val;
	Byte_t CommandBuffer[5];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Initialize the command buffer.                                 */
	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	/* Determine whether we should enable or disable AVPR.            */
	CommandBuffer[0] = (Byte_t)((AVPREnable)?1:0);
	CommandBuffer[1] = A3DPRole;
	CommandBuffer[2] = (Byte_t)((LoadCode)?1:0);

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_AVPR_ENABLE_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_AVPR_ENABLE_COMMAND_OPCODE);

	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* DRPb_Enable_RF_Calibration_Enhanced command.  Refer to the        */
   /* Bluetooth (WL18xx and WL18xxQ) Vendor-Specific HCI Commands User's*/
   /* Guide for a description of the command's parameters.  This        */
   /* function returns 0 on success and a negative error code otherwise.*/
int BTPSAPI PM_VS_DRPb_Enable_RF_Calibration_Enhanced(Byte_t Mode, Byte_t PeriodicOptions, DWord_t CalibrationProcedures, Byte_t OverrideTemperatureCondition)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t OGF;
	Word_t OCF;
	Byte_t CommandBuffer[BYTE_SIZE + BYTE_SIZE + DWORD_SIZE + BYTE_SIZE];
	Byte_t ReturnBuffer[1];

	/* Format the HCI Vendor-Specific DRPB Enable RF Calibration      */
	/* Enhanced Command.                                              */
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[0],   Mode);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[1],   PeriodicOptions);
	ASSIGN_HOST_DWORD_TO_LITTLE_ENDIAN_UNALIGNED_DWORD(&CommandBuffer[2], CalibrationProcedures);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[6],   OverrideTemperatureCondition);

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_ENABLE_RF_CALIBRATION_ENHANCED_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_ENABLE_RF_CALIBRATION_ENHANCED_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, sizeof(CommandBuffer), (Byte_t *)CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_Tester_Con_TX command.  Refer to the Bluetooth (WL18xx and*/
   /* WL18xxQ) Vendor-Specific HCI Commands User's Guide for a          */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_DRPb_Tester_Con_TX(Word_t Frequency, VS_Modulation_Type_t Modulation, VS_Test_Pattern_t TestPattern, Byte_t PowerLevelIndex)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t OGF;
	Word_t OCF;
	Byte_t CommandBuffer[13];
	Byte_t ReturnBuffer[1];

	/* Format the HCI Vendor-Specific DRPB Continuous Tx Command.     */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[0],   Frequency);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[2],   Modulation);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[3],   TestPattern);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[4],   PowerLevelIndex);
	ASSIGN_HOST_DWORD_TO_LITTLE_ENDIAN_UNALIGNED_DWORD(&CommandBuffer[5], 0x00000000);
	ASSIGN_HOST_DWORD_TO_LITTLE_ENDIAN_UNALIGNED_DWORD(&CommandBuffer[9], 0x00000000);

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_TESTER_CON_TX_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_TESTER_CON_TX_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, (Byte_t)sizeof(CommandBuffer), (Byte_t *)CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_Tester_Packet_TX_RX command.  Refer to the Bluetooth      */
   /* (WL18xx and WL18xxQ) Vendor-Specific HCI Commands User's Guide for*/
   /* a description of the command's parameters.  This function returns */
   /* 0 on success and a negative error code otherwise.                 */
int BTPSAPI PM_VS_DRPb_Tester_Packet_TX_RX(VS_DRPb_Tester_Packet_TX_RX_Params_t *VS_DRPb_Tester_Packet_TX_RX_Params)
{
	int          ret_val;
	unsigned int Index;
	Byte_t       Length;
	Byte_t       Status;
	Byte_t       OGF;
	Word_t       OCF;
	Byte_t       CommandBuffer[BYTE_SIZE + BYTE_SIZE + WORD_SIZE + WORD_SIZE + BYTE_SIZE + BYTE_SIZE + WORD_SIZE + BYTE_SIZE + BYTE_SIZE + WORD_SIZE];
	Byte_t       ReturnBuffer[1];

	Index = 0;

	/* Format the HCI Vendor-Specific Packet Tx/Rx Command.           */
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_Tester_Packet_TX_RX_Params->ACLTXPacketType);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_Tester_Packet_TX_RX_Params->FrequencyMode);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index], VS_DRPb_Tester_Packet_TX_RX_Params->TXSingleFrequency);
	Index += WORD_SIZE;
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index], VS_DRPb_Tester_Packet_TX_RX_Params->RXSingleFrequency);
	Index += WORD_SIZE;
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_Tester_Packet_TX_RX_Params->ACLTXPacketDataPattern);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], 0x00);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index], VS_DRPb_Tester_Packet_TX_RX_Params->ACLPacketDataLength);
	Index += WORD_SIZE;
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_Tester_Packet_TX_RX_Params->PowerLevelIndex);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_Tester_Packet_TX_RX_Params->DisableWhitening);
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index], VS_DRPb_Tester_Packet_TX_RX_Params->PRBS9InitValue);

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_PACKET_TX_RX_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_PACKET_TX_RX_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, (Byte_t)sizeof(CommandBuffer), (Byte_t *)CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_Tester_Con_RX command.  Refer to the Bluetooth (WL18xx and*/
   /* WL18xxQ) Vendor-Specific HCI Commands User's Guide for a          */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_DRPb_Tester_Con_RX(Word_t Frequency, Byte_t RxMode, Byte_t ModulationType)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t OGF;
	Word_t OCF;
	Byte_t CommandBuffer[4];
	Byte_t ReturnBuffer[1];

	/* Format the HCI Vendor-Specific Packet Tx/Rx Command.           */
	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[0], Frequency);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[2], RxMode);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[3], ModulationType);

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_TESTER_CON_RX_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_TESTER_CON_RX_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, (Byte_t)sizeof(CommandBuffer), (Byte_t *)CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_Reset command.  Refer to the Bluetooth (WL18xx and        */
   /* WL18xxQ) Vendor-Specific HCI Commands User's Guide for a          */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_DRPb_Reset(unsigned int BluetoothStackID)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t OGF;
	Word_t OCF;
	Byte_t ReturnBuffer[1];

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_RESET_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_RESET_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, 0, NULL, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRPb_BER_Meter_Start command.  Refer to the Bluetooth (WL18xx  */
   /* and WL18xxQ) Vendor-Specific HCI Commands User's Guide for a      */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_DRPb_BER_Meter_Start(VS_DRPb_BER_Meter_Start_Params_t *VS_DRPb_BER_Meter_Start_Params)
{
	int          ret_val;
	unsigned int Index;
	Byte_t       Length;
	Byte_t       Status;
	Byte_t       OGF;
	Word_t       OCF;
	Byte_t       CommandBuffer[(BYTE_SIZE * 5) + (WORD_SIZE * 3) + BD_ADDR_SIZE];
	Byte_t       ReturnBuffer[1];
	BD_ADDR_t    TempBD_ADDR;

	Index = 0;

	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_BER_Meter_Start_Params->ChannelIndex);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], 0x00);

	/* Place the BD_ADDR in to the buffer in big endian order, note   */
	/* that this different than other commands in the Bluetooth       */
	/* specification where the BD_ADDR is expected to be in little    */
	/* endian order.                                                  */
	/* The TI chipset expects the BD_ADDR to be in big endian format  */
	/* so convert the little endian BD_ADDR to big endian.            */
	SwapEndianessBD_ADDR(&(VS_DRPb_BER_Meter_Start_Params->BD_ADDR), &TempBD_ADDR);
	BTPS_MemCopy(&CommandBuffer[Index], &TempBD_ADDR, sizeof(TempBD_ADDR));
	Index += BD_ADDR_SIZE;

	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_BER_Meter_Start_Params->LT_Address);
	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++], VS_DRPb_BER_Meter_Start_Params->PacketType);

	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index],   VS_DRPb_BER_Meter_Start_Params->PacketLength);
	Index += WORD_SIZE;

	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index],   VS_DRPb_BER_Meter_Start_Params->NumberOfPackets);
	Index += WORD_SIZE;

	ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[Index],   VS_DRPb_BER_Meter_Start_Params->PRBS_InitializationValue);
	Index += WORD_SIZE;

	ASSIGN_HOST_BYTE_TO_LITTLE_ENDIAN_UNALIGNED_BYTE(&CommandBuffer[Index++],   VS_DRPb_BER_Meter_Start_Params->PollPeriod);

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRPB_BER_METER_START_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRPB_BER_METER_START_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, (Byte_t)Index, (Byte_t *)CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_DRP_Read_BER_Meter_Result command.  Refer to the Bluetooth     */
   /* (WL18xx and WL18xxQ) Vendor-Specific HCI Commands User's Guide for*/
   /* a description of the command's parameters.  This function returns */
   /* 0 on success and a negative error code otherwise.                 */
int BTPSAPI PM_VS_DRP_Read_BER_Meter_Result(VS_DRP_Read_BER_Meter_Result_Return_Params_t *VS_DRP_Read_BER_Meter_Result_Return_Params)
{
	int    ret_val;
	Byte_t Length;
	Byte_t Status;
	Byte_t OGF;
	Word_t OCF;
	Byte_t ReturnBuffer[12];

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_DRP_READ_BER_METER_RESULT_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_DRP_READ_BER_METER_RESULT_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, 0, NULL, &Status, &Length, ReturnBuffer, TRUE);

	if(!(ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer)))
	{
		VS_DRP_Read_BER_Meter_Result_Return_Params->FinishedAtLeastOneTest  = READ_UNALIGNED_BYTE_LITTLE_ENDIAN(&ReturnBuffer[1]);
		VS_DRP_Read_BER_Meter_Result_Return_Params->NumberOfPacketsReceived = READ_UNALIGNED_WORD_LITTLE_ENDIAN(&ReturnBuffer[2]);
		VS_DRP_Read_BER_Meter_Result_Return_Params->TotalBitsCounted        = READ_UNALIGNED_DWORD_LITTLE_ENDIAN(&ReturnBuffer[4]);
		VS_DRP_Read_BER_Meter_Result_Return_Params->NumberOfErrorsFound     = READ_UNALIGNED_DWORD_LITTLE_ENDIAN(&ReturnBuffer[8]);
	}

	return(ret_val);
}

   /* The following function implements the vendor-specific             */
   /* VS_Read_Patch_Version command.  Refer to the Bluetooth (WL18xx and*/
   /* WL18xxQ) Vendor-Specific HCI Commands User's Guide for a          */
   /* description of the command's parameters.  This function returns 0 */
   /* on success and a negative error code otherwise.                   */
int BTPSAPI PM_VS_Read_Patch_Version(VS_Read_Patch_Version_Return_Params_t *VS_Read_Patch_Version_Return_Params)
{
	int          ret_val;
	unsigned int Index;
	Byte_t       Length;
	Byte_t       Status;
	Byte_t       OGF;
	Word_t       OCF;
	Byte_t       ReturnBuffer[11];

	Length  = sizeof(ReturnBuffer);
	OGF     = VS_COMMAND_OGF(VS_READ_PATCH_VERSION_COMMAND_OPCODE);
	OCF     = VS_COMMAND_OCF(VS_READ_PATCH_VERSION_COMMAND_OPCODE);
	ret_val = DEVM_SendRawHCICommand(OGF, OCF, 0, NULL, &Status, &Length, ReturnBuffer, TRUE);

	if(!(ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer)))
	{
		BTPS_MemInitialize(VS_Read_Patch_Version_Return_Params, 0x00, sizeof(*VS_Read_Patch_Version_Return_Params));

		Index = 1;

		BTPS_MemCopy(VS_Read_Patch_Version_Return_Params->EnabledMask, &ReturnBuffer[Index], sizeof(VS_Read_Patch_Version_Return_Params->EnabledMask));
		Index += sizeof(VS_Read_Patch_Version_Return_Params->EnabledMask);

		VS_Read_Patch_Version_Return_Params->ReleaseMajor = READ_UNALIGNED_BYTE_LITTLE_ENDIAN(&ReturnBuffer[Index++]);
		VS_Read_Patch_Version_Return_Params->ReleaseMinor = READ_UNALIGNED_BYTE_LITTLE_ENDIAN(&ReturnBuffer[Index++]);
		VS_Read_Patch_Version_Return_Params->PackageID    = READ_UNALIGNED_BYTE_LITTLE_ENDIAN(&ReturnBuffer[Index++]);
		VS_Read_Patch_Version_Return_Params->BuildNumber  = READ_UNALIGNED_BYTE_LITTLE_ENDIAN(&ReturnBuffer[Index]);
	}

	return(ret_val);
}

   /* The following function is a wrapper for the                       */
   /* VS_DRPb_BER_Meter_Start and VS_DRP_Read_BER_Meter_Result          */
   /* vendor-specific commands .  It implements the procedure for the   */
   /* WL18xx PLT Tests documented on TI's WL18xx Bluetopia PM Bluetooth */
   /* RF Testing Wiki guide.  Refer to the Bluetooth (WL18xx and        */
   /* WL18xxQ) Vendor-Specific HCI Commands User's Guide for a          */
   /* description of the return parameters.  This function returns 0 on */
   /* success and a negative error code otherwise.                      */
int BTPSAPI PM_VS_Production_Line_Test(BD_ADDR_t BD_ADDR, VS_DRP_Read_BER_Meter_Result_Return_Params_t *VS_DRP_Read_BER_Meter_Result_Return_Params)
{
	int                              ret_val;
	VS_DRPb_BER_Meter_Start_Params_t VS_DRPb_BER_Meter_Start_Params;

	VS_DRPb_BER_Meter_Start_Params.ChannelIndex             = 0;
	VS_DRPb_BER_Meter_Start_Params.BD_ADDR                  = BD_ADDR;
	VS_DRPb_BER_Meter_Start_Params.LT_Address               = 1;
	VS_DRPb_BER_Meter_Start_Params.PacketType               = 0x01;
	VS_DRPb_BER_Meter_Start_Params.PacketLength             = 27;
	VS_DRPb_BER_Meter_Start_Params.NumberOfPackets          = 1000;
	VS_DRPb_BER_Meter_Start_Params.PRBS_InitializationValue = 0x1FF;
	VS_DRPb_BER_Meter_Start_Params.PollPeriod               = 0x01;

	if(!(ret_val = PM_VS_DRPb_BER_Meter_Start(&VS_DRPb_BER_Meter_Start_Params)))
	{
		BTPS_Delay(5000);

		ret_val = PM_VS_DRP_Read_BER_Meter_Result(VS_DRP_Read_BER_Meter_Result_Return_Params);
	}

	return(ret_val);
}

   /* The following function is called when an A2DP connection is in the*/
   /* open state to tell the controller the L2CAP parameters of the     */
   /* channel.  This function returns zero if successful or a negative  */
   /* return error code if there was an error.                          */
int BTPSAPI PM_VS_A3DP_Open_Stream(Byte_t Connection_Handle, Word_t CID, Word_t MTU)
{
	int    ret_val;
	Byte_t CommandBuffer[15];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	if(Connection_Handle)
	{
		BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));
		CommandBuffer[0] = Connection_Handle;

		/* AVDTP version parameter [0x00 - 0x03].                         */
		CommandBuffer[5] = 0x02;

		/* AVDTP payload parameter [0x30 - 0xFF].                         */
		CommandBuffer[6] = 0x65;

		ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[1], CID);
		ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[3], MTU);

		CommandLength = (Byte_t)sizeof(CommandBuffer);
		Length        = sizeof(ReturnBuffer);
		OGF           = VS_COMMAND_OGF(VS_A3DP_OPEN_STREAM_COMMAND_OPCODE);
		OCF           = VS_COMMAND_OCF(VS_A3DP_OPEN_STREAM_COMMAND_OPCODE);
		ret_val       = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

		/* Map the Send Raw return results.                               */
		ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);
	}
	else
		ret_val = BTPS_ERROR_INVALID_PARAMETER;

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to inform the controller when A2DP */
   /* connection closes.  This function returns zero if successful or a */
   /* negative return error code if there was an error.                 */
int BTPSAPI PM_VS_A3DP_Close_Stream(Byte_t Connection_Handle)
{
   int    ret_val;
   Byte_t CommandBuffer[5];
   Byte_t CommandLength;
   Word_t OCF;
   Byte_t OGF;
   Byte_t Length;
   Byte_t Status;
   Byte_t ReturnBuffer[1];

   /* Verify that the parameters that were passed in appear valid.      */
   if(Connection_Handle)
   {
      BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));
      CommandBuffer[0] = Connection_Handle;

      CommandLength    = (Byte_t)sizeof(CommandBuffer);
      Length           = sizeof(ReturnBuffer);
      OGF              = VS_COMMAND_OGF(VS_A3DP_CLOSE_STREAM_COMMAND_OPCODE);
      OCF              = VS_COMMAND_OCF(VS_A3DP_CLOSE_STREAM_COMMAND_OPCODE);
      ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

      /* Map the Send Raw return results.                               */
      ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);
   }
   else
      ret_val = BTPS_ERROR_INVALID_PARAMETER;

   /* Return the result the caller.                                     */
   return(ret_val);
}

   /* The following function is used to configure the SBC Encoder or    */
   /* Decoder parameters.  This function returns zero if successful or a*/
   /* negative return error code if there was an error.                 */
int BTPSAPI PM_VS_A3DP_Codec_Configuration(Byte_t AudioFormat, Byte_t SBCFormat, Byte_t BitPoolSize)
{
	int    ret_val;
	Byte_t CommandBuffer[19];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	CommandBuffer[0] = AVRP_SOURCE_PCM;
	CommandBuffer[1] = (AudioFormat & AVRP_AUDIO_FORMAT_PCM_SAMPLE_RATE_MASK);
	CommandBuffer[2] = (Byte_t)(((AudioFormat & AVRP_AUDIO_FORMAT_SBC_MODE_MASK) == AVRP_AUDIO_FORMAT_SBC_MODE_MONO)?1:2);
	CommandBuffer[3] = ((AudioFormat & AVRP_AUDIO_FORMAT_SBC_SAMPLE_RATE_MASK) >> 4);
	CommandBuffer[4] = ((AudioFormat & AVRP_AUDIO_FORMAT_SBC_MODE_MASK) >> 6);

	/* Convert from 0,1,2,3 to 4,8,12,16 for the block length.        */
	CommandBuffer[5] = ((SBCFormat & AVRP_SBC_FORMAT_BLOCK_LENGTH_MASK) + 1) << 2;
	CommandBuffer[6] = 8;
	CommandBuffer[7] = ((SBCFormat & AVRP_SBC_FORMAT_ALLOCATION_METHOD_MASK) >> 2);

	/* old value used to be 12 minimum bit pool.                      */
	CommandBuffer[8] = 20;
	CommandBuffer[9] = BitPoolSize;

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_A3DP_CODEC_CONFIGURATION_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_A3DP_CODEC_CONFIGURATION_COMMAND_OPCODE);
	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to start assisted A2DP streaming.  */
   /* This function returns zero if successful or a negative return     */
   /* error code if there was an error.                                 */
int BTPSAPI PM_VS_A3DP_Start_Stream(Byte_t Connection_Handle)
{
	int    ret_val;
	Byte_t CommandBuffer[5];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	if(Connection_Handle)
	{
		BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));
		CommandBuffer[0] = Connection_Handle;

		CommandLength    = (Byte_t)sizeof(CommandBuffer);
		Length           = sizeof(ReturnBuffer);
		OGF              = VS_COMMAND_OGF(VS_A3DP_START_STREAM_COMMAND_OPCODE);
		OCF              = VS_COMMAND_OCF(VS_A3DP_START_STREAM_COMMAND_OPCODE);
		ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

		/* Map the Send Raw return results.                               */
		ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);
	}
	else
		ret_val = BTPS_ERROR_INVALID_PARAMETER;

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to stop assisted A2DP streaming.   */
   /* This function returns zero if successful or a negative return     */
   /* error code if there was an error.                                 */
int BTPSAPI PM_VS_A3DP_Stop_Stream(Byte_t Connection_Handle, Byte_t Flags)
{
   int    ret_val;
   Byte_t CommandBuffer[7];
   Byte_t CommandLength;
   Word_t OCF;
   Byte_t OGF;
   Byte_t Length;
   Byte_t Status;
   Byte_t ReturnBuffer[1];

   /* Verify that the parameters that were passed in appear valid.      */
   if(Connection_Handle)
   {
      BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));
      CommandBuffer[0] = Connection_Handle;
      CommandBuffer[1] = (Byte_t)((Flags & STOP_STREAM_FLAG_FLUSH_DATA)?1:0);
      CommandBuffer[2] = (Byte_t)((Flags & STOP_STREAM_FLAG_GENERATE_STOP_EVENT)?1:0);

      CommandLength    = (Byte_t)sizeof(CommandBuffer);
      Length           = sizeof(ReturnBuffer);
      OGF              = VS_COMMAND_OGF(VS_A3DP_STOP_STREAM_COMMAND_OPCODE);
      OCF              = VS_COMMAND_OCF(VS_A3DP_STOP_STREAM_COMMAND_OPCODE);
      ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

      /* Map the Send Raw return results.                               */
      ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);
   }
   else
      ret_val = BTPS_ERROR_INVALID_PARAMETER;

   /* Return the result the caller.                                     */
   return(ret_val);
}

   /* The following function is used to open a stream as an A2DP SNK    */
   /* device. This function returns zero if successful or a negative    */
   /* return error code if there was an error.                          */
int BTPSAPI PM_VS_A3DP_Sink_Open_Stream(Byte_t Connection_Handle, Word_t CID)
{
	int    ret_val;
	Byte_t CommandBuffer[11];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	if((Connection_Handle) && (CID))
	{
		BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

		CommandBuffer[0] = Connection_Handle;
		ASSIGN_HOST_WORD_TO_LITTLE_ENDIAN_UNALIGNED_WORD(&CommandBuffer[1], CID);

		CommandLength    = (Byte_t)sizeof(CommandBuffer);
		Length           = sizeof(ReturnBuffer);
		OGF              = VS_COMMAND_OGF(VS_A3DP_SINK_OPEN_STREAM_COMMAND_OPCODE);
		OCF              = VS_COMMAND_OCF(VS_A3DP_SINK_OPEN_STREAM_COMMAND_OPCODE);
		ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

		/* Map the Send Raw return results.                               */
		ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);
	}
	else
		ret_val = BTPS_ERROR_INVALID_PARAMETER;

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to close a SNK stream previously   */
   /* opened using VS_A3DP_Sink_Open_Stream. This function returns zero */
   /* if successful or a negative return error code if there was an     */
   /* error.                                                            */
int BTPSAPI PM_VS_A3DP_Sink_Close_Stream(unsigned int BluetoothStackID)
{
	int    ret_val;
	Byte_t CommandBuffer[4];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_A3DP_SINK_CLOSE_STREAM_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_A3DP_SINK_CLOSE_STREAM_COMMAND_OPCODE);
	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to configure an A3DP device as an  */
   /* A2DP SNK, giving it PCM and SBC parameters. This configuration    */
   /* should be performed after VS_PCM_CodecConfig and VS_AVPR_Enable.  */
   /* This function returns zero if successful or a negative return     */
   /* error code if there was an error.                                 */
int BTPSAPI PM_VS_A3DP_Sink_Codec_Configuration(Byte_t AudioFormat, Byte_t SBCFormat)
{
	int    ret_val;
	Byte_t CommandBuffer[18];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	CommandBuffer[0] = (Byte_t)(((AudioFormat & AVRP_AUDIO_FORMAT_SBC_MODE_MASK) == AVRP_AUDIO_FORMAT_SBC_MODE_MONO)?1:2);;
	CommandBuffer[1] = ((AudioFormat & AVRP_AUDIO_FORMAT_SBC_SAMPLE_RATE_MASK) >> 4);
	CommandBuffer[2] = ((AudioFormat & AVRP_AUDIO_FORMAT_SBC_MODE_MASK) >> 6);
	CommandBuffer[3] = ((SBCFormat & AVRP_SBC_FORMAT_BLOCK_LENGTH_MASK) + 1) << 2;
	CommandBuffer[4] = 8;
	CommandBuffer[5] = ((SBCFormat & AVRP_SBC_FORMAT_ALLOCATION_METHOD_MASK) >> 2);

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_A3DP_SINK_CODEC_CONFIGURATION_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_A3DP_SINK_CODEC_CONFIGURATION_COMMAND_OPCODE);
	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to change a stream previously      */
   /* opened via VS_A3DP_Sink_Open_Stream to the "Playing" state. This  */
   /* function returns zero if successful or a negative return error    */
   /* code if there was an error.                                       */
int BTPSAPI PM_VS_A3DP_Sink_Start_Stream()
{
	int    ret_val;
	Byte_t CommandBuffer[4];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_A3DP_SINK_START_STREAM_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_A3DP_SINK_START_STREAM_COMMAND_OPCODE);
	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

   /* The following function is used to change a stream previously      */
   /* opened via VS_A3DP_Sink_Open_stream to the "Stopped" state.  This */
   /* function returns zero if successful or a negative return error    */
   /* code if there was an error.                                       */
int BTPSAPI PM_VS_A3DP_Sink_Stop_Stream()
{
	int    ret_val;
	Byte_t CommandBuffer[4];
	Byte_t CommandLength;
	Word_t OCF;
	Byte_t OGF;
	Byte_t Length;
	Byte_t Status;
	Byte_t ReturnBuffer[1];

	/* Verify that the parameters that were passed in appear valid.      */
	BTPS_MemInitialize(CommandBuffer, 0, sizeof(CommandBuffer));

	CommandLength    = (Byte_t)sizeof(CommandBuffer);
	Length           = sizeof(ReturnBuffer);
	OGF              = VS_COMMAND_OGF(VS_A3DP_SINK_STOP_STREAM_COMMAND_OPCODE);
	OCF              = VS_COMMAND_OCF(VS_A3DP_SINK_STOP_STREAM_COMMAND_OPCODE);
	ret_val          = DEVM_SendRawHCICommand(OGF, OCF, CommandLength, CommandBuffer, &Status, &Length, ReturnBuffer, TRUE);

	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, Length, ReturnBuffer);

	/* Return the result the caller.                                     */
	return(ret_val);
}

/*
 *  Function Name: SendHciDDIPCommand.
 *  Description: The following function is responsible for sending HCI
 *  	vendor specific command, for changing the Remote Bluetooth device ACL
 *  	priority over scans.
 *
 *  Input: The remote device Bluetooth address.
 *
 *  Output: None
 *
 *  Notes: The function is sent when start playing A2DP stream to
 *  	give priority to the audio data over scans.
 *
 */

int BTPSAPI PM_VS_DDIPCommand(Byte_t best_effort_percentage, Byte_t guaranteed_percentage)
{
	int 	ret_val;
	Byte_t  Length;
	Byte_t  Status;
	Byte_t  CommandData[9];
	Byte_t  ResultLength;
	Byte_t  ResultBuffer[32];

	Length = VS_DDIP_COMMAND_LENGTH;
	/* Best Effort percentage over scans, 1 bytes */
	CommandData[0] = (Byte_t) best_effort_percentage;
	/* Guaranteed percentage over scans, 1 bytes */
	CommandData[1] = (Byte_t) guaranteed_percentage;
	/* Poll Period, 1 byte, 0x02 */
	CommandData[2] = (Byte_t) POLL_PERIODE;
	/* The number of frames for ACK reception after the slave transmitted packet. */
	/* Slave Wait After TX Boundary, 1 byte, outgoing = 0x07 */
	CommandData[3] = (Byte_t) SLAVE_WAIT_AFTER_ACK_TX_BOUNDARY;
	/* The max number of frames that the Slave search for the Master during DDIP */
	/* Master Search Boundary, 1 byte, outgoing = 0x02 */
	CommandData[4] = (Byte_t) MASTER_SEARCH_BOUNDARY;
	CommandData[5] = (Byte_t) MASTER_BURST_AFTER_RX_ENABLE;
	CommandData[6] = (Byte_t) MASTER_BURST_AFTER_RX_LIMIT;
	/* Reserved 2 Bytes = 0xFF */
	CommandData[7] = (Byte_t) 0xFF;
	CommandData[8] = (Byte_t) 0xFF;
	/* Send Vendor DDIP command, OGF=0x155, */
	ret_val = DEVM_SendRawHCICommand(HCI_COMMAND_CODE_VENDOR_SPECIFIC_DEBUG_OGF, (Word_t) VS_COMMAND_OCF(VS_CONFIGURE_DDIP_COMMAND_OPCODE),
			Length, CommandData, &Status, &ResultLength, ResultBuffer, TRUE);
	/* Map the Send Raw return results.                               */
	ret_val = MapSendRawResults(ret_val, Status, ResultLength, ResultBuffer);
	return(ret_val);
}

