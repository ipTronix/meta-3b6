
# This script copies the GStreamer plugin to a system library path.

cp ./*.so /usr/lib/gstreamer-0.10
