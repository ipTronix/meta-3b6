/*****< btpmdbg.h >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMDBG - Debug Module for the Stonestreet One Bluetopia Platform         */
/*            Manager.                                                        */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   05/25/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPMDBGH__
#define __BTPMDBGH__

#include "BTPMCFG.h"             /* BTPM Configuration Settings/Constants.    */

#include "DBGAPI.h"              /* Debug API Prototypes and Constants.       */

   /* The following constant will allow the inclusion of the debug      */
   /* functionality to be included.                                     */
   /* * NOTE * This also allows the ability for the debugging framework */
   /*          to be built without altering the configuration file (if  */
   /*          this functionality is required).                         */
#if (BTPM_CONFIGURATION_DEBUG_DEBUG_FRAMEWORK_PRESENT != 0)

   #define __BTPMDEBUG__

#endif

   /* * NOTE * The use of some of these MACRO's requires that the       */
   /*          parameters of each MACRO be bounded by parenthesis (any  */
   /*          parameter that is actually a variable argument length    */
   /*          parameter - currently only a single function has this    */
   /*          limitation).  To clarify, the following examples show    */
   /*          the format must be used when calling each MACRO:         */
   /*                                                                   */
   /*             DebugInit(NULL);                                      */
   /*             DebugPrint(ZONE1, ("Result is %d\r\n", Result));      */
   /*             DebugDump(ZONE1, sizeof(Buffer), Buffer);             */
   /*             DebugZoneMask(NewZoneMask);                           */
   /*                                                                   */
   /*          Not all of the MACRO's would require this syntax.  The   */
   /*          only MACRO is the DebugPrint MACRO which requires that   */
   /*          any parameter specified after the Zone ID be enclosed in */
   /*          parenthesis.                                             */
   /* * NOTE * See the function prototypes at the bottom of this file   */
   /*          for the parameters that each of the MACROs accept.       */
   /* * NOTE * All debug strings that are accepted by this module are   */
   /*          in ASCII format.                                         */

   /* Define the correct MACRO's/functions based on the debugging       */
   /* requested (see note above about the preprocessor definitions that */
   /* control the debugging output).                                    */
#ifdef __BTPMDEBUG__

   /* Some form of debugging is to be linked in, now determine the type */
   /* of requested debugging.                                           */

   #define DebugInit(_x)                     BTPM_DebugInit(_x)

#else

   /* Debugging disabled, make sure no debugging is linked in.          */

   #define DebugInit(_x)

#endif

   /* The following function is a utility function that initializes the */
   /* Debug Module.  The parameter that is passed to this function is   */
   /* opaque and is passed directly to the implementation and utilized  */
   /* there.                                                            */
void BTPM_DebugInit(BTPM_Debug_Initialization_Data_t *DebugInitData);

#endif
