/*****< btpmdbgi.h >***********************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMDBGI - Debug Implentation Protypes/Constants for the Stonestreet One  */
/*             Bluetooth Protocol Stack Platform Manager.                     */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   05/25/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPMDBGIH__
#define __BTPMDBGIH__

   /* The following function is provided to allow a mechanism to perform*/
   /* any required Debug Module Implementation initialization           */
   /* functionality.                                                    */
void _BTPMDebugInit(void *DebugInitData);

   /* The following function is provided to allow a mechanism to perform*/
   /* any required Debug Module Implementation reconfiguration          */
   /* functionality (as an example to select a new debug output method).*/
void _BTPMDebugReconfigure(void *DebugReconfigureData);

   /* The following function is provided to allow a mechanism to        */
   /* actually output the specified Debug Output String to the currently*/
   /* active debug mechanism.                                           */
void _BTPMDebugOutput(char *DebugString);

#endif
