/*****< btpmmmsg.h >***********************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMMMSG - Defined Interprocess Communication Messages for Main           */
/*             Bluetopia Protocol Stack Platform Manager Control.             */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/13/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPMMMSGH__
#define __BTPMMMSGH__

#include "BTAPITyp.h"            /* Bluetooth API Type Definitions.           */

#include "BTPMMSGT.h"            /* BTPM Message Type Definitions/Constants.  */

   /* The following Message Group constant represents the Bluetopia     */
   /* Platform Manager Message Group that specifies the Main Platform   */
   /* Manager Control Manager.                                          */
#define BTPM_MESSAGE_GROUP_MAIN_PLATFORM_MANAGER               0x00000100

   /* The following constants represent the defined Bluetopia Platform  */
   /* Manager Message Functions that are valid for the Main Platform    */
   /* Manager Control Manager.                                          */

   /* Main Platform Manager Control Commands.                           */
#define BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK      0x00001001
#define BTPM_CONTROL_MESSAGE_FUNCTION_QUERY_DEBUG_ZONE_MASK    0x00001002
#define BTPM_CONTROL_MESSAGE_FUNCTION_SHUTDOWN_SERVICE         0x00001003
#define BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK_PID  0x00001004

   /* Main Platform Manager Asynchronous Events.                        */
#define BTPM_CONTROL_MESSAGE_FUNCTION_UPDATE_DEBUG_ZONE_MASK   0x00010001

   /* The following constants and/or definitions define the specific    */
   /* Message structures that are valid for the Main Platform Manager   */
   /* Control Manager.                                                  */

   /* Main Platform Manager Control Manager Command/Response Message    */
   /* Formats.                                                          */

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to change the debug */
   /* zone mask of the local Service (Request).                         */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK     */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Set_Debug_Zone_Mask_Request_t
{
   BTPM_Message_Header_t MessageHeader;
   unsigned long         DebugZoneMask;
} BTPM_Control_Set_Debug_Zone_Mask_Request_t;

#define BTPM_CONTROL_SET_DEBUG_ZONE_MASK_REQUEST_SIZE       (sizeof(BTPM_Control_Set_Debug_Zone_Mask_Request_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to change the debug */
   /* zone mask of the local Service (Response).                        */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK     */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Set_Debug_Zone_Mask_Response_t
{
   BTPM_Message_Header_t MessageHeader;
   int                   Status;
} BTPM_Control_Set_Debug_Zone_Mask_Response_t;

#define BTPM_CONTROL_SET_DEBUG_ZONE_MASK_RESPONSE_SIZE      (sizeof(BTPM_Control_Set_Debug_Zone_Mask_Response_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to query the current*/
   /* debug zone mask of the local Service (Request).                   */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_QUERY_DEBUG_ZONE_MASK   */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Query_Debug_Zone_Mask_Request_t
{
   BTPM_Message_Header_t MessageHeader;
   unsigned int          PageNumber;
} BTPM_Control_Query_Debug_Zone_Mask_Request_t;

#define BTPM_CONTROL_QUERY_DEBUG_ZONE_MASK_REQUEST_SIZE     (sizeof(BTPM_Control_Query_Debug_Zone_Mask_Request_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to query the current*/
   /* debug zone mask of the local Service (Request).                   */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_QUERY_DEBUG_ZONE_MASK   */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Query_Debug_Zone_Mask_Response_t
{
   BTPM_Message_Header_t MessageHeader;
   int                   Status;
   unsigned long         DebugZoneMask;
} BTPM_Control_Query_Debug_Zone_Mask_Response_t;

#define BTPM_CONTROL_QUERY_DEBUG_ZONE_MASK_RESPONSE_SIZE    (sizeof(BTPM_Control_Query_Debug_Zone_Mask_Response_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to instruct the     */
   /* local Service to shutdown (Request).                              */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SHUTDOWN_SERVICE        */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Shutdown_Service_Request_t
{
   BTPM_Message_Header_t MessageHeader;
} BTPM_Control_Shutdown_Service_Request_t;

#define BTPM_CONTROL_SHUTDOWN_SERVICE_REQUEST_SIZE          (sizeof(BTPM_Control_Shutdown_Service_Request_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to instruct the     */
   /* local Service to shutdown (Response).                             */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SHUTDOWN_SERVICE        */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Shutdown_Service_Response_t
{
   BTPM_Message_Header_t MessageHeader;
   int                   Status;
} BTPM_Control_Shutdown_Service_Response_t;

#define BTPM_CONTROL_SHUTDOWN_SERVICE_RESPONSE_SIZE         (sizeof(BTPM_Control_Shutdown_Service_Response_t))

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to instruct the     */
   /* local Service to inform the client with the specified Process ID  */
   /* to update it's Debug Zone Mask (Request).                         */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK_PID */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Set_Debug_Zone_Mask_PID_Request_t
{
   BTPM_Message_Header_t MessageHeader;
   unsigned long         ProcessID;
   unsigned long         DebugZoneMask;
} BTPM_Control_Set_Debug_Zone_Mask_PID_Request_t;

#define BTPM_CONTROL_SET_DEBUG_ZONE_MASK_PID_REQUEST_SIZE      (sizeof(BTPM_Control_Set_Debug_Zone_Mask_PID_Request_t))

   /* The following constant is used to denote that ALL client processes*/
   /* should update their Debug Zone Mask.  This constant is used with  */
   /* the ProcessID member of the                                       */
   /* BTPM_Control_Set_Debug_Zone_Mask_PID_Request_t structure.         */
#define BTPM_CONTROL_SET_DEBUG_ZONE_MASK_PID_ALL_PROCESSES     0xFFFFFFFF

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to instruct the     */
   /* local Service to inform the client with the specified Process ID  */
   /* to update it's Debug Zone Mask (Response).                        */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_SET_DEBUG_ZONE_MASK_PID */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Set_Debug_Zone_Mask_PID_Response_t
{
   BTPM_Message_Header_t MessageHeader;
   int                   Status;
} BTPM_Control_Set_Debug_Zone_Mask_PID_Response_t;

#define BTPM_CONTROL_SET_DEBUG_ZONE_MASK_PID_RESPONSE_SIZE     (sizeof(BTPM_Control_Set_Debug_Zone_Mask_PID_Response_t))

   /* Main Platform Manager Asynchronous Message Formats.               */

   /* The following structure represents the Message definition for a   */
   /* Main Platform Manager Control Manager Message to instruct the     */
   /* remote client (with matching process ID) to update the Debug      */
   /* Zone Mask it is currently using (asynchronously).                 */
   /* * NOTE * This is the message format for the                       */
   /*                                                                   */
   /*             BTPM_CONTROL_MESSAGE_FUNCTION_UPDATE_DEBUG_ZONE_MASK  */
   /*                                                                   */
   /*          Message Function ID.                                     */
typedef struct _tagBTPM_Control_Update_Debug_Zone_Mask_Message_t
{
   BTPM_Message_Header_t MessageHeader;
   unsigned long         ProcessID;
   unsigned long         DebugZoneMask;
} BTPM_Control_Update_Debug_Zone_Mask_Message_t;

#define BTPM_CONTROL_UPDATE_DEBUG_ZONE_MASK_MESSAGE_SIZE       (sizeof(BTPM_Control_Update_Debug_Zone_Mask_Message_t))

#endif
