/*****< btpmmod.h >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  BTPMMOD - Installable Module Handler for Stonestreet One Bluetooth        */
/*            Protocol Stack Platform Manager.                                */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   06/12/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __BTPMMODH__
#define __BTPMMODH__

   /* The following function is responsible for initializing the        */
   /* Bluetopia Platform Manager Module Handler Service.  This function */
   /* returns zero if successful, or a negative return error code if    */
   /* there was an error initializing the Bluetopia Platform Manager    */
   /* Module Handler Service.                                           */
int MOD_Initialize(void);

   /* The following function is responsible for shutting down the       */
   /* Bluetopia Platform Manager Module Handler Service.  After this    */
   /* function is called the Bluetooth Platform Manager Module Handler  */
   /* service will no longer operate until it is initialized again via a*/
   /* call to the MOD_Initialize() function.                            */
void MOD_Cleanup(void);

#endif
