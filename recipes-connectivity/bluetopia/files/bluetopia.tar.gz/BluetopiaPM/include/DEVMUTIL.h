/*****< devmutil.h >***********************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  DEVMUTIL - Local Device Manager Utilities Implementation for              */
/*             Stonestreet One Bluetooth Protocol Stack Platform Manager.     */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/25/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __DEVMUTILH__
#define __DEVMUTILH__

#include "SS1BTPS.h"             /* BTPS Protocol Stack Prototypes/Constants. */

#include "BTPMDEVM.h"            /* BTPM Device Manager Prototypes/Constants. */

   /* The following function is a utility function that exists to locate*/
   /* the Procotol Descriptor entry which describes the given Protocol. */
   /* This function returns a pointer to the element, or NULL if the    */
   /* protocol is not found in the given record.                        */
SDP_Data_Element_t *FindProtocolDescriptor(SDP_Service_Attribute_Response_Data_t *ServiceRecord, SDP_UUID_Entry_t *Protocol);

   /* The following function is a utility function that exists to locate*/
   /* a particular Attribute within a parsed SDP record. This function  */
   /* returns a pointer to the Attribute data, or NULL if the attribute */
   /* does not exist in the given SDP record.                           */
SDP_Data_Element_t *FindSDPAttribute(SDP_Service_Attribute_Response_Data_t *ServiceRecord, Word_t AttributeID);

   /* The following function is a utility function that exists to       */
   /* convert a UUID Entry into a 128-bit UUID. This function returns   */
   /* zero if successful, or a negative error code on failure.          */
int ConvertUUIDEntryToUUID128(SDP_UUID_Entry_t *UUIDEntry, UUID_128_t *UUID);

   /* The following function is a utility function that exists to       */
   /* convert an SDP Data Element, which contains a UUID, into a 128-bit*/
   /* UUID. This function returns zero if successful, or a negative     */
   /* error code on failure.                                            */
int ConvertSDPDataElementToUUID128(SDP_Data_Element_t *DataElement, UUID_128_t *UUID);

#endif
