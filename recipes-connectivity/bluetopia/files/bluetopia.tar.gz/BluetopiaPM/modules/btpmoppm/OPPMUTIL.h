/*****< oppmutil.h >***********************************************************/
/*      Copyright 2013 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  OPPMUTIL - Object Push Manager Utility functions for Stonestreet One      */
/*             Bluetooth Protocol Stack Platform Manager.                     */
/*                                                                            */
/*  Author:  Matt Seabold                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   12/10/13  M. Seabold     Initial creation                                */
/******************************************************************************/
#ifndef __OPPMUTILH__
#define __OPPMUTILH__

#include "BTAPITyp.h"            /* Bluetooth API Type Definitions            */
#include "SS1BTPS.h"             /* BTPS Protocol Stack Prototypes/Constants  */

#include "SS1BTPM.h"             /* Device Manager Prototypes                 */

#include "OPPMType.h"            /* BTPM OPP Manager Type Definitions         */

   /* The following function is a utility function that exists to parse */
   /* the known services of a remote device for Object Push Service     */
   /* records.                                                          */
int ParseObjectPushServicesFromSDP(BD_ADDR_t RemoteDeviceAddress, OPPM_Parsed_Service_Info_t *OPPMServiceInfo);

#endif
