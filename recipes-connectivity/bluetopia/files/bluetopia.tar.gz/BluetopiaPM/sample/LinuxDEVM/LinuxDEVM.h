/*****< linuxdevm.h >**********************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXDEVM - Simple Linux application using Bluetopia Platform Manager     */
/*              Device Manager Application Programming (API) Interface.       */
/*                                                                            */
/*  Author:  Damon Lange                                                      */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/11/10  D. Lange       Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXDEVMH__
#define __LINUXDEVMH__

#endif

