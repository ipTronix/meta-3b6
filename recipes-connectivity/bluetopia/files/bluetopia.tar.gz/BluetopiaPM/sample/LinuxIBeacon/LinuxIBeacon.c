/*****< LinuxIBeacon.c >******************************************************/
/*      Copyright 2012 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LinuxIBeacon - Simple Linux application using Bluetopia Platform Manager  */
/*                  demonstrating IBeacon preparation and transmission        */
/*                  (using DEVM API)                                          */
/*                                                                            */
/*  Author:  Kobi L                                                         */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   07/07/12  Kobi L         Initial creation.                               */
/******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>

#include <unistd.h>           /* Include for getpid().                        */


#include "SS1BTPM.h"          /* BTPM Application Programming Interface.      */

#define MAX_SUPPORTED_COMMANDS                     (16)  /* Denotes the       */
                                                         /* maximum number of */
                                                         /* User Commands that*/
                                                         /* are supported by  */
                                                         /* this application. */

#define MAX_COMMAND_LENGTH                        (128)  /* Denotes the max   */
                                                         /* buffer size used  */
                                                         /* for user commands */
                                                         /* input via the     */
                                                         /* User Interface.   */

#define MAX_NUM_OF_PARAMETERS                       (5)  /* Denotes the max   */
                                                         /* number of         */
                                                         /* parameters a      */
                                                         /* command can have. */

#define INDENT_LENGTH                                 3  /* Denotes the number*/
                                                         /* of character      */
                                                         /* spaces to be used */
                                                         /* for indenting when*/
                                                         /* displaying SDP    */
                                                         /* Data Elements.    */

#define NO_COMMAND_ERROR                           (-1)  /* Denotes that no   */
                                                         /* command was       */
                                                         /* specified to the  */
                                                         /* parser.           */

#define INVALID_COMMAND_ERROR                      (-2)  /* Denotes that the  */
                                                         /* Command does not  */
                                                         /* exist for         */
                                                         /* processing.       */

#define EXIT_CODE                                  (-3)  /* Denotes that the  */
                                                         /* Command specified */
                                                         /* was the Exit      */
                                                         /* Command.          */

#define FUNCTION_ERROR                             (-4)  /* Denotes that an   */
                                                         /* error occurred in */
                                                         /* execution of the  */
                                                         /* Command Function. */

#define TO_MANY_PARAMS                             (-5)  /* Denotes that there*/
                                                         /* are more          */
                                                         /* parameters then   */
                                                         /* will fit in the   */
                                                         /* UserCommand.      */

#define INVALID_PARAMETERS_ERROR                   (-6)  /* Denotes that an   */
                                                         /* error occurred due*/
                                                         /* to the fact that  */
                                                         /* one or more of the*/
                                                         /* required          */
                                                         /* parameters were   */
                                                         /* invalid.          */

#define PLATFORM_MANAGER_NOT_INITIALIZED_ERROR     (-7)  /* Denotes that an   */
                                                         /* error occurred due*/
                                                         /* to the fact that  */
                                                         /* the Platform      */
                                                         /* Manager has not   */
                                                         /* been initialized. */

#define UUID_INPUT_LENGTH                           (35) /* Denotes the length*/
                                                         /* of the user input */
                                                         /* parameter for the */
                                                         /* UUID parameter.   */

#define Display(x)   	{printf x; printf("\r\n");}
#define DisplayR(x)   	{printf x; }

   /* The following type definition represents the structure which holds*/
   /* all information about the parameter, in particular the parameter  */
   /* as a string and the parameter as an unsigned int.                 */
typedef struct _tagParameter_t
{
   char         *strParam;
   unsigned int  intParam;
} Parameter_t;

   /* The following type definition represents the structure which holds*/
   /* a list of parameters that are to be associated with a command The */
   /* NumberofParameters variable holds the value of the number of      */
   /* parameters in the list.                                           */
typedef struct _tagParameterList_t
{
   int         NumberofParameters;
   Parameter_t Params[MAX_NUM_OF_PARAMETERS];
} ParameterList_t;

   /* The following type definition represents the structure which holds*/
   /* the command and parameters to be executed.                        */
typedef struct _tagUserCommand_t
{
   char            *Command;
   ParameterList_t  Parameters;
} UserCommand_t;

   /* The following type definition represents the generic function     */
   /* pointer to be used by all commands that can be executed by the    */
   /* test program.                                                     */
typedef int (*CommandFunction_t)(ParameterList_t *TempParam);

   /* The following type definition represents the structure which holds*/
   /* information used in the interpretation and execution of Commands. */
typedef struct _tagCommandTable_t
{
	char              *DisplayName;
	char              *CommandName; // Upper Case Name
    CommandFunction_t  CommandFunction;
} CommandTable_t;

   /* Internal Variables to this Module (Remember that all variables    */
   /* declared static are initialized to 0 automatically by the         */
   /* compiler as part of standard C/C++).                              */
static Boolean_t           Initialized;             /* Variable which is used to hold  */
                                                    /* the current state of the        */
                                                    /* Bluetopia Platform Manager      */
                                                    /* Initialization.                 */

static unsigned int        DEVMCallbackID;          /* Variable which holds the        */
                                                    /* Callback ID of the currently    */
                                                    /* registered Device Manager       */
                                                    /* Callback ID.                    */

static unsigned int        NumberCommands;          /* Variable which is used to hold  */
                                                    /* the number of Commands that are */
                                                    /* supported by this application.  */
                                                    /* Commands are added individually.*/

static CommandTable_t      CommandTable[MAX_SUPPORTED_COMMANDS]; /* Variable which is  */
                                                    /* used to hold the actual Commands*/
                                                    /* that are supported by this      */
                                                    /* application.                    */

static Boolean_t           ReadAsString;            /* Variable which holds if a read  */
                                                    /* should be formatted as a string.*/


   /* The following is used to map from ATT Error Codes to a printable  */
   /* string.                                                           */
static char *ErrorCodeStr[] = {
   "No Error",
   "Invalid Handle",
   "Read not permitted",
   "Write not permitted",
   "Invalid PDU",
   "Insufficient authentication",
   "Request not supported",
   "Invalid offset",
   "Insufficient authorization",
   "Prepare queue full",
   "Attribute not found",
   "Attribute not long",
   "Insufficient encryption key size",
   "Invalid attribute value length",
   "Unlikely error",
   "Insufficient encryption",
   "Unsupported group type",
   "Insufficient resources",
};

#define NUMBER_OF_ERROR_CODES     (sizeof(ErrorCodeStr)/sizeof(char *))

   /* Internal function prototypes.                                     */
static void UserInterface(void);
static int ReadLine(char *Buffer, unsigned int BufferSize);
static unsigned int StringToUnsignedInteger(char *StringInteger);
static char *StringParser(char *String);
static int CommandParser(UserCommand_t *TempCommand, char *UserInput);
static int CommandInterpreter(UserCommand_t *TempCommand);
static int AddCommand(char *CommandName, CommandFunction_t CommandFunction);
static CommandFunction_t FindCommand(char *Command);
static void ClearCommands(void);

static void BD_ADDRToStr(BD_ADDR_t Board_Address, char *BoardStr);

static int DisplayHelp(ParameterList_t *TempParam);

static int Initialize();
static int EnableBluetoothDebug(ParameterList_t *TempParam);
static int Cleanup();
static int SetDevicePower(ParameterList_t *TempParam);
static int QueryDevicePower(ParameterList_t *TempParam);
static int QueryLocalDeviceProperties(ParameterList_t *TempParam);
static int SetLocalDeviceName(ParameterList_t *TempParam);
static int SetLocalClassOfDevice(ParameterList_t *TempParam);
static int SetIbeaconUUID(ParameterList_t *TempParam);
static int SetIbeaconMinor(ParameterList_t *TempParam);
static int SetIbeaconMajor(ParameterList_t *TempParam);
static int SetIbeaconTxPower(ParameterList_t *TempParam);
static int QueryIbeaconParams(ParameterList_t *TempParam);
static int StartAdvertising(ParameterList_t *TempParam);
static int StopAdvertising(ParameterList_t *TempParam);
static void DisplayLocalDeviceProperties(unsigned long UpdateMask, DEVM_Local_Device_Properties_t *LocalDeviceProperties);

   /* BTPM Server Un-Registration Callback function prototype.          */
void BTPSAPI ServerUnRegistrationCallback(void *CallbackParameter);

   /* BTPM Local Device Manager Callback function prototype.            */
static void BTPSAPI DEVM_Event_Callback(DEVM_Event_Data_t *EventData, void *CallbackParameter);

   /* This function is responsible for taking the input from the user   */
   /* and dispatching the appropriate Command Function.  First, this    */
   /* function retrieves a String of user input, parses the user input  */
   /* into Command and Parameters, and finally executes the Command or  */
   /* Displays an Error Message if the input is not a valid Command.    */
static void UserInterface(void)
{
   UserCommand_t TempCommand;
   int  Result = !EXIT_CODE;
   char UserInput[MAX_COMMAND_LENGTH];
   struct sigaction SignalAction;

   /* First let's make sure that we start on new line.                  */
   Display((""));


   ClearCommands();

   AddCommand("SetDevicePower", SetDevicePower);
   AddCommand("QueryDevicePower", QueryDevicePower);
   AddCommand("QueryLocalDeviceProperties", QueryLocalDeviceProperties);
   AddCommand("SetLocalDeviceName", SetLocalDeviceName);
   AddCommand("SetLocalClassOfDevice", SetLocalClassOfDevice);
   AddCommand("SetIbeaconUUID", SetIbeaconUUID);
   AddCommand("SetIbeaconMajor", SetIbeaconMajor);
   AddCommand("SetIbeaconMinor", SetIbeaconMinor);
   AddCommand("SetIbeaconTxPower", SetIbeaconTxPower);
   AddCommand("QueryIbeaconParams", QueryIbeaconParams);
   AddCommand("StartAdvertising", StartAdvertising);
   AddCommand("StopAdvertising", StopAdvertising);
   AddCommand("EnableBluetoothDebug", EnableBluetoothDebug);

   AddCommand("Help", DisplayHelp);

   /* Next display the available commands.                              */
   DisplayHelp(NULL);

   /* Configure the SIGTTIN signal so that this application can run in  */
   /* the background.                                                   */
   
   /* Initialize the signal set to empty.                               */
   sigemptyset(&SignalAction.sa_mask);
   
   /* Flag that we want to ignore this signal.                          */
   SignalAction.sa_handler = SIG_IGN;
                        
   /* Clear the restart flag so that system calls interrupted by this   */
   /* signal fail and set the error number instead of restarting.       */
   SignalAction.sa_flags = ~SA_RESTART;
   
   /* Set the SIGTTIN signal's action.  Note that the default behavior  */
   /* for SIGTTIN is to suspend the application.  We want to ignore the */
   /* signal instead so that this doesn't happen.  When the read()      */
   /* function fails the we can check the error number to determine if  */
   /* it was interrupted by a signal, and if it was then we can wait    */
   /* until we have re-entered the foreground before attempting to read */
   /* from standard input again.                                        */
   sigaction(SIGTTIN, &SignalAction, NULL);
                     
   /* This is the main loop of the program.  It gets user input from the*/
   /* command window, make a call to the command parser, and command    */
   /* interpreter.  After the function has been ran it then check the   */
   /* return value and displays an error message when appropriate. If   */
   /* the result returned is ever the EXIT_CODE the loop will exit      */
   /* leading the the exit of the program.                              */
   while(Result != EXIT_CODE)
   {
      /* Initialize the value of the variable used to store the users   */
      /* input and output "Input: " to the command window to inform the */
      /* user that another command may be entered.                      */
      UserInput[0] = '\0';

      /* Output an Input Shell-type prompt.                             */
      printf("TI-BT>");

      /* Read the next line of user input.  Note that this command will */
      /* return an error if it is interrupted by a signal, this case is */
      /* handled in the else clause below.                              */
      if(ReadLine(UserInput, sizeof(UserInput)) > 0)
      {
         /* Next, check to see if a command was input by the user.      */
         if(strlen(UserInput))
         {
            /* Start a newline for the results.                         */
            printf("\r\n");

            /* The string input by the user contains a value, now run   */
            /* the string through the Command Parser.                   */
            if(CommandParser(&TempCommand, UserInput) >= 0)
            {
               /* The Command was successfully parsed, run the Command. */
               Result = CommandInterpreter(&TempCommand);

               switch(Result)
               {
                  case INVALID_COMMAND_ERROR:
                     Display(("Invalid Command."));
                     break;
                  case FUNCTION_ERROR:
                     Display(("Function Error."));
                     break;
               }
            }
            else
               Display(("Invalid Input."));
         }
      }
      else
         Result = EXIT_CODE;
   }
}


static unsigned long HexStringToUINT(char *str, int str_len)
{
	int i, ret_val = 0;

	/* Hexadecimal Number has been specified.                      */
	for(i=0; i<str_len; i++)
	{
		/* check for valid digit, add it to the value being      */
		/* built.                                                */
		if((str[i] >= '0') && (str[i] <= '9'))
			ret_val = (ret_val *16) + (str[i] & 0xF);
		else if ((str[i] >= 'a') && (str[i] <= 'f'))
			ret_val = (ret_val *16) + (str[i] - 'a' + 10);
		else if ((str[i] >= 'A') && (str[i] <= 'F'))
			ret_val = (ret_val *16) + (str[i] - 'A' + 10);
		else
			break;
	}
	return ret_val;
}

static unsigned long DecStringToUINT(char *str, int str_len)
{
	int i, ret_val = 0;

	/* Hexadecimal Number has been specified.                      */
	for(i=0; i<str_len; i++)
	{
		/* check for valid digit, add it to the value being      */
		/* built.                                                */
		if((str[i] >= '0') && (str[i] <= '9'))
			ret_val = (ret_val *10) + (str[i] & 0xF);
		else
			break;
	}
	return ret_val;
}







   /* The following function is responsible for parsing strings into    */
   /* components.  The first parameter of this function is a pointer to */
   /* the String to be parsed.  This function will return the start of  */
   /* the string upon success and a NULL pointer on all errors.         */
static char *StringParser(char *String)
{
   int   Index;
   char *ret_val = NULL;

   /* Before proceeding make a0798996sure that the string passed in appears to  */
   /* be at least semi-valid.                                           */
   if((String) && (strlen(String)))
   {
      /* The string appears to be at least semi-valid.  Search for the  */
      /* first space character and replace it with a NULL terminating   */
      /* character.                                                     */
      for(Index=0,ret_val=String;Index < strlen(String);Index++)
      {
         /* Is this the space character.                                */
         if((String[Index] == ' ') || (String[Index] == '\r') || (String[Index] == '\n'))
         {
            /* This is the space character, replace it with a NULL      */
            /* terminating character and set the return value to the    */
            /* begining character of the string.                        */
            String[Index] = '\0';
            break;
         }
      }
   }

   return(ret_val);
}

   /* The following function reads a line from standard input into the  */
   /* specified buffer.  This function returns the string length of the */
   /* line, including the null character, on success and a negative     */
   /* value if an error occurred.                                       */
static int ReadLine(char *Buffer, unsigned int BufferSize)
{
   int       ret_val;
   Boolean_t Done;
   
   Buffer[0] = '\0';
   Done      = FALSE;
   
   while(!Done)
   {
      /* Flush the output buffer before reading from standard in so that*/
      /* we don't get out of order input and output in the console.     */
      fflush(stdout);
      
      /* Read a line from standard input.                               */
      ret_val = read(STDIN_FILENO, Buffer, BufferSize);
      
      /* Check if the read succeeded.                                   */
      if(ret_val > 0)
      {
         /* The read succeeded, replace the new line character with a   */
         /* null character to delimit the string.                       */
         Buffer[ret_val - 1] = '\0';
         Buffer[ret_val] = '\0';
         /* Stop the loop.                                              */
         Done = TRUE;
      }
      else
      {
         /* The read failed, check the error number to determine if we  */
         /* were interrupted by a signal.  Note that the error number is*/
         /* EIO in the case that we are interrupted by a signal because */
         /* we are blocking SIGTTIN. If we were not blocking SIGTTIN and*/
         /* handling it instead then error number would be EINTR.       */
         if(errno == EIO)
         {               
            /* The call was interrupted by a signal which indicates that*/
            /* the app was either suspended or placed into the          */
            /* background, spin until the app has re-entered the        */
            /* foreground.                                              */
            while(getpgrp() != tcgetpgrp(STDOUT_FILENO))
            {
               BTPS_Delay(500);
            }
         }
         else
         {
            /* An unexpected error occurred, stop the loop.             */
            Done = TRUE;

            /* Display the error to the user.                           */
            perror("Error: Unexpected return from read()");
         }
      }
   }
   
   return(ret_val);
}

/* The following function is responsible for converting number       */
/* strings to there unsigned integer equivalent.  This function can  */
/* handle leading and tailing white space, however it does not handle*/
/* signed or comma delimited values.  This function takes as its     */
/* input the string which is to be converted.  The function returns  */
/* zero if an error occurs otherwise it returns the value parsed from*/
/* the string passed as the input parameter.                         */
static unsigned int StringToUnsignedInteger(char *StringInteger)
{
	int          IsHex;
	unsigned int Index;
	unsigned int ret_val = 0;

	/* Before proceeding make sure that the parameter that was passed as */
	/* an input appears to be at least semi-valid.                       */
	if((StringInteger) && (strlen(StringInteger)))
	{
		/* Initialize the variable.                                       */
		Index = 0;

		/* Next check to see if this is a hexadecimal number.             */
		if(strlen(StringInteger) > 2)
		{
			if((StringInteger[0] == '0') && ((StringInteger[1] == 'x') || (StringInteger[1] == 'X')))
			{
				IsHex = 1;

				/* Increment the String passed the Hexadecimal prefix.      */
				StringInteger += 2;
			}
			else
				IsHex = 0;
		}
		else
			IsHex = 0;

		/* Process the value differently depending on whether or not a    */
		/* Hexadecimal Number has been specified.                         */
		if(!IsHex)
		{
			ret_val = DecStringToUINT(StringInteger, strlen(StringInteger));
		}
		else
		{
			ret_val = HexStringToUINT(StringInteger, strlen(StringInteger));
		}
	}

	return(ret_val);
}


   /* This function is responsable for taking command strings and       */
   /* parsing them into a command, param1, and param2.  After parsing   */
   /* this string the data is stored into a UserCommand_t structure to  */
   /* be used by the interpreter.  The first parameter of this function */
   /* is the structure used to pass the parsed command string out of the*/
   /* function.  The second parameter of this function is the string    */
   /* that is parsed into the UserCommand structure.  Successful        */
   /* execution of this function is denoted by a retrun value of zero.  */
   /* Negative return values denote an error in the parsing of the      */
   /* string parameter.                                                 */
static int CommandParser(UserCommand_t *TempCommand, char *UserInput)
{
   int            ret_val;
   int            StringLength;
   char          *LastParameter;
   unsigned int   Count         = 0;

   /* Before proceeding make sure that the passed parameters appear to  */
   /* be at least semi-valid.                                           */
   if((TempCommand) && (UserInput) && (strlen(UserInput)))
   {
      /* Retrieve the first token in the string, this should be the     */
      /* commmand.                                                      */
      TempCommand->Command = StringParser(UserInput);

      /* Flag that there are NO Parameters for this Command Parse.      */
      TempCommand->Parameters.NumberofParameters = 0;

      /* Check to see if there is a Command.                            */
      if(TempCommand->Command)
      {
         /* Initialize the return value to zero to indicate success on  */
         /* commands with no parameters.                                */
         ret_val = 0;

         /* Adjust the UserInput pointer and StringLength to remove     */
         /* the Command from the data passed in before parsing the      */
         /* parameters.                                                 */
         UserInput    += strlen(TempCommand->Command)+1;
         StringLength  = strlen(UserInput);

         /* There was an available command, now parse out the parameters*/
         while((StringLength > 0) && ((LastParameter = StringParser(UserInput)) != NULL))
         {
            /* There is an available parameter, now check to see if     */
            /* there is room in the UserCommand to store the parameter  */
            if(Count < (sizeof(TempCommand->Parameters.Params)/sizeof(Parameter_t)))
            {
               /* Save the parameter as a string.                       */
               TempCommand->Parameters.Params[Count].strParam = LastParameter;

               /* Save the parameter as an unsigned int intParam will   */
               /* have a value of zero if an error has occurred.        */
               TempCommand->Parameters.Params[Count].intParam = StringToUnsignedInteger(LastParameter);

               Count++;
               UserInput    += strlen(LastParameter)+1;
               StringLength -= strlen(LastParameter)+1;

               ret_val = 0;
            }
            else
            {
               /* Be sure we exit out of the Loop.                      */
               StringLength = 0;

               ret_val      = TO_MANY_PARAMS;
            }
         }

         /* Set the number of parameters in the User Command to the     */
         /* number of found parameters                                  */
         TempCommand->Parameters.NumberofParameters = Count;
      }
      else
      {
         /* No command was specified                                    */
         ret_val = NO_COMMAND_ERROR;
      }
   }
   else
   {
      /* One or more of the passed parameters appear to be invalid.     */
      ret_val = INVALID_PARAMETERS_ERROR;
   }

   return(ret_val);
}

   /* This function is responsible for determining the command in which */
   /* the user entered and running the appropriate function associated  */
   /* with that command.  The first parameter of this function is a     */
   /* structure containing information about the commmand to be issued. */
   /* This information includes the command name and multiple parameters*/
   /* which maybe be passed to the function to be executed.  Successful */
   /* execution of this function is denoted by a return value of zero.  */
   /* A negative return value implies that that command was not found   */
   /* and is invalid.                                                   */
static int CommandInterpreter(UserCommand_t *TempCommand)
{
   int               i;
   int               ret_val;
   CommandFunction_t CommandFunction;

   /* If the command is not found in the table return with an invaild   */
   /* command error                                                     */
   ret_val = INVALID_COMMAND_ERROR;

   /* Let's make sure that the data passed to us appears semi-valid.    */
   if((TempCommand) && (TempCommand->Command))
   {
      /* Now, let's make the Command string all upper case so that we   */
      /* compare against it.                                            */
      for(i=0;i<strlen(TempCommand->Command);i++)
      {
         if((TempCommand->Command[i] >= 'a') && (TempCommand->Command[i] <= 'z'))
            TempCommand->Command[i] -= ('a' - 'A');
      }

      /* Check to see if the command which was entered was exit.        */
      if(memcmp(TempCommand->Command, "QUIT", strlen("QUIT")) != 0)
      {
         /* The command entered is not exit so search for command in    */
         /* table.                                                      */
         if((CommandFunction = FindCommand(TempCommand->Command)) != NULL)
         {
            /* The command was found in the table so call the command.  */
            if(!((*CommandFunction)(&TempCommand->Parameters)))
            {
               /* Return success to the caller.                         */
               ret_val = 0;
            }
            else
               ret_val = FUNCTION_ERROR;
         }
      }
      else
      {
         /* The command entered is exit, set return value to EXIT_CODE  */
         /* and return.                                                 */
         ret_val = EXIT_CODE;
      }
   }
   else
      ret_val = INVALID_PARAMETERS_ERROR;

   return(ret_val);
}

   /* The following function is provided to allow a means to            */
   /* programatically add Commands the Global (to this module) Command  */
   /* Table.  The Command Table is simply a mapping of Command Name     */
   /* (NULL terminated ASCII string) to a command function.  This       */
   /* function returns zero if successful, or a non-zero value if the   */
   /* command could not be added to the list.                           */
static int AddCommand(char *CommandName, CommandFunction_t CommandFunction)
{
   int ret_val = 1;

   /* First, make sure that the parameters passed to us appear to be    */
   /* semi-valid.                                                       */
   if((CommandName) && (CommandFunction))
   {
      /* Next, make sure that we still have room in the Command Table   */
      /* to add commands.                                               */
      if(NumberCommands < MAX_SUPPORTED_COMMANDS)
      {
    	  int i;
         /* Simply add the command data to the command table and        */
         /* increment the number of supported commands.                 */
          CommandTable[NumberCommands].CommandName       = (char *)malloc(strlen(CommandName));
          if(CommandTable[NumberCommands].CommandName)
          {
			  for(i=0;i<strlen(CommandName);i++)
			  {
				 if((CommandName[i] >= 'a') && (CommandName[i] <= 'z'))
					 CommandTable[NumberCommands].CommandName[i] = CommandName[i] - ('a' - 'A');
				 else
					 CommandTable[NumberCommands].CommandName[i] = CommandName[i];
			  }

			  CommandTable[NumberCommands].DisplayName       = CommandName;
			  CommandTable[NumberCommands++].CommandFunction = CommandFunction;
		      ret_val                                        = 0;
		  }
          /* Return success to the caller.                               */
      }
   }
   return(ret_val);
}

   /* The following function searches the Command Table for the         */
   /* specified Command.  If the Command is found, this function returns*/
   /* a NON-NULL Command Function Pointer.  If the command is not found */
   /* this function returns NULL.                                       */
static CommandFunction_t FindCommand(char *Command)
{
   unsigned int      Index;
   CommandFunction_t ret_val;

   /* First, make sure that the command specified is semi-valid.        */
   if(Command)
   {
      /* Special shortcut: If it's simply a one or two digit number,    */
      /* convert the command directly based on the Command Index.       */
      if((strlen(Command) == 1) && (Command[0] >= '1') && (Command[0] <= '9'))
      {
         Index = atoi(Command);

         if(Index < NumberCommands)
            ret_val = CommandTable[Index - 1].CommandFunction;
         else
            ret_val = NULL;
      }
      else
      {
         if((strlen(Command) == 2) && (Command[0] >= '0') && (Command[0] <= '9') && (Command[1] >= '0') && (Command[1] <= '9'))
         {
            Index = atoi(Command);

            if(Index < NumberCommands)
               ret_val = CommandTable[Index?(Index-1):Index].CommandFunction;
            else
               ret_val = NULL;
         }
         else
         {
            /* Now loop through each element in the table to see if     */
            /* there is a match.                                        */
            for(Index=0,ret_val=NULL;((Index<NumberCommands) && (!ret_val));Index++)
            {
               if((strlen(Command) == strlen(CommandTable[Index].CommandName)) && (memcmp(Command, CommandTable[Index].CommandName, strlen(CommandTable[Index].CommandName)) == 0))
                  ret_val = CommandTable[Index].CommandFunction;
            }
         }
      }
   }
   else
      ret_val = NULL;

   return(ret_val);
}

   /* The following function is provided to allow a means to clear out  */
   /* all available commands from the command table.                    */
static void ClearCommands(void)
{
   /* Simply flag that there are no commands present in the table.      */
   NumberCommands = 0;
}

   /* The following function is responsible for converting data of type */
   /* BD_ADDR to a string.  The first parameter of this function is the */
   /* BD_ADDR to be converted to a string.  The second parameter of this*/
   /* function is a pointer to the string in which the converted BD_ADDR*/
   /* is to be stored.                                                  */
static void BD_ADDRToStr(BD_ADDR_t Board_Address, char *BoardStr)
{
   sprintf(BoardStr, "%02X%02X%02X%02X%02X%02X", Board_Address.BD_ADDR5,
                                                 Board_Address.BD_ADDR4,
                                                 Board_Address.BD_ADDR3,
                                                 Board_Address.BD_ADDR2,
                                                 Board_Address.BD_ADDR1,
                                                 Board_Address.BD_ADDR0);
}

   /* The following function is responsible for the specified string    */
   /* into data of type BD_ADDR.  The first parameter of this function  */
   /* is the BD_ADDR string to be converted to a BD_ADDR.  The second   */
   /* parameter of this function is a pointer to the BD_ADDR in which   */
   /* the converted BD_ADDR String is to be stored.                     */
static void StrToBD_ADDR(char *BoardStr, BD_ADDR_t *Board_Address)
{
   unsigned int Address[sizeof(BD_ADDR_t)];

   if((BoardStr) && (strlen(BoardStr) == sizeof(BD_ADDR_t)*2) && (Board_Address))
   {
      sscanf(BoardStr, "%02X%02X%02X%02X%02X%02X", &(Address[5]), &(Address[4]), &(Address[3]), &(Address[2]), &(Address[1]), &(Address[0]));

      Board_Address->BD_ADDR5 = (Byte_t)Address[5];
      Board_Address->BD_ADDR4 = (Byte_t)Address[4];
      Board_Address->BD_ADDR3 = (Byte_t)Address[3];
      Board_Address->BD_ADDR2 = (Byte_t)Address[2];
      Board_Address->BD_ADDR1 = (Byte_t)Address[1];
      Board_Address->BD_ADDR0 = (Byte_t)Address[0];
   }
   else
   {
      if(Board_Address)
         BTPS_MemInitialize(Board_Address, 0, sizeof(BD_ADDR_t));
   }
}




   /* The following function is responsible for displaying the current  */
   /* Command Options for this Device Manager Sample Application.  The  */
   /* input parameter to this function is completely ignored, and only  */
   /* needs to be passed in because all Commands that can be entered at */
   /* the Prompt pass in the parsed information.  This function displays*/
   /* the current Command Options that are available and always returns */
   /* zero.                                                             */
static int DisplayHelp(ParameterList_t *TempParam)
{
	int i;
   /* Note the order they are listed here *MUST* match the order in     */
   /* which then are added to the Command Table.                        */

   Display(("******************************************************************"));
   Display(("* Command Options: "));
   for(i=0; i<NumberCommands-1; i++)
	   Display(("    %2d) %s", i+1, CommandTable[i].DisplayName));
   Display(("*    Help, Quit. "));
   Display(("******************************************************************"));

   return(0);
}

	/* The following function is responsible for Initializing the        */
	/* Bluetopia Platform Manager Framework.  This function returns      */
	/* zero if successful and a negative value if an error occurred.     */
static int Initialize()
{
	int Result;
	int ret_val;

	/* First, check to make sure that we are not already initialized.    */
	if(!Initialized)
	{
		/* Determine if the user would like to Register an Event Callback */
		/* with the calling of this command.                              */


		/* Now actually initialize the Platform Manager Service.       */
		Result = BTPM_Initialize((unsigned long)getpid(), NULL, ServerUnRegistrationCallback, NULL);

		if(!Result)
		{
			/* Initialization successful, go ahead and inform the user  */
			/* that it was successful and flag that the Platform Manager*/
			/* has been initialized.                                    */
			Display(("BTPM_Initialize() Success: %d.", Result));

			/* If the caller would like to Register an Event Callback   */
			/* then we will do that at this time.                       */
			if((Result = DEVM_RegisterEventCallback(DEVM_Event_Callback, NULL)) > 0)
			{
				Display(("DEVM_RegisterEventCallback() Success: %d.", Result));

				/* Note the Callback ID and flag success.             */
				DEVMCallbackID = (unsigned int)Result;

				Initialized    = TRUE;

				ret_val        = 0;
			}
			else
			{
				/* Error registering the Callback, inform user and    */
				/* flag an error.                                     */
				Display(("DEVM_RegisterEventCallback() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

				ret_val = FUNCTION_ERROR;

				/* Since there was an error, go ahead and clean up the*/
				/* library.                                           */
				BTPM_Cleanup();
			}
		}
		else
		{
			/* Error initializing Platform Manager, inform the user.    */
			Display(("BTPM_Initialize() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

			ret_val = FUNCTION_ERROR;
		}
	}
	else
	{
		/* Already initialized, flag an error.                            */
		Display(("Initialization Failure: Already initialized."));

		ret_val = FUNCTION_ERROR;
	}

	return(ret_val);
}

   /* The following function is responsible for Cleaning up/Shutting    */
   /* down the Bluetopia Platform Manager Framework.  This function     */
   /* returns zero if successful and a negative value if an error       */
   /* occurred.                                                         */
static int Cleanup()
{
   int ret_val;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      /* If there was an Event Callback Registered, then we need to     */
      /* un-register it.                                                */
      if(DEVMCallbackID)
         DEVM_UnRegisterEventCallback(DEVMCallbackID);


      /* Nothing to do other than to clean up the Bluetopia Platform    */
      /* Manager Service and flag that it is no longer initialized.     */
      BTPM_Cleanup();

      Initialized    = FALSE;
      DEVMCallbackID = 0;

      ret_val        = 0;
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}


   /* The following function is responsible for Setting the Device Power*/
   /* of the Local Device.  This function returns zero if successful and*/
   /* a negative value if an error occurred.                            */
static int SetDevicePower(ParameterList_t *TempParam)
{
   int Result;
   int ret_val;

   /* First, check to make sure that we are not already initialized.    */
   if(Initialized)
   {
      /* Determine if the user would like to Power On or Off the Local  */
      /* Device with the calling of this command.                       */
      if((TempParam) && (TempParam->NumberofParameters >= 1))
      {
         /* Now actually Perform the command.                           */
         if(TempParam->Params[0].intParam)
            Result = DEVM_PowerOnDevice();
         else
            Result = DEVM_PowerOffDevice();

         if(!Result)
         {
            /* Device Power request was successful, go ahead and inform */
            /* the User.                                                */
            Display(("DEVM_Power%sDevice() Success: %d.", TempParam->Params[0].intParam?"On":"Off", Result));

            /* Return success to the caller.                            */
            ret_val = 0;
         }
         else
         {
            /* Error Powering On/Off the device, inform the user.       */
            Display(("DEVM_Power%sDevice() Failure: %d, %s.", TempParam->Params[0].intParam?"On":"Off", Result, ERR_ConvertErrorCodeToString(Result)));

            ret_val = FUNCTION_ERROR;
         }
      }
      else
      {
         Display(("Usage: SetDevicePower [0/1 - Power Off/Power On]."));

         /* One or more of the necessary parameters is/are invalid.     */
         ret_val = INVALID_PARAMETERS_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = FUNCTION_ERROR;
   }

   return(ret_val);
}

   /* The following function is responsible for enabling/disabling      */
   /* Bluetooth Debugging.  This function returns zero if successful and*/
   /* a negative value if an error occurred.                            */
static int EnableBluetoothDebug(ParameterList_t *TempParam)
{
   int            Result;
   int            ret_val;
   unsigned long  Flags;
   unsigned int   Type;
   unsigned int   ParameterDataLength;
   unsigned char *ParameterData;

   /* First, check to make sure that we are not already initialized.    */
   if(Initialized)
   {
      /* Make sure the input parameters have been specified.            */
      if((TempParam) && (TempParam->NumberofParameters >= 1))
      {
         /* Initialize no parameters.                                   */
         ret_val             = 0;

         Flags               = 0;
         ParameterDataLength = 0;
         ParameterData       = NULL;

         /* Check to see if a Disable operation is being requested.     */
         if(!TempParam->Params[0].intParam)
         {
            /* Disable - No other parameters are required.              */
            Flags = 0;
            Type  = 0;
         }
         else
         {
            /* Enable - Make sure we have the Type specified.           */
            if(TempParam->NumberofParameters >= 2)
            {
               /* Note the Debug Type.                                  */
               Type = (unsigned int)TempParam->Params[1].intParam;

               /* Check for optional flags.                             */
               if(TempParam->NumberofParameters >= 3)
                  Flags = (unsigned int)TempParam->Params[2].intParam;
               else
                  Flags = 0;

               /* Determine if there are any Parameters specified.      */
               if((TempParam->NumberofParameters >= 4) && (TempParam->Params[3].strParam))
               {
                  ParameterDataLength = BTPS_StringLength(TempParam->Params[3].strParam) + 1;
                  ParameterData       = (unsigned char *)TempParam->Params[3].strParam;
               }
            }
            else
            {
               printf("Usage: EnableBluetoothDebug [Enable (0/1)] [Type (1 - ASCII File, 2 - Terminal, 3 - FTS File)] [Debug Flags] [Debug Parameter String (no spaces)].\r\n");

               /* One or more of the necessary parameters is/are        */
               /* invalid.                                              */
               ret_val = INVALID_PARAMETERS_ERROR;
            }
         }

         if(!ret_val)
         {
            /* Now actually Perform the command.                        */
            Result = DEVM_EnableBluetoothDebug((Boolean_t)(TempParam->Params[0].intParam), Type, Flags, ParameterDataLength, ParameterData);

            if(!Result)
            {
               /* Enable Bluetooth Debugging request was successful, go */
               /* ahead and inform the User.                            */
               printf("DEVM_EnableBluetoothDebug(%s) Success.\r\n", TempParam->Params[0].intParam?"TRUE":"FALSE");

               /* Return success to the caller.                         */
               ret_val = 0;
            }
            else
            {
               /* Error Enabling Bluetooth Debugging, inform the user.  */
               printf("DEVM_EnableBluetoothDebug(%s) Failure: %d, %s.\r\n", TempParam->Params[0].intParam?"TRUE":"FALSE", Result, ERR_ConvertErrorCodeToString(Result));

               ret_val = FUNCTION_ERROR;
            }
         }
      }
      else
      {
         printf("Usage: EnableBluetoothDebug [Enable (0/1)] [Type (1 - ASCII File, 2 - Terminal, 3 - FTS File)] [Debug Flags] [Debug Parameter String (no spaces)].\r\n");

         /* One or more of the necessary parameters is/are invalid.     */
         ret_val = INVALID_PARAMETERS_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      printf("Platform Manager has not been initialized.\r\n");

      ret_val = FUNCTION_ERROR;
   }

   return(ret_val);
}


   /* The following function is responsible for querying the current    */
   /* device power for the local device.  This function returns zero if */
   /* successful and a negative value if an error occurred.             */
static int QueryDevicePower(ParameterList_t *TempParam)
{
   int       ret_val;
   Boolean_t Result;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      /* Framework has been initialized, go ahead and query the current */
      /* Power state.                                                   */
      Result = DEVM_QueryDevicePowerState();

      if(Result >= 0)
      {
    	  if(Result)
    	  {
    		  Display(("DEVM_QueryDevicePowerState() Success: ON."));
    	  }
    	  else
    	  {
    		  Display(("DEVM_QueryDevicePowerState() Success: OFF."));
    	  }
      }
      else
         Display(("DEVM_QueryDevicePowerState() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

      /* Flag success to the caller.                                    */
      ret_val = 0;
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}



   /* The following function is responsible for displaying the current  */
   /* local device properties of the server.  This function returns zero*/
   /* if successful and a negative value if an error occurred.          */
static int QueryLocalDeviceProperties(ParameterList_t *TempParam)
{
   int                            Result;
   int                            ret_val;
   DEVM_Local_Device_Properties_t LocalDeviceProperties;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      /* Initialized, go ahead and query the Local Device Properties.   */
      if((Result = DEVM_QueryLocalDeviceProperties(&LocalDeviceProperties)) >= 0)
      {
         Display(("DEVM_QueryLocalDeviceProperties() Success: %d.", Result));

         /* Next, go ahead and display the properties.                  */
         DisplayLocalDeviceProperties(0, &LocalDeviceProperties);

         /* Flag success.                                               */
         ret_val = 0;
      }
      else
      {
         /* Error querying the Local Device Properties, inform the user */
         /* and flag an error.                                          */
         Display(("DEVM_QueryLocalDeviceProperties() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

         ret_val = FUNCTION_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}

   /* The following function is responsible for setting the Local Name  */
   /* Device Property of the local device.  This function returns zero  */
   /* if successful and a negative value if an error occurred.          */
static int SetLocalDeviceName(ParameterList_t *TempParam)
{
   int                            Result;
   int                            ret_val;
   DEVM_Local_Device_Properties_t LocalDeviceProperties;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      BTPS_MemInitialize(&LocalDeviceProperties, 0, sizeof(LocalDeviceProperties));

      if((TempParam) && (TempParam->NumberofParameters))
      {
         LocalDeviceProperties.DeviceNameLength = strlen(TempParam->Params[0].strParam);
         strcpy(LocalDeviceProperties.DeviceName, TempParam->Params[0].strParam);
      }

      Display(("Attempting to set Device Name to: \"%s\".", LocalDeviceProperties.DeviceName));

      if((Result = DEVM_UpdateLocalDeviceProperties(DEVM_UPDATE_LOCAL_DEVICE_PROPERTIES_DEVICE_NAME, &LocalDeviceProperties)) >= 0)
      {
         Display(("DEVM_UpdateLocalDeviceProperties() Success: %d.", Result));

         /* Flag success.                                               */
         ret_val = 0;
      }
      else
      {
         /* Error updating the Local Device Properties, inform the user */
         /* and flag an error.                                          */
         Display(("DEVM_UpdateLocalDeviceProperties() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

         ret_val = FUNCTION_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}

   /* The following function is responsible for setting the Local Name  */
   /* Device Property of the local device.  This function returns zero  */
   /* if successful and a negative value if an error occurred.          */
static int SetLocalDeviceAppearance(ParameterList_t *TempParam)
{
   int                            Result;
   int                            ret_val;
   DEVM_Local_Device_Properties_t LocalDeviceProperties;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      BTPS_MemInitialize(&LocalDeviceProperties, 0, sizeof(LocalDeviceProperties));

      if((TempParam) && (TempParam->NumberofParameters))
         LocalDeviceProperties.DeviceAppearance = (Word_t)TempParam->Params[0].intParam;

      Display(("Attempting to set Device Appearance to: %u.", (unsigned int)LocalDeviceProperties.DeviceAppearance));

      if((Result = DEVM_UpdateLocalDeviceProperties(DEVM_UPDATE_LOCAL_DEVICE_PROPERTIES_DEVICE_APPEARANCE, &LocalDeviceProperties)) >= 0)
      {
         Display(("DEVM_UpdateLocalDeviceProperties() Success: %d.", Result));

         /* Flag success.                                               */
         ret_val = 0;
      }
      else
      {
         /* Error updating the Local Device Properties, inform the user */
         /* and flag an error.                                          */
         Display(("DEVM_UpdateLocalDeviceProperties() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

         ret_val = FUNCTION_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}

   /* The following function is responsible for setting the Local Class */
   /* of Device Device Property of the local device.  This function     */
   /* returns zero if successful and a negative value if an error       */
   /* occurred.                                                         */
static int SetLocalClassOfDevice(ParameterList_t *TempParam)
{
   int                            Result;
   int                            ret_val;
   DEVM_Local_Device_Properties_t LocalDeviceProperties;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      BTPS_MemInitialize(&LocalDeviceProperties, 0, sizeof(LocalDeviceProperties));

      /* Make sure that all of the parameters required for this function*/
      /* appear to be at least semi-valid.                              */
      if((TempParam) && (TempParam->NumberofParameters))
      {
         ASSIGN_CLASS_OF_DEVICE(LocalDeviceProperties.ClassOfDevice, (Byte_t)((TempParam->Params[0].intParam) & 0xFF), (Byte_t)(((TempParam->Params[0].intParam) >> 8) & 0xFF), (Byte_t)(((TempParam->Params[0].intParam) >> 16) & 0xFF));

         Display(("Attempting to set Class Of Device to: 0x%02X%02X%02X.", LocalDeviceProperties.ClassOfDevice.Class_of_Device0, LocalDeviceProperties.ClassOfDevice.Class_of_Device1, LocalDeviceProperties.ClassOfDevice.Class_of_Device2));

         if((Result = DEVM_UpdateLocalDeviceProperties(DEVM_UPDATE_LOCAL_DEVICE_PROPERTIES_CLASS_OF_DEVICE, &LocalDeviceProperties)) >= 0)
         {
            Display(("DEVM_UpdateLocalDeviceProperties() Success: %d.", Result));

            /* Flag success.                                            */
            ret_val = 0;
         }
         else
         {
            /* Error updating the Local Device Properties, inform the   */
            /* user and flag an error.                                  */
            Display(("DEVM_UpdateLocalDeviceProperties() Failure: %d, %s.", Result, ERR_ConvertErrorCodeToString(Result)));

            ret_val = FUNCTION_ERROR;
         }
      }
      else
      {
         /* One or more of the necessary parameters is/are invalid.     */
         Display(("Usage: SetLocalClassOfDevice [Class of Device]."));

         ret_val = INVALID_PARAMETERS_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}


static Byte_t iBeacon_Prefix[] = {0x02,0x01,0x1a,0x1a,0xff,0x4c,0x00,0x02,0x15};
#define IBEACON_PREFIX_LEN   (sizeof(iBeacon_Prefix)/sizeof(char))

static Byte_t iBeacon_UUID[] = {0xe2,0xc5,0x6d,0xb5,0xdf,0xfb,0x48,0xd2,0xb0,0x60,0xd0,0xf5,0xa7,0x10,0x96,0xe0};
#define IBEACON_UUID_LEN   (sizeof(iBeacon_UUID)/sizeof(char))

static unsigned short iBeacon_Major = 1;
#define IBEACON_MAJOR_LEN   (sizeof(iBeacon_Major)/sizeof(char))

static unsigned short iBeacon_Minor = 1;
#define IBEACON_MINOR_LEN   (sizeof(iBeacon_Minor)/sizeof(char))

static signed char iBeacon_Tx_Power = 0xc5;


#define IBEACON_ADRETISE_DATA_SIZE_LEN          (0x1e)

/* The following function is a utility function that is used to      */
/* format the advertising data for this application in the           */
/* advertising data.                                                 */
static void FormatAdvertisingData(DEVM_Advertising_Information_t *AdvertisingInformation, Byte_t *AdvertisingBuffer)
{
	Byte_t Length;
	int writeIndex = 0, i;


	/* Verify that the input parameters are semi-valid.                  */
	if((AdvertisingInformation) && (AdvertisingBuffer))
	{
		AdvertisingBuffer[writeIndex++] = IBEACON_ADRETISE_DATA_SIZE_LEN;
		AdvertisingBuffer[writeIndex++] = HCI_LE_ADVERTISING_REPORT_DATA_TYPE_RAW_IBEACON;

		/*Set the IBEACON prefix to the Advertising Data */
		for(i=0; i < IBEACON_PREFIX_LEN; i++)
		{
			AdvertisingBuffer[writeIndex++] = iBeacon_Prefix[i] ;
		}

		/* Set the IBEACON UUID to the Advertising Data */
		for(i = 0; i < IBEACON_UUID_LEN; i++)
		{
			AdvertisingBuffer[writeIndex++] = iBeacon_UUID[i] ;
		}

        /*Set the iBEACON Major (Big Endian) */
		AdvertisingBuffer[writeIndex++] = (iBeacon_Major >> 8)&0xff ;
		AdvertisingBuffer[writeIndex++] = (iBeacon_Major     )&0xff ;

        /*Set the iBEACON Minor (Big Endian) */
		AdvertisingBuffer[writeIndex++] = (iBeacon_Minor >> 8)&0xff ;
		AdvertisingBuffer[writeIndex++] = (iBeacon_Minor     )&0xff ;

        /*Set the iBEACON TX Power */
		AdvertisingBuffer[writeIndex++] = iBeacon_Tx_Power;

		/* Format the structure.                                          */
		AdvertisingInformation->AdvertisingDataLength = writeIndex;
		AdvertisingInformation->AdvertisingData       = AdvertisingBuffer;

	}
}

static void DisplayAdvertisingData()
{
	Byte_t Length;
	int writeIndex = 0, i;

	Display(("IbeaconParams::"));

	DisplayR(("  UUID:: "));
	for(i = 0; i < IBEACON_UUID_LEN; i++)
	{
		DisplayR(("%02X", iBeacon_UUID[i]));
		if(i==3 || i==5 || i==7 || i==9)
		{
			DisplayR(("-"));
		}
	}
	Display((""));

	Display(("  Major:: %d", iBeacon_Major));
	Display(("  Minor:: %d", iBeacon_Major));
	Display(("  TX Power:: %d", iBeacon_Tx_Power));
}


static int SetIbeaconUUID(ParameterList_t *TempParam)
{
   int           ret_val     = 0;
   int           index       = 0;
   char         *temp_ptr    = NULL;


    /* First, check that valid Bluetooth Stack ID exists.           */
    if(Initialized)
    {
        /* Next, let's make sure that the user has specified a      */
        /* Remote Bluetooth Device to open.                         */
        if((TempParam) && (BTPS_StringLength(TempParam->Params[0].strParam)) == UUID_INPUT_LENGTH)
        {
            /* Holds the location of the input string               */
            temp_ptr = TempParam->Params[0].strParam;
            /* This loops translates the string into Hex numbers    */
            while (index<16)
            {
                while (*temp_ptr == '-')
                	temp_ptr ++;

                /* Translate the Hex string into Hex integet    */
                iBeacon_UUID[index] = HexStringToUINT(temp_ptr,2);
                index++;
                temp_ptr += 2;
            }
            Display(("SetIbeaconUUID (Success): %02x %02x ... %02x %02x", iBeacon_UUID[0], iBeacon_UUID[1], iBeacon_UUID[14], iBeacon_UUID[15]));
            Display(("In order to enable this changes, call StopAdvertise and then" ));
            Display(("StartAdvertise."));
        }
        else
        {
        	Display(("SetIbeaconUUID (Error): Invalid UUID format"));
            Display(("Usage: Example SetIbeaconUUID: E2C56DB5-DFFB-4848-D2B060D0F5A71096"));
            ret_val = INVALID_PARAMETERS_ERROR;
        }
    }
    else
    {
        /* No valid Bluetooth Stack ID exists.                      */
        ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
    }

   return(ret_val);
}

static int SetIbeaconMajor(ParameterList_t *TempParam)
{
   int           ret_val     = 0;
   int           index       = 0;
   char         *temp_ptr    = NULL;


    /* First, check that valid Bluetooth Stack ID exists.           */
    if(Initialized)
    {
        /* Next, let's make sure that the user has specified a      */
        /* Remote Bluetooth Device to open.                         */
        if((TempParam) && (TempParam->NumberofParameters == 1))
        {
            iBeacon_Major = TempParam->Params[0].intParam;
            Display(("SetIbeaconMajor (Success): %d", iBeacon_Major));
            Display(("In order to enable this changes, call StopAdvertise and then" ));
            Display(("StartAdvertise."));
        }
        else
        {
        	Display(("SetIbeaconMajor (Error): Invalid Parameter"));
            Display(("Usage: Example SetIbeaconMajor: 1000"));
            ret_val = INVALID_PARAMETERS_ERROR;
        }
    }
    else
    {
        /* No valid Bluetooth Stack ID exists.                      */
        ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
    }

   return(ret_val);
}

static int SetIbeaconMinor(ParameterList_t *TempParam)
{
   int           ret_val     = 0;
   int           index       = 0;
   char         *temp_ptr    = NULL;


    /* First, check that valid Bluetooth Stack ID exists.           */
    if(Initialized)
    {
        /* Next, let's make sure that the user has specified a      */
        /* Remote Bluetooth Device to open.                         */
        if((TempParam) && (TempParam->NumberofParameters == 1))
        {
            iBeacon_Minor = TempParam->Params[0].intParam;
            Display(("SetIbeaconMinor (Success): %d", iBeacon_Minor));
            Display(("In order to enable this changes, call StopAdvertise and then" ));
            Display(("StartAdvertise."));
         }
        else
        {
        	Display(("SetIbeaconMinor (Error): Invalid Parameter"));
        	Display(("Usage: Example SetIbeaconMinor: 1000"));
            ret_val = INVALID_PARAMETERS_ERROR;
        }
    }
    else
    {
        /* No valid Bluetooth Stack ID exists.                      */
        ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
    }

   return(ret_val);
}


static int SetIbeaconTxPower(ParameterList_t *TempParam)
{
   int           ret_val = 0;

   /* First, check that valid Bluetooth Stack ID exists.                */
    if(Initialized)
    {
        /* Next, let's make sure that the user has specified a      */
        /* Remote Bluetooth Device to open.                         */
        if((TempParam) && (TempParam->NumberofParameters == 1) && (TempParam->Params[0].intParam))
        {
            iBeacon_Tx_Power = TempParam->Params[0].intParam ;
            Display(("SetIbeaconTxPower (Success): %d", iBeacon_Tx_Power));
            Display(("In order to enable this changes, call DisableAdvertizeIbeacon and call" ));
            Display(("AdvertizeIbeacon again to enable the beacon with the updated values"));
        }
        else
        {
        	Display(("SetIbeaconTxPower (Error): Invalid Parameter"));
            Display(("Usage: SetIbeaconTxPower [Byte]"));
            ret_val = INVALID_PARAMETERS_ERROR;
        }
    }
    else
    {
        /* No valid Bluetooth Stack ID exists.                            */
        ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
    }

   return(ret_val);
}

static int QueryIbeaconParams(ParameterList_t *TempParam)
{
   int ret_val = 0;
   int i;

   /* First, check that valid Bluetooth Stack ID exists.                */
    if(Initialized)
    {
    	DisplayAdvertisingData();
    }
    else
    {
        /* No valid Bluetooth Stack ID exists.                            */
        ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
    }

   return(ret_val);
}


   /* The following function is responsible for starting an advertising */
   /* process.  This function returns zero if successful and a negative */
   /* value if an error occurred.                                       */
static int StartAdvertising(ParameterList_t *TempParam)
{
   int                            ret_val;
   DEVM_Advertising_Information_t AdvertisingInfo;
	Byte_t                        AdvertisingBuffer[32];

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
      /* Make sure that all of the parameters required for this function*/
      /* appear to be at least semi-valid.                              */
      if((TempParam) && (TempParam->NumberofParameters >= 1) && (TempParam->Params[0].intParam))
      {
         /* Format the Advertising Information.                         */
         BTPS_MemInitialize(&AdvertisingInfo, 0, sizeof(DEVM_Advertising_Information_t));

         AdvertisingInfo.AdvertisingFlags    = DEVM_ADVERTISING_INFORMATION_FLAGS_USE_PUBLIC_ADDRESS;
         AdvertisingInfo.AdvertisingDuration = TempParam->Params[0].intParam;

         FormatAdvertisingData(&AdvertisingInfo, AdvertisingBuffer);

         /* Submit the Start Advertising Command.                       */
         if((ret_val = DEVM_StartAdvertising(&AdvertisingInfo)) == 0)
         {
            Display(("DEVM_StartAdvertising() Success: Duration %lu seconds.", AdvertisingInfo.AdvertisingDuration));
         }
         else
         {
            /* Error Connecting With Remote Device, inform the user and */
            /* flag an error.                                           */
            Display(("DEVM_StartAdvertising() Failure: %d, %s.", ret_val, ERR_ConvertErrorCodeToString(ret_val)));

            ret_val = FUNCTION_ERROR;
         }
      }
      else
      {
         /* One or more of the necessary parameters is/are invalid.     */
         Display(("Usage: StartAdvertising [Duration]."));

         ret_val = INVALID_PARAMETERS_ERROR;
      }
   }
   else
   {
      /* Not initialized, flag an error.                                */
	   Display(("Platform Manager has not been initialized."));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}

   /* The following function is responsible for stopping an advertising */
   /* process.  This function returns zero if successful and a negative */
   /* value if an error occurred.                                       */
static int StopAdvertising(ParameterList_t *TempParam)
{
   int ret_val;

   /* First, check to make sure that we have already been initialized.  */
   if(Initialized)
   {
	   /* Submit the Stop Advertising Command.                        */
	   if((ret_val = DEVM_StopAdvertising(1)) == 0)
	   {
		   Display(("DEVM_StopAdvertising() Success."));
	   }
	   else
	   {
		   /* Error Connecting With Remote Device, inform the user and */
		   /* flag an error.                                           */
		   Display(("DEVM_StopAdvertising() Failure: %d, %s.", ret_val, ERR_ConvertErrorCodeToString(ret_val)));

		   ret_val = FUNCTION_ERROR;
	   }
   }
   else
   {
      /* Not initialized, flag an error.                                */
      Display(("Platform Manager has not been initialized.\n"));

      ret_val = PLATFORM_MANAGER_NOT_INITIALIZED_ERROR;
   }

   return(ret_val);
}

   /* The following function is a utility function that exists to       */
   /* display either the entire Local Device Property information (first*/
   /* parameter is zero) or portions that have changed.                 */
static void DisplayLocalDeviceProperties(unsigned long UpdateMask, DEVM_Local_Device_Properties_t *LocalDeviceProperties)
{
   char Buffer[64];

   if(LocalDeviceProperties)
   {
      /* First, display any information that is not part of any update  */
      /* mask.                                                          */
      if(!UpdateMask)
      {
         BD_ADDRToStr(LocalDeviceProperties->BD_ADDR, Buffer);

         Display(("BD_ADDR:      %s", Buffer));
         Display(("HCI Ver:      0x%04X", (Word_t)LocalDeviceProperties->HCIVersion));
         Display(("HCI Rev:      0x%04X", (Word_t)LocalDeviceProperties->HCIRevision));
         Display(("LMP Ver:      0x%04X", (Word_t)LocalDeviceProperties->LMPVersion));
         Display(("LMP Sub Ver:  0x%04X", (Word_t)LocalDeviceProperties->LMPSubVersion));
         Display(("Device Man:   0x%04X (%s)", (Word_t)LocalDeviceProperties->DeviceManufacturer, DEVM_ConvertManufacturerNameToString(LocalDeviceProperties->DeviceManufacturer)));
         Display(("Device Flags: 0x%08lX", LocalDeviceProperties->LocalDeviceFlags));
      }
      else
      {
         if(UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_DEVICE_FLAGS)
            Display(("Device Flags: 0x%08lX", LocalDeviceProperties->LocalDeviceFlags));
      }

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_BLE_ADDRESS))
      {
         switch(LocalDeviceProperties->BLEAddressType)
         {
            case atPublic:
               Display(("BLE Address Type: %s", "Public"));
               break;
            case atStatic:
               Display(("BLE Address Type: %s", "Static"));
               break;
            case atPrivate_Resolvable:
               Display(("BLE Address Type: %s", "Resolvable Random"));
               break;
            case atPrivate_NonResolvable:
               Display(("BLE Address Type: %s", "Non-Resolvable Random"));
               break;
         }

         BD_ADDRToStr(LocalDeviceProperties->BLEBD_ADDR, Buffer);

         Display(("BLE BD_ADDR:      %s", Buffer));
      }

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_CLASS_OF_DEVICE))
         Display(("COD:          0x%02X%02X%02X", LocalDeviceProperties->ClassOfDevice.Class_of_Device0, LocalDeviceProperties->ClassOfDevice.Class_of_Device1, LocalDeviceProperties->ClassOfDevice.Class_of_Device2));

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_DEVICE_NAME))
         Display(("Device Name:  %s", (LocalDeviceProperties->DeviceNameLength)?LocalDeviceProperties->DeviceName:""));

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_DISCOVERABLE_MODE))
         Display(("Disc. Mode:   %s, 0x%08X", LocalDeviceProperties->DiscoverableMode?"TRUE ":"FALSE", LocalDeviceProperties->DiscoverableModeTimeout));

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_CONNECTABLE_MODE))
         Display(("Conn. Mode:   %s, 0x%08X", LocalDeviceProperties->ConnectableMode?"TRUE ":"FALSE", LocalDeviceProperties->ConnectableModeTimeout));

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_PAIRABLE_MODE))
         Display(("Pair. Mode:   %s, 0x%08X", LocalDeviceProperties->PairableMode?"TRUE ":"FALSE", LocalDeviceProperties->PairableModeTimeout));

      if((!UpdateMask) || (UpdateMask & DEVM_LOCAL_DEVICE_PROPERTIES_CHANGED_DEVICE_FLAGS))
      {
         Display(("LE Scan Mode:    %s, 0x%08X", (LocalDeviceProperties->LocalDeviceFlags & DEVM_LOCAL_DEVICE_FLAGS_LE_SCANNING_IN_PROGRESS)?"TRUE":"FALSE", LocalDeviceProperties->ScanTimeout));
         Display(("LE Adv Mode:     %s, 0x%08X", (LocalDeviceProperties->LocalDeviceFlags & DEVM_LOCAL_DEVICE_FLAGS_LE_ADVERTISING_IN_PROGRESS)?"TRUE":"FALSE", LocalDeviceProperties->AdvertisingTimeout));
         Display(("LE Slv Mode:     %s", (LocalDeviceProperties->LocalDeviceFlags & DEVM_LOCAL_DEVICE_FLAGS_LE_ROLE_IS_CURRENTLY_SLAVE)?"In Slave Mode":"Not in Slave Mode"));
      }
   }
}


   /* The following function is the Callback function that is installed */
   /* to be notified when any local IPC connection to the server has    */
   /* been lost.  This case only occurs when the Server exits.  This    */
   /* callback allows the application mechanism to be notified so that  */
   /* all resources can be cleaned up (i.e.  call BTPM_Cleanup().       */
void BTPSAPI ServerUnRegistrationCallback(void *CallbackParameter)
{
   Display(("Server has been Un-Registered."));

   printf("TI-BT>");


   /* Make sure the output is displayed to the user.                    */
   fflush(stdout);
}

   /* The following function is the Device Manager Event Callback       */
   /* function that is Registered with the Device Manager.  This        */
   /* callback is responsible for processing all Device Manager Events. */
static void BTPSAPI DEVM_Event_Callback(DEVM_Event_Data_t *EventData, void *CallbackParameter)
{
   char Buffer[32];

   if(EventData)
   {
      Display((""));

      switch(EventData->EventType)
      {
         case detDevicePoweredOn:
            Display(("Device Powered On."));
            break;
         case detDevicePoweringOff:
            Display(("Device Powering Off Event, Timeout: 0x%08X.", EventData->EventData.DevicePoweringOffEventData.PoweringOffTimeout));
            break;
         case detDevicePoweredOff:
            Display(("Device Powered Off."));
            break;
         case detLocalDevicePropertiesChanged:
            Display(("Local Device Properties changed."));
            break;
         case detDeviceAdvertisingStarted:
            Display(("LE Advertising Started."));
            break;
         case detDeviceAdvertisingStopped:
            Display(("LE Advertising Stopped."));
            break;
         case detAdvertisingTimeout:
            Display(("LE Advertising Timeout."));
            break;
         default:
            Display(("Unknown Device Manager Event Received: 0x%08X, Length: 0x%08X.", (unsigned int)EventData->EventType, EventData->EventLength));
            break;
      }
   }
   else
      Display(("\r\nDEVM Event Data is NULL."));

   printf("TI-BT>");

   /* Make sure the output is displayed to the user.                    */
   fflush(stdout);
}

#define NUM__OF_PM_CONNECTION_RETRIES 	5
   /* Main Program Entry Point.                                         */
int main(int argc, char* argv[])
{
	int i;

	for(i=0; i<NUM__OF_PM_CONNECTION_RETRIES; i++)
	{
		Display(("Trying to connect to server (%d)...", i));
		if(Initialize() == 0)
		{
			/* Nothing really to do here aside from running the main application */
			/* code.                                                             */
			UserInterface();
			break;
		}
		sleep(1);
	}

	Cleanup();
	return 0;
}

