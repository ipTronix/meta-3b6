/*****< linuxpanm.h >**********************************************************/
/*      Copyright 2011 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXPANM - Simple Linux application using Bluetopia Platform Manager     */
/*              Personal Area Network Application Programming (API) Interface.*/
/*                                                                            */
/*  Author:  Matt Seabold                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   08/02/11  M. Seabold     Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXPANM__
#define __LINUXPANM__

#endif

