/*****< linuxsppm.h >**********************************************************/
/*      Copyright 2011 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  LINUXSPPM - Simple Linux application using Bluetopia Platform Manager     */
/*              Device Manager Application Programming (API) Interface.       */
/*                                                                            */
/*  Author:  Matt Seabold                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   06/01/11  M. Seabold     Initial creation.                               */
/******************************************************************************/
#ifndef __LINUXSPPMH__
#define __LINUXSPPMH__

#endif

