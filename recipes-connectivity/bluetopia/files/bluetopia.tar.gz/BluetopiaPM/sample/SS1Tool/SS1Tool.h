/*****< SS1Tool.h >************************************************************/
/*      Copyright 2010 - 2014 Stonestreet One.                                */
/*      All Rights Reserved.                                                  */
/*                                                                            */
/*  SS1TOOL - Command-line driven Linux application using Bluetopia Platform  */
/*            Manager Device Manager Application Programming (API) Interface. */
/*                                                                            */
/*  Author:  Greg Hensley                                                     */
/*                                                                            */
/*** MODIFICATION HISTORY *****************************************************/
/*                                                                            */
/*   mm/dd/yy  F. Lastname    Description of Modification                     */
/*   --------  -----------    ------------------------------------------------*/
/*   04/25/12  G. Hensley     Initial creation.                               */
/******************************************************************************/
#ifndef __SS1TOOLH__
#define __SS1TOOLH__

#endif

